import { spawn } from "child_process";
import fs from "fs";

async function testFeaturesPage() {
  const loginRes = await fetch("http://localhost:8080/api/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email: "admin@fedmaintain.com", password: "Admin@123" })
  });
  const auth = await loginRes.json();

  const chromeProc = spawn("C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe", [
    "--headless=new",
    "--remote-debugging-port=9226",
    "--window-size=1920,1080",
    "--disable-gpu",
    "--no-first-run",
    "about:blank"
  ]);
  await new Promise(r => setTimeout(r, 2000));

  const listRes = await fetch("http://127.0.0.1:9226/json/list");
  const targets = await listRes.json();
  const ws = new WebSocket(targets[0].webSocketDebuggerUrl);

  let id = 1;
  const pending = new Map();
  ws.onmessage = (e) => {
    const d = JSON.parse(e.data);
    if (d.method === "Runtime.consoleAPICalled") {
      console.log("PAGE CONSOLE:", d.params.type, d.params.args.map(a => a.value || a.description).join(" "));
    }
    if (d.id && pending.has(d.id)) {
      const { resolve } = pending.get(d.id);
      pending.delete(d.id);
      resolve(d.result);
    }
  };
  await new Promise(r => ws.onopen = r);

  function send(method, params = {}) {
    return new Promise(resolve => {
      const mid = id++;
      pending.set(mid, { resolve });
      ws.send(JSON.stringify({ id: mid, method, params }));
    });
  }

  await send("Page.enable");
  await send("Runtime.enable");
  await send("Page.navigate", { url: "http://localhost:5173/login" });
  await new Promise(r => setTimeout(r, 1000));

  const inject = `
    localStorage.setItem("fedmaintain_token", ${JSON.stringify(auth.token)});
    localStorage.setItem("fedmaintain_user", ${JSON.stringify(JSON.stringify(auth.user))});
  `;
  await send("Runtime.evaluate", { expression: inject });
  await send("Page.navigate", { url: "http://localhost:5173/machines/1/features" });
  await new Promise(r => setTimeout(r, 3500));

  const textRes = await send("Runtime.evaluate", { expression: "document.body.innerText" });
  console.log("FEATURES PAGE LOADED TEXT PREVIEW:\n", textRes.result.value?.substring(0, 300));

  const shot = await send("Page.captureScreenshot", { format: "png" });
  fs.writeFileSync("C:\\Users\\IDREEZE\\.gemini\\antigravity\\scratch\\fedmaintain\\screenshots\\test_features_page.png", Buffer.from(shot.data, "base64"));
  console.log("Saved test_features_page.png! Size:", Math.round(Buffer.from(shot.data, "base64").length / 1024), "KB");

  ws.close();
  chromeProc.kill();
}
testFeaturesPage().catch(console.error);
