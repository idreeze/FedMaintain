import { spawn } from "child_process";

async function testAllFeatures() {
  console.log("Starting Chrome for full UI feature verification...");
  const chromeProc = spawn("C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe", [
    "--headless=new",
    "--remote-debugging-port=9228",
    "--window-size=1920,1080",
    "--disable-gpu",
    "--no-first-run",
    "about:blank"
  ]);

  await new Promise(r => setTimeout(r, 2000));

  const listRes = await fetch("http://127.0.0.1:9228/json/list");
  const targets = await listRes.json();
  const pageTarget = targets.find(t => t.type === "page") || targets[0];
  const ws = new WebSocket(pageTarget.webSocketDebuggerUrl);

  let id = 1;
  const pending = new Map();
  const consoleLogs = [];
  const networkErrors = [];

  ws.onmessage = (e) => {
    const d = JSON.parse(e.data);
    if (d.method === "Runtime.consoleAPICalled") {
      const msg = d.params.args.map(a => a.value || a.description || JSON.stringify(a)).join(" ");
      consoleLogs.push({ type: d.params.type, msg });
      if (d.params.type === "error") {
        console.error(`[BROWSER ERROR]: ${msg}`);
      }
    }
    if (d.method === "Runtime.exceptionThrown") {
      console.error(`[PAGE EXCEPTION]: ${d.params.exceptionDetails?.exception?.description || d.params.exceptionDetails?.text}`);
    }
    if (d.method === "Network.responseReceived") {
      const resp = d.params.response;
      if (resp.status >= 400) {
        networkErrors.push({ url: resp.url, status: resp.status });
        console.error(`[HTTP ${resp.status}]: ${resp.url}`);
      }
    }
    if (d.id && pending.has(d.id)) {
      const { resolve } = pending.get(d.id);
      pending.delete(d.id);
      resolve(d.result);
    }
  };

  await new Promise(r => ws.onopen = r);

  function send(method, params = {}) {
    return new Promise(resolve => {
      const mid = id++;
      pending.set(mid, { resolve });
      ws.send(JSON.stringify({ id: mid, method, params }));
    });
  }

  await send("Page.enable");
  await send("Runtime.enable");
  await send("Network.enable");

  console.log("\n--- [Step 1] Navigating to http://localhost:5173/login ---");
  await send("Page.navigate", { url: "http://localhost:5173/login" });
  await new Promise(r => setTimeout(r, 2000));

  console.log("Clicking ADMIN test account button...");
  await send("Runtime.evaluate", {
    expression: `
      (() => {
        const btns = Array.from(document.querySelectorAll('button'));
        const adminBtn = btns.find(b => b.innerText.includes('ADMIN'));
        if (adminBtn) adminBtn.click();
      })()
    `
  });
  await new Promise(r => setTimeout(r, 600));

  console.log("Clicking Sign In button...");
  await send("Runtime.evaluate", {
    expression: `
      (() => {
        const btns = Array.from(document.querySelectorAll('button'));
        const submitBtn = btns.find(b => b.innerText.includes('Sign In') || b.type === 'submit');
        if (submitBtn) submitBtn.click();
      })()
    `
  });

  await new Promise(r => setTimeout(r, 3000));

  const afterLoginUrl = await send("Runtime.evaluate", { expression: "window.location.href" });
  console.log("URL after login:", afterLoginUrl.result.value);

  const routes = [
    { name: "Dashboard", path: "/dashboard" },
    { name: "Plants", path: "/plants" },
    { name: "Plant Details (1)", path: "/plants/1" },
    { name: "Machines", path: "/machines" },
    { name: "Machine Details (1)", path: "/machines/1" },
    { name: "Machine Monitoring / Telemetry (1)", path: "/machines/1/monitoring" },
    { name: "Feature Engineering (1)", path: "/machines/1/features" },
    { name: "RUL Predictions (1)", path: "/machines/1/predictions" },
    { name: "Machine Health & XAI (1)", path: "/machines/1/health" },
    { name: "Predictive Alerts & Workflows", path: "/alerts" },
    { name: "Federated Learning Hub", path: "/federated" },
    { name: "Digital Twins Fleet", path: "/digital-twins" },
    { name: "Digital Twin Detail (1)", path: "/digital-twins/1" }
  ];

  console.log("\n--- [Step 2] Navigating all routes and testing render & data ---");
  for (const r of routes) {
    console.log(`\nTesting ${r.name} (${r.path})...`);
    await send("Page.navigate", { url: `http://localhost:5173${r.path}` });
    await new Promise(resolve => setTimeout(resolve, 3000));

    const check = await send("Runtime.evaluate", {
      expression: `
        (() => {
          const bodyText = document.body.innerText;
          const isErrorPage = bodyText.includes("Something went wrong") || bodyText.includes("Cannot read property") || bodyText.includes("404");
          const isLoginPage = window.location.pathname === "/login";
          const heading = document.querySelector('h1, h2, h3')?.innerText || "No heading";
          return {
            url: window.location.href,
            heading: heading.trim(),
            isErrorPage,
            isLoginPage,
            preview: bodyText.substring(0, 150).replace(/\\n/g, ' ')
          };
        })()
      `,
      returnByValue: true
    });

    const info = check.result.value;
    console.log(`  Result for ${r.name}:`, JSON.stringify(info));
    if (info.isLoginPage) {
      console.warn(`  ⚠️ Redirected to login on ${r.path}!`);
    } else if (info.isErrorPage) {
      console.error(`  ❌ Error on page ${r.path}!`);
    } else {
      console.log(`  ✅ Successfully rendered ${r.name}`);
    }
  }

  console.log("\nFeature verification completed.");
  chromeProc.kill();
  process.exit(0);
}

testAllFeatures().catch(e => {
  console.error("Test script failed:", e);
  process.exit(1);
});
