import { spawn } from "child_process";

async function inspectFrontend() {
  const chromeProc = spawn("C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe", [
    "--headless=new",
    "--remote-debugging-port=9227",
    "--window-size=1920,1080",
    "--disable-gpu",
    "--no-first-run",
    "about:blank"
  ]);
  await new Promise(r => setTimeout(r, 2000));

  const listRes = await fetch("http://127.0.0.1:9227/json/list");
  const targets = await listRes.json();
  const pageTarget = targets.find(t => t.type === "page") || targets[0];
  const ws = new WebSocket(pageTarget.webSocketDebuggerUrl);

  let id = 1;
  const pending = new Map();
  ws.onmessage = (e) => {
    const d = JSON.parse(e.data);
    if (d.method === "Runtime.consoleAPICalled") {
      console.log(`[CONSOLE ${d.params.type.toUpperCase()}]:`, d.params.args.map(a => a.value || a.description || JSON.stringify(a)).join(" "));
    }
    if (d.method === "Network.responseReceived") {
      const resp = d.params.response;
      if (resp.status >= 400) {
        console.log(`[NETWORK ERROR ${resp.status}]: ${resp.url}`);
      }
    }
    if (d.id && pending.has(d.id)) {
      const { resolve } = pending.get(d.id);
      pending.delete(d.id);
      resolve(d.result);
    }
  };
  await new Promise(r => ws.onopen = r);

  function send(method, params = {}) {
    return new Promise(resolve => {
      const mid = id++;
      pending.set(mid, { resolve });
      ws.send(JSON.stringify({ id: mid, method, params }));
    });
  }

  await send("Page.enable");
  await send("Runtime.enable");
  await send("Network.enable");

  console.log("Navigating to http://localhost:5173/login...");
  await send("Page.navigate", { url: "http://localhost:5173/login" });
  await new Promise(r => setTimeout(r, 2000));

  // Type credentials and click login
  console.log("Attempting UI login form submission...");
  const loginEval = await send("Runtime.evaluate", {
    expression: `
      (async () => {
        const emailInput = document.querySelector('input[type="email"]') || document.querySelector('input[name="email"]');
        const passInput = document.querySelector('input[type="password"]');
        const submitBtn = document.querySelector('button[type="submit"]');
        if (!emailInput || !passInput || !submitBtn) return { error: "inputs not found", html: document.body.innerHTML.substring(0, 300) };
        emailInput.value = 'admin@fedmaintain.com';
        emailInput.dispatchEvent(new Event('input', { bubbles: true }));
        passInput.value = 'Admin@123';
        passInput.dispatchEvent(new Event('input', { bubbles: true }));
        submitBtn.click();
        return { success: true };
      })()
    `,
    awaitPromise: true
  });
  console.log("Login form action result:", loginEval.result.value);
  await new Promise(r => setTimeout(r, 3000));

  // Check current URL and DOM
  const curUrl = await send("Runtime.evaluate", { expression: "window.location.href" });
  console.log("Current URL after login:", curUrl.result.value);

  // Test navigation to features page
  console.log("\nNavigating to /machines/1/features...");
  await send("Page.navigate", { url: "http://localhost:5173/machines/1/features" });
  await new Promise(r => setTimeout(r, 4000));

  const featuresDom = await send("Runtime.evaluate", {
    expression: "document.body.innerText.substring(0, 400)"
  });
  console.log("Features page body text:\n", featuresDom.result.value);

  // Test navigation to dashboard
  console.log("\nNavigating to /dashboard...");
  await send("Page.navigate", { url: "http://localhost:5173/dashboard" });
  await new Promise(r => setTimeout(r, 3000));
  const dashDom = await send("Runtime.evaluate", {
    expression: "document.body.innerText.substring(0, 400)"
  });
  console.log("Dashboard page body text:\n", dashDom.result.value);

  ws.close();
  chromeProc.kill();
  console.log("Inspection finished.");
}

inspectFrontend().catch(console.error);
