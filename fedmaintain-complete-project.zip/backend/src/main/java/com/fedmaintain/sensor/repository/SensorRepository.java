package com.fedmaintain.sensor.repository;

import com.fedmaintain.sensor.entity.Sensor;
import com.fedmaintain.sensor.entity.SensorHealthState;
import com.fedmaintain.sensor.entity.SensorStatus;
import com.fedmaintain.sensor.entity.SensorType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface SensorRepository extends JpaRepository<Sensor, Long> {

    List<Sensor> findByMachineId(Long machineId);

    Optional<Sensor> findBySensorCode(String sensorCode);

    Optional<Sensor> findByMachineIdAndSensorType(Long machineId, SensorType sensorType);

    boolean existsBySensorCode(String sensorCode);

    long countByMachineId(Long machineId);

    long countByHealthState(SensorHealthState healthState);

    long countByStatus(SensorStatus status);
}
