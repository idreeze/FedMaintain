package com.fedmaintain.sensor.entity;

public enum ReadingQuality {
    GOOD,
    WARNING,
    BAD
}
