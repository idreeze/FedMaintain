package com.fedmaintain.sensor.dto;

import com.fedmaintain.sensor.entity.SensorStatus;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateSensorRequest {

    @NotBlank(message = "Sensor name is required")
    @Size(min = 2, max = 150, message = "Sensor name must be between 2 and 150 characters")
    private String name;

    @NotBlank(message = "Unit is required")
    private String unit;

    private int samplingIntervalMs;
    private SensorStatus status;
    private Double minOperatingValue;
    private Double maxOperatingValue;
    private Double warningThreshold;
    private Double criticalThreshold;
}
