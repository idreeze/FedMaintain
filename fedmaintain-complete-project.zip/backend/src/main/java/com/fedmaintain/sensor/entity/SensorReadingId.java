package com.fedmaintain.sensor.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.Instant;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SensorReadingId implements Serializable {

    private Instant time;
    private Long sensorId;
}
