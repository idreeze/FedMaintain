package com.fedmaintain.sensor.service.impl;

import com.fedmaintain.exception.ResourceNotFoundException;
import com.fedmaintain.exception.UserAlreadyExistsException;
import com.fedmaintain.machine.entity.Machine;
import com.fedmaintain.machine.repository.MachineRepository;
import com.fedmaintain.sensor.dto.CreateSensorRequest;
import com.fedmaintain.sensor.dto.SensorResponse;
import com.fedmaintain.sensor.dto.SensorStatusUpdateRequest;
import com.fedmaintain.sensor.dto.UpdateSensorRequest;
import com.fedmaintain.sensor.entity.Sensor;
import com.fedmaintain.sensor.entity.SensorHealthState;
import com.fedmaintain.sensor.entity.SensorStatus;
import com.fedmaintain.sensor.repository.SensorRepository;
import com.fedmaintain.sensor.service.SensorService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional(readOnly = true)
public class SensorServiceImpl implements SensorService {

    private final SensorRepository sensorRepository;
    private final MachineRepository machineRepository;
    private final int offlineThresholdSeconds;

    public SensorServiceImpl(
            SensorRepository sensorRepository,
            MachineRepository machineRepository,
            @Value("${telemetry.offline-threshold-seconds:30}") int offlineThresholdSeconds) {
        this.sensorRepository = sensorRepository;
        this.machineRepository = machineRepository;
        this.offlineThresholdSeconds = offlineThresholdSeconds;
    }

    @Override
    public List<SensorResponse> getSensorsByMachineId(Long machineId) {
        if (!machineRepository.existsById(machineId)) {
            throw new ResourceNotFoundException("Machine not found with id: " + machineId);
        }
        return sensorRepository.findByMachineId(machineId).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public SensorResponse getSensorById(Long id) {
        Sensor sensor = getSensorEntityById(id);
        return mapToResponse(sensor);
    }

    @Override
    public Sensor getSensorEntityById(Long id) {
        return sensorRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Sensor not found with id: " + id));
    }

    @Override
    public Sensor getSensorEntityByCode(String sensorCode) {
        return sensorRepository.findBySensorCode(sensorCode)
                .orElseThrow(() -> new ResourceNotFoundException("Sensor not found with code: " + sensorCode));
    }

    @Override
    @Transactional
    public SensorResponse createSensor(Long machineId, CreateSensorRequest request) {
        Machine machine = machineRepository.findById(machineId)
                .orElseThrow(() -> new ResourceNotFoundException("Machine not found with id: " + machineId));

        String code = request.getSensorCode().trim().toUpperCase();
        if (sensorRepository.existsBySensorCode(code)) {
            throw new UserAlreadyExistsException("Sensor with code already exists: " + code);
        }

        Sensor sensor = Sensor.builder()
                .machine(machine)
                .sensorCode(code)
                .name(request.getName().trim())
                .sensorType(request.getSensorType())
                .unit(request.getUnit().trim())
                .samplingIntervalMs(request.getSamplingIntervalMs())
                .status(request.getStatus() != null ? request.getStatus() : SensorStatus.ACTIVE)
                .minOperatingValue(request.getMinOperatingValue())
                .maxOperatingValue(request.getMaxOperatingValue())
                .warningThreshold(request.getWarningThreshold())
                .criticalThreshold(request.getCriticalThreshold())
                .healthState(SensorHealthState.NORMAL)
                .build();

        Sensor saved = sensorRepository.save(sensor);
        return mapToResponse(saved);
    }

    @Override
    @Transactional
    public SensorResponse updateSensor(Long id, UpdateSensorRequest request) {
        Sensor sensor = getSensorEntityById(id);

        sensor.setName(request.getName().trim());
        sensor.setUnit(request.getUnit().trim());
        if (request.getSamplingIntervalMs() > 0) {
            sensor.setSamplingIntervalMs(request.getSamplingIntervalMs());
        }
        if (request.getStatus() != null) {
            sensor.setStatus(request.getStatus());
        }
        sensor.setMinOperatingValue(request.getMinOperatingValue());
        sensor.setMaxOperatingValue(request.getMaxOperatingValue());
        sensor.setWarningThreshold(request.getWarningThreshold());
        sensor.setCriticalThreshold(request.getCriticalThreshold());

        Sensor updated = sensorRepository.save(sensor);
        return mapToResponse(updated);
    }

    @Override
    @Transactional
    public SensorResponse updateSensorStatus(Long id, SensorStatusUpdateRequest request) {
        Sensor sensor = getSensorEntityById(id);
        sensor.setStatus(request.getStatus());
        Sensor updated = sensorRepository.save(sensor);
        return mapToResponse(updated);
    }

    @Override
    @Transactional
    public void deleteSensor(Long id) {
        Sensor sensor = getSensorEntityById(id);
        sensorRepository.delete(sensor);
    }

    @Override
    @Transactional
    public void evaluateAllSensorHealthStates() {
        Instant cutoff = Instant.now().minusSeconds(offlineThresholdSeconds);
        List<Sensor> sensors = sensorRepository.findAll();
        for (Sensor sensor : sensors) {
            if (sensor.getStatus() == SensorStatus.INACTIVE || sensor.getStatus() == SensorStatus.FAULTY) {
                continue;
            }
            if (sensor.getLastReadingTime() == null || sensor.getLastReadingTime().isBefore(cutoff)) {
                sensor.setHealthState(SensorHealthState.OFFLINE);
                sensorRepository.save(sensor);
            }
        }
    }

    private SensorResponse mapToResponse(Sensor sensor) {
        // Dynamic offline check if active
        if (sensor.getStatus() == SensorStatus.ACTIVE && sensor.getLastReadingTime() != null) {
            Instant cutoff = Instant.now().minusSeconds(offlineThresholdSeconds);
            if (sensor.getLastReadingTime().isBefore(cutoff)) {
                sensor.setHealthState(SensorHealthState.OFFLINE);
            }
        }
        return SensorResponse.fromEntity(sensor);
    }
}
