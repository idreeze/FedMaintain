package com.fedmaintain.sensor.entity;

public enum SensorStatus {
    ACTIVE,
    INACTIVE,
    FAULTY,
    OFFLINE
}
