package com.fedmaintain.sensor.dto;

import com.fedmaintain.sensor.entity.Sensor;
import com.fedmaintain.sensor.entity.SensorHealthState;
import com.fedmaintain.sensor.entity.SensorStatus;
import com.fedmaintain.sensor.entity.SensorType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SensorResponse {

    private Long id;
    private Long machineId;
    private String machineCode;
    private String sensorCode;
    private String name;
    private SensorType sensorType;
    private String unit;
    private int samplingIntervalMs;
    private SensorStatus status;
    private Double minOperatingValue;
    private Double maxOperatingValue;
    private Double warningThreshold;
    private Double criticalThreshold;
    private Instant lastReadingTime;
    private Double lastReadingValue;
    private SensorHealthState healthState;
    private Instant createdAt;
    private Instant updatedAt;

    public static SensorResponse fromEntity(Sensor sensor) {
        return SensorResponse.builder()
                .id(sensor.getId())
                .machineId(sensor.getMachine().getId())
                .machineCode(sensor.getMachine().getMachineCode())
                .sensorCode(sensor.getSensorCode())
                .name(sensor.getName())
                .sensorType(sensor.getSensorType())
                .unit(sensor.getUnit())
                .samplingIntervalMs(sensor.getSamplingIntervalMs())
                .status(sensor.getStatus())
                .minOperatingValue(sensor.getMinOperatingValue())
                .maxOperatingValue(sensor.getMaxOperatingValue())
                .warningThreshold(sensor.getWarningThreshold())
                .criticalThreshold(sensor.getCriticalThreshold())
                .lastReadingTime(sensor.getLastReadingTime())
                .lastReadingValue(sensor.getLastReadingValue())
                .healthState(sensor.getHealthState())
                .createdAt(sensor.getCreatedAt())
                .updatedAt(sensor.getUpdatedAt())
                .build();
    }
}
