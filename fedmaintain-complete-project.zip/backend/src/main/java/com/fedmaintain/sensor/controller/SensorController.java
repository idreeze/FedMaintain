package com.fedmaintain.sensor.controller;

import com.fedmaintain.sensor.dto.CreateSensorRequest;
import com.fedmaintain.sensor.dto.SensorResponse;
import com.fedmaintain.sensor.dto.SensorStatusUpdateRequest;
import com.fedmaintain.sensor.dto.UpdateSensorRequest;
import com.fedmaintain.sensor.service.SensorService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class SensorController {

    private final SensorService sensorService;

    public SensorController(SensorService sensorService) {
        this.sensorService = sensorService;
    }

    @GetMapping("/machines/{machineId}/sensors")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER', 'OPERATOR')")
    public ResponseEntity<List<SensorResponse>> getSensorsByMachineId(@PathVariable Long machineId) {
        return ResponseEntity.ok(sensorService.getSensorsByMachineId(machineId));
    }

    @GetMapping("/sensors/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER', 'OPERATOR')")
    public ResponseEntity<SensorResponse> getSensorById(@PathVariable Long id) {
        return ResponseEntity.ok(sensorService.getSensorById(id));
    }

    @PostMapping("/machines/{machineId}/sensors")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER')")
    public ResponseEntity<SensorResponse> createSensor(
            @PathVariable Long machineId,
            @Valid @RequestBody CreateSensorRequest request) {
        SensorResponse response = sensorService.createSensor(machineId, request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @PutMapping("/sensors/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER')")
    public ResponseEntity<SensorResponse> updateSensor(
            @PathVariable Long id,
            @Valid @RequestBody UpdateSensorRequest request) {
        return ResponseEntity.ok(sensorService.updateSensor(id, request));
    }

    @PatchMapping("/sensors/{id}/status")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER')")
    public ResponseEntity<SensorResponse> updateSensorStatus(
            @PathVariable Long id,
            @Valid @RequestBody SensorStatusUpdateRequest request) {
        return ResponseEntity.ok(sensorService.updateSensorStatus(id, request));
    }

    @DeleteMapping("/sensors/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER')")
    public ResponseEntity<Void> deleteSensor(@PathVariable Long id) {
        sensorService.deleteSensor(id);
        return ResponseEntity.noContent().build();
    }
}
