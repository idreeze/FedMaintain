package com.fedmaintain.sensor.dto;

import com.fedmaintain.sensor.entity.SensorStatus;
import com.fedmaintain.sensor.entity.SensorType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateSensorRequest {

    @NotBlank(message = "Sensor code is required")
    @Size(min = 2, max = 50, message = "Sensor code must be between 2 and 50 characters")
    private String sensorCode;

    @NotBlank(message = "Sensor name is required")
    @Size(min = 2, max = 150, message = "Sensor name must be between 2 and 150 characters")
    private String name;

    @NotNull(message = "Sensor type is required (TEMPERATURE, VIBRATION, CURRENT, PRESSURE, RPM, ACOUSTIC)")
    private SensorType sensorType;

    @NotBlank(message = "Unit is required (e.g. C, mm/s, A, bar, RPM, dB)")
    private String unit;

    @Builder.Default
    private int samplingIntervalMs = 1000;

    @Builder.Default
    private SensorStatus status = SensorStatus.ACTIVE;

    private Double minOperatingValue;
    private Double maxOperatingValue;
    private Double warningThreshold;
    private Double criticalThreshold;
}
