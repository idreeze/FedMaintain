package com.fedmaintain.sensor.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Index;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;

@Entity
@Table(
    name = "sensor_readings",
    indexes = {
        @Index(name = "idx_sr_sensor_time", columnList = "sensor_id, time DESC"),
        @Index(name = "idx_sr_machine_time", columnList = "machine_id, time DESC")
    }
)
@IdClass(SensorReadingId.class)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SensorReading {

    @Id
    @Column(nullable = false)
    private Instant time;

    @Id
    @Column(name = "sensor_id", nullable = false)
    private Long sensorId;

    @Column(name = "machine_id", nullable = false)
    private Long machineId;

    @Column(name = "\"value\"", nullable = false)
    private Double value;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    @Builder.Default
    private ReadingQuality quality = ReadingQuality.GOOD;
}
