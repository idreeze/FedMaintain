package com.fedmaintain.sensor.service;

import com.fedmaintain.sensor.dto.CreateSensorRequest;
import com.fedmaintain.sensor.dto.SensorResponse;
import com.fedmaintain.sensor.dto.SensorStatusUpdateRequest;
import com.fedmaintain.sensor.dto.UpdateSensorRequest;
import com.fedmaintain.sensor.entity.Sensor;

import java.util.List;

public interface SensorService {

    List<SensorResponse> getSensorsByMachineId(Long machineId);

    SensorResponse getSensorById(Long id);

    Sensor getSensorEntityById(Long id);

    Sensor getSensorEntityByCode(String sensorCode);

    SensorResponse createSensor(Long machineId, CreateSensorRequest request);

    SensorResponse updateSensor(Long id, UpdateSensorRequest request);

    SensorResponse updateSensorStatus(Long id, SensorStatusUpdateRequest request);

    void deleteSensor(Long id);

    void evaluateAllSensorHealthStates();
}
