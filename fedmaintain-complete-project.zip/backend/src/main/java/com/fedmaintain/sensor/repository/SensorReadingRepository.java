package com.fedmaintain.sensor.repository;

import com.fedmaintain.sensor.entity.SensorReading;
import com.fedmaintain.sensor.entity.SensorReadingId;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

@Repository
public interface SensorReadingRepository extends JpaRepository<SensorReading, SensorReadingId> {

    List<SensorReading> findBySensorIdAndTimeBetweenOrderByTimeAsc(
            Long sensorId, Instant start, Instant end, Pageable pageable);

    List<SensorReading> findByMachineIdAndTimeBetweenOrderByTimeAsc(
            Long machineId, Instant start, Instant end, Pageable pageable);

    Optional<SensorReading> findFirstBySensorIdOrderByTimeDesc(Long sensorId);

    Optional<SensorReading> findFirstByMachineIdOrderByTimeDesc(Long machineId);

    @Query("SELECT AVG(sr.value) FROM SensorReading sr WHERE sr.sensorId = :sensorId AND sr.time >= :since")
    Double getAverageValueSince(@Param("sensorId") Long sensorId, @Param("since") Instant since);

    @Query("SELECT MIN(sr.value) FROM SensorReading sr WHERE sr.sensorId = :sensorId AND sr.time >= :since")
    Double getMinValueSince(@Param("sensorId") Long sensorId, @Param("since") Instant since);

    @Query("SELECT MAX(sr.value) FROM SensorReading sr WHERE sr.sensorId = :sensorId AND sr.time >= :since")
    Double getMaxValueSince(@Param("sensorId") Long sensorId, @Param("since") Instant since);

    @Query("SELECT sr FROM SensorReading sr WHERE sr.machineId = :machineId AND sr.time >= :start AND sr.time <= :end ORDER BY sr.time ASC")
    List<SensorReading> findReadingsForMachineInRange(
            @Param("machineId") Long machineId,
            @Param("start") Instant start,
            @Param("end") Instant end);
}
