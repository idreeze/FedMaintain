package com.fedmaintain.sensor.entity;

public enum SensorType {
    TEMPERATURE,
    VIBRATION,
    CURRENT,
    PRESSURE,
    RPM,
    ACOUSTIC
}
