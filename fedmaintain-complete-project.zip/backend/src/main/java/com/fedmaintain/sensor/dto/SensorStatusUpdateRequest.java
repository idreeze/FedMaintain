package com.fedmaintain.sensor.dto;

import com.fedmaintain.sensor.entity.SensorStatus;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SensorStatusUpdateRequest {

    @NotNull(message = "Status is required (ACTIVE, INACTIVE, FAULTY, OFFLINE)")
    private SensorStatus status;
}
