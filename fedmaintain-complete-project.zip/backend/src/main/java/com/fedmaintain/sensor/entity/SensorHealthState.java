package com.fedmaintain.sensor.entity;

public enum SensorHealthState {
    NORMAL,
    WARNING,
    CRITICAL,
    OFFLINE
}
