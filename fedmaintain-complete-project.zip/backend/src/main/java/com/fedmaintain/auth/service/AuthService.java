package com.fedmaintain.auth.service;

import com.fedmaintain.auth.dto.AuthResponse;
import com.fedmaintain.auth.dto.LoginRequest;
import com.fedmaintain.auth.dto.MessageResponse;
import com.fedmaintain.auth.dto.RegisterRequest;
import com.fedmaintain.user.dto.UserDto;

public interface AuthService {

    MessageResponse register(RegisterRequest request);

    AuthResponse login(LoginRequest request);

    UserDto getCurrentUser();
}
