package com.fedmaintain.alert.entity;

public enum AlertSeverity {
    INFO,
    WARNING,
    CRITICAL
}
