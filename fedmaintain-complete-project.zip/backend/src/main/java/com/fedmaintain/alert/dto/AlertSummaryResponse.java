package com.fedmaintain.alert.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AlertSummaryResponse {
    private long totalAlerts;
    private long criticalAlerts;
    private long warningAlerts;
    private long openAlerts;
    private long acknowledgedAlerts;
    private long resolvedAlerts;
}
