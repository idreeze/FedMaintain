package com.fedmaintain.alert.entity;

public enum AlertStatus {
    OPEN,
    ACKNOWLEDGED,
    IN_PROGRESS,
    RESOLVED
}
