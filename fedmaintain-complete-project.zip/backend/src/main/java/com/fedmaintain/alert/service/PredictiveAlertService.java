package com.fedmaintain.alert.service;

import com.fedmaintain.alert.dto.AlertResponse;
import com.fedmaintain.alert.dto.AlertSummaryResponse;
import com.fedmaintain.alert.entity.AlertSeverity;
import com.fedmaintain.alert.entity.AlertStatus;
import com.fedmaintain.alert.entity.AlertType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface PredictiveAlertService {
    void evaluateAlertsForMachine(Long machineId);
    Page<AlertResponse> getAlerts(Long machineId, AlertStatus status, AlertSeverity severity, AlertType alertType, Pageable pageable);
    AlertResponse getAlertById(Long alertId);
    List<AlertResponse> getActiveAlertsForMachine(Long machineId);
    AlertResponse acknowledgeAlert(Long alertId, String username);
    AlertResponse resolveAlert(Long alertId, String username);
    AlertSummaryResponse getAlertSummary();
}
