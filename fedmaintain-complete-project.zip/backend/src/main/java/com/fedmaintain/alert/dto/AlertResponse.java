package com.fedmaintain.alert.dto;

import com.fedmaintain.alert.entity.AlertSeverity;
import com.fedmaintain.alert.entity.AlertStatus;
import com.fedmaintain.alert.entity.AlertType;
import com.fedmaintain.alert.entity.MaintenanceAlert;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AlertResponse {
    private Long id;
    private Long machineId;
    private String machineCode;
    private Long predictionId;
    private AlertType alertType;
    private AlertSeverity severity;
    private String title;
    private String description;
    private Double triggerValue;
    private Double thresholdValue;
    private AlertStatus status;
    private Instant createdAt;
    private Instant updatedAt;
    private Instant acknowledgedAt;
    private Instant resolvedAt;
    private String acknowledgedBy;
    private String resolvedBy;

    public static AlertResponse fromEntity(MaintenanceAlert a) {
        if (a == null) return null;
        return AlertResponse.builder()
                .id(a.getId())
                .machineId(a.getMachine() != null ? a.getMachine().getId() : null)
                .machineCode(a.getMachine() != null ? a.getMachine().getMachineCode() : null)
                .predictionId(a.getPrediction() != null ? a.getPrediction().getId() : null)
                .alertType(a.getAlertType())
                .severity(a.getSeverity())
                .title(a.getTitle())
                .description(a.getDescription())
                .triggerValue(a.getTriggerValue())
                .thresholdValue(a.getThresholdValue())
                .status(a.getStatus())
                .createdAt(a.getCreatedAt())
                .updatedAt(a.getUpdatedAt())
                .acknowledgedAt(a.getAcknowledgedAt())
                .resolvedAt(a.getResolvedAt())
                .acknowledgedBy(a.getAcknowledgedBy())
                .resolvedBy(a.getResolvedBy())
                .build();
    }
}
