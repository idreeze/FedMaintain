package com.fedmaintain.alert.controller;

import com.fedmaintain.alert.dto.AlertResponse;
import com.fedmaintain.alert.dto.AlertSummaryResponse;
import com.fedmaintain.alert.entity.AlertSeverity;
import com.fedmaintain.alert.entity.AlertStatus;
import com.fedmaintain.alert.entity.AlertType;
import com.fedmaintain.alert.service.PredictiveAlertService;
import com.fedmaintain.common.ApiResponse;
import com.fedmaintain.common.PageResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/alerts")
public class AlertController {

    private final PredictiveAlertService alertService;

    public AlertController(PredictiveAlertService alertService) {
        this.alertService = alertService;
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER', 'OPERATOR')")
    public ResponseEntity<ApiResponse<PageResponse<AlertResponse>>> getAlerts(
            @RequestParam(required = false) Long machineId,
            @RequestParam(required = false) AlertStatus status,
            @RequestParam(required = false) AlertSeverity severity,
            @RequestParam(required = false) AlertType alertType,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        Page<AlertResponse> alerts = alertService.getAlerts(
                machineId, status, severity, alertType,
                PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt")));
        return ResponseEntity.ok(ApiResponse.success(PageResponse.fromPage(alerts)));
    }

    @GetMapping("/summary")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER', 'OPERATOR')")
    public ResponseEntity<ApiResponse<AlertSummaryResponse>> getAlertSummary() {
        AlertSummaryResponse summary = alertService.getAlertSummary();
        return ResponseEntity.ok(ApiResponse.success(summary));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER', 'OPERATOR')")
    public ResponseEntity<ApiResponse<AlertResponse>> getAlertById(@PathVariable Long id) {
        AlertResponse alert = alertService.getAlertById(id);
        return ResponseEntity.ok(ApiResponse.success(alert));
    }

    @GetMapping("/machine/{machineId}")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER', 'OPERATOR')")
    public ResponseEntity<ApiResponse<List<AlertResponse>>> getActiveAlertsForMachine(@PathVariable Long machineId) {
        List<AlertResponse> list = alertService.getActiveAlertsForMachine(machineId);
        return ResponseEntity.ok(ApiResponse.success(list));
    }

    @PostMapping("/{id}/acknowledge")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER')")
    public ResponseEntity<ApiResponse<AlertResponse>> acknowledgeAlert(
            @PathVariable Long id,
            Authentication authentication) {
        String username = authentication != null ? authentication.getName() : "ENGINEER";
        AlertResponse alert = alertService.acknowledgeAlert(id, username);
        return ResponseEntity.ok(ApiResponse.success("Alert acknowledged successfully", alert));
    }

    @PostMapping("/{id}/resolve")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER')")
    public ResponseEntity<ApiResponse<AlertResponse>> resolveAlert(
            @PathVariable Long id,
            Authentication authentication) {
        String username = authentication != null ? authentication.getName() : "ENGINEER";
        AlertResponse alert = alertService.resolveAlert(id, username);
        return ResponseEntity.ok(ApiResponse.success("Alert resolved successfully", alert));
    }
}
