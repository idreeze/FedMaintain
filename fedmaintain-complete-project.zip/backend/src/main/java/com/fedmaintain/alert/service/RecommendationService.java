package com.fedmaintain.alert.service;

import com.fedmaintain.alert.dto.RecommendationResponse;
import com.fedmaintain.alert.entity.AlertStatus;
import com.fedmaintain.alert.entity.AlertType;
import com.fedmaintain.alert.entity.MaintenanceAlert;
import com.fedmaintain.alert.repository.MaintenanceAlertRepository;
import com.fedmaintain.exception.ResourceNotFoundException;
import com.fedmaintain.machine.entity.Machine;
import com.fedmaintain.machine.repository.MachineRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class RecommendationService {

    private final MachineRepository machineRepository;
    private final MaintenanceAlertRepository alertRepository;

    public RecommendationService(
            MachineRepository machineRepository,
            MaintenanceAlertRepository alertRepository) {
        this.machineRepository = machineRepository;
        this.alertRepository = alertRepository;
    }

    @Transactional(readOnly = true)
    public RecommendationResponse getRecommendationsForMachine(Long machineId) {
        Machine machine = machineRepository.findById(machineId)
                .orElseThrow(() -> new ResourceNotFoundException("Machine not found with id: " + machineId));

        List<MaintenanceAlert> activeAlerts = alertRepository.findByMachineIdAndStatusIn(
                machineId, List.of(AlertStatus.OPEN, AlertStatus.ACKNOWLEDGED, AlertStatus.IN_PROGRESS));

        List<String> recommendations = new ArrayList<>();
        String priority = "NORMAL";

        if (activeAlerts.isEmpty()) {
            recommendations.add("Machine operating within nominal baseline parameters. Continue scheduled routine monitoring.");
            return RecommendationResponse.builder()
                    .machineId("MACHINE-" + machine.getId())
                    .machineCode(machine.getMachineCode())
                    .recommendations(recommendations)
                    .priority(priority)
                    .build();
        }

        Set<AlertType> types = activeAlerts.stream().map(MaintenanceAlert::getAlertType).collect(Collectors.toSet());

        if (types.contains(AlertType.RUL_CRITICAL) || types.contains(AlertType.MULTI_SENSOR_DEGRADATION)) {
            priority = "URGENT";
            recommendations.add("URGENT: Initiate tool idling sequence and complete in-flight wafer transfer. RUL/Multi-sensor critical limit breached.");
        } else if (types.contains(AlertType.RUL_LOW) || types.contains(AlertType.VIBRATION_ANOMALY)) {
            priority = "HIGH";
        } else {
            priority = "MEDIUM";
        }

        if (types.contains(AlertType.VIBRATION_ANOMALY)) {
            recommendations.add("Vibration Anomaly: Inspect spindle/bearing condition. Check mechanical runout, spindle balance, and bearing lubrication levels.");
        }
        if (types.contains(AlertType.TEMPERATURE_ANOMALY)) {
            recommendations.add("Temperature Anomaly: Inspect cooling circuits, thermal heat exchanger efficiency, and chiller setpoints.");
        }
        if (types.contains(AlertType.CURRENT_ANOMALY)) {
            recommendations.add("Current Anomaly: Inspect motor/load condition. Verify drive motor windings and mechanical slide friction.");
        }
        if (types.contains(AlertType.RUL_LOW)) {
            recommendations.add("Low RUL Notice: Schedule maintenance inspection during the upcoming cleanroom shift changeover.");
        }
        if (types.contains(AlertType.DATA_QUALITY)) {
            recommendations.add("Data Quality Alert: Verify edge sensor wiring, gateway telemetry latency, and sampling packet loss.");
        }

        return RecommendationResponse.builder()
                .machineId("MACHINE-" + machine.getId())
                .machineCode(machine.getMachineCode())
                .recommendations(recommendations)
                .priority(priority)
                .build();
    }
}
