package com.fedmaintain.alert.repository;

import com.fedmaintain.alert.entity.AlertSeverity;
import com.fedmaintain.alert.entity.AlertStatus;
import com.fedmaintain.alert.entity.AlertType;
import com.fedmaintain.alert.entity.MaintenanceAlert;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

@Repository
public interface MaintenanceAlertRepository extends JpaRepository<MaintenanceAlert, Long> {

    List<MaintenanceAlert> findByMachineIdAndStatusIn(Long machineId, Collection<AlertStatus> statuses);

    Optional<MaintenanceAlert> findFirstByMachineIdAndAlertTypeAndStatusIn(
            Long machineId, AlertType alertType, Collection<AlertStatus> statuses);

    Page<MaintenanceAlert> findByMachineIdOrderByCreatedAtDesc(Long machineId, Pageable pageable);

    Page<MaintenanceAlert> findByStatusOrderByCreatedAtDesc(AlertStatus status, Pageable pageable);

    @Query("SELECT a FROM MaintenanceAlert a WHERE " +
           "(:machineId IS NULL OR a.machine.id = :machineId) AND " +
           "(:status IS NULL OR a.status = :status) AND " +
           "(:severity IS NULL OR a.severity = :severity) AND " +
           "(:alertType IS NULL OR a.alertType = :alertType) " +
           "ORDER BY a.createdAt DESC")
    Page<MaintenanceAlert> findFilteredAlerts(
            @Param("machineId") Long machineId,
            @Param("status") AlertStatus status,
            @Param("severity") AlertSeverity severity,
            @Param("alertType") AlertType alertType,
            Pageable pageable);

    long countByStatus(AlertStatus status);

    long countBySeverity(AlertSeverity severity);
}
