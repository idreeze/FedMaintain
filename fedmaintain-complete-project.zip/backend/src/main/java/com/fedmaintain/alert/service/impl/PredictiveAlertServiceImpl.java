package com.fedmaintain.alert.service.impl;

import com.fedmaintain.alert.dto.AlertResponse;
import com.fedmaintain.alert.dto.AlertSummaryResponse;
import com.fedmaintain.alert.entity.AlertSeverity;
import com.fedmaintain.alert.entity.AlertStatus;
import com.fedmaintain.alert.entity.AlertType;
import com.fedmaintain.alert.entity.MaintenanceAlert;
import com.fedmaintain.alert.repository.MaintenanceAlertRepository;
import com.fedmaintain.alert.service.PredictiveAlertService;
import com.fedmaintain.exception.ResourceNotFoundException;
import com.fedmaintain.feature.entity.DataQualityState;
import com.fedmaintain.feature.entity.MachineBaseline;
import com.fedmaintain.feature.entity.MachineFeature;
import com.fedmaintain.feature.repository.MachineFeatureRepository;
import com.fedmaintain.feature.service.MachineBaselineService;
import com.fedmaintain.machine.entity.Machine;
import com.fedmaintain.machine.repository.MachineRepository;
import com.fedmaintain.ml.entity.RulPrediction;
import com.fedmaintain.ml.repository.RulPredictionRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

@Service
public class PredictiveAlertServiceImpl implements PredictiveAlertService {

    private static final Logger log = LoggerFactory.getLogger(PredictiveAlertServiceImpl.class);

    private final MaintenanceAlertRepository alertRepository;
    private final MachineRepository machineRepository;
    private final MachineFeatureRepository featureRepository;
    private final MachineBaselineService baselineService;
    private final RulPredictionRepository predictionRepository;

    @Value("${ml.rul.thresholds.warning-hours:24.0}")
    private double rulWarningHours;

    @Value("${ml.rul.thresholds.critical-hours:8.0}")
    private double rulCriticalHours;

    public PredictiveAlertServiceImpl(
            MaintenanceAlertRepository alertRepository,
            MachineRepository machineRepository,
            MachineFeatureRepository featureRepository,
            MachineBaselineService baselineService,
            RulPredictionRepository predictionRepository) {
        this.alertRepository = alertRepository;
        this.machineRepository = machineRepository;
        this.featureRepository = featureRepository;
        this.baselineService = baselineService;
        this.predictionRepository = predictionRepository;
    }

    @Override
    @Transactional
    public void evaluateAlertsForMachine(Long machineId) {
        Machine machine = machineRepository.findById(machineId).orElse(null);
        if (machine == null) {
            return;
        }

        MachineFeature feature = featureRepository.findFirstByMachineIdOrderByWindowEndDesc(machineId).orElse(null);
        MachineBaseline baseline = baselineService.getOrCreateBaseline(machineId);
        RulPrediction pred = predictionRepository.findFirstByMachineIdOrderByPredictionTimeDesc(machineId).orElse(null);

        // 1. Evaluate RUL alerts
        if (pred != null) {
            double rul = pred.getRulHours();
            if (rul < rulCriticalHours) {
                upsertAlert(machine, pred, AlertType.RUL_CRITICAL, AlertSeverity.CRITICAL,
                        "Critical RUL: Tool Failure Imminent",
                        String.format("Remaining useful life has dropped to %.1f hours (critical limit < %.1f hrs). Immediate intervention required.", rul, rulCriticalHours),
                        rul, rulCriticalHours);
            } else if (rul < rulWarningHours) {
                upsertAlert(machine, pred, AlertType.RUL_LOW, AlertSeverity.WARNING,
                        "Low RUL Warning",
                        String.format("Remaining useful life is %.1f hours (warning limit < %.1f hrs). Schedule tool maintenance.", rul, rulWarningHours),
                        rul, rulWarningHours);
            }
        }

        // 2. Evaluate Sensor Deviations
        boolean highVib = false;
        boolean highTemp = false;

        if (feature != null) {
            // Vibration check
            double vibRms = feature.getVibrationRms() != null ? feature.getVibrationRms() : 0.0;
            double baseVib = baseline.getBaselineVibration();
            double vibDevPct = feature.getVibrationDeviationPct() != null ? feature.getVibrationDeviationPct() : 0.0;

            if (vibRms >= 7.0 || vibDevPct >= 150.0) {
                highVib = true;
                upsertAlert(machine, pred, AlertType.VIBRATION_ANOMALY, AlertSeverity.CRITICAL,
                        "Critical Vibration Anomaly",
                        String.format("Vibration RMS reached %.2f mm/s (+%.1f%% above baseline %.2f mm/s). Mechanical bearing damage risk.", vibRms, vibDevPct, baseVib),
                        vibRms, baseVib * 2.0);
            } else if (vibRms >= 3.5 || vibDevPct >= 60.0) {
                highVib = true;
                upsertAlert(machine, pred, AlertType.VIBRATION_ANOMALY, AlertSeverity.WARNING,
                        "Elevated Vibration Warning",
                        String.format("Vibration RMS is elevated at %.2f mm/s (+%.1f%% deviation).", vibRms, vibDevPct),
                        vibRms, baseVib * 1.6);
            }

            // Temperature check
            double tempMean = feature.getTemperatureMean() != null ? feature.getTemperatureMean() : 0.0;
            double baseTemp = baseline.getBaselineTemperature();
            double tempDevPct = feature.getTemperatureDeviationPct() != null ? feature.getTemperatureDeviationPct() : 0.0;

            if (tempMean >= 80.0 || tempDevPct >= 60.0) {
                highTemp = true;
                upsertAlert(machine, pred, AlertType.TEMPERATURE_ANOMALY, AlertSeverity.CRITICAL,
                        "Critical Chamber Temperature Excursion",
                        String.format("Process temperature reached %.1f C (+%.1f%% above baseline %.1f C). Thermal runaway risk.", tempMean, tempDevPct, baseTemp),
                        tempMean, baseTemp * 1.5);
            } else if (tempMean >= 65.0 || tempDevPct >= 30.0) {
                highTemp = true;
                upsertAlert(machine, pred, AlertType.TEMPERATURE_ANOMALY, AlertSeverity.WARNING,
                        "Elevated Temperature Warning",
                        String.format("Chamber temperature elevated at %.1f C (+%.1f%% deviation).", tempMean, tempDevPct),
                        tempMean, baseTemp * 1.3);
            }

            // Current check
            double currMean = feature.getCurrentMean() != null ? feature.getCurrentMean() : 0.0;
            double baseCurr = baseline.getBaselineCurrent();
            double currDevPct = feature.getCurrentDeviationPct() != null ? feature.getCurrentDeviationPct() : 0.0;

            if (currMean >= 32.0 || currDevPct >= 70.0) {
                upsertAlert(machine, pred, AlertType.CURRENT_ANOMALY, AlertSeverity.WARNING,
                        "Motor Overcurrent Anomaly",
                        String.format("Spindle motor current reached %.1f A (+%.1f%% above baseline %.1f A). High mechanical load.", currMean, currDevPct, baseCurr),
                        currMean, baseCurr * 1.5);
            }

            // Multi-sensor degradation check
            if (highVib && highTemp && (pred == null || pred.getRulHours() < 40.0)) {
                upsertAlert(machine, pred, AlertType.MULTI_SENSOR_DEGRADATION, AlertSeverity.CRITICAL,
                        "Multi-Sensor Simultaneous Degradation",
                        "Both thermal and mechanical vibration parameters are deteriorating concurrently under declining RUL. Emergency inspection advised.",
                        vibRms, 7.0);
            }

            // Data Quality check
            if (feature.getDataQuality() == DataQualityState.DEGRADED || feature.getDataQuality() == DataQualityState.INSUFFICIENT) {
                upsertAlert(machine, pred, AlertType.DATA_QUALITY, AlertSeverity.INFO,
                        "Telemetry Quality Alert",
                        "Sensor sampling gaps or packet dropouts detected in the recent telemetry sliding window.",
                        0.0, 0.0);
            }
        }
    }

    /**
     * Deduplication: if an active alert (OPEN, ACKNOWLEDGED, IN_PROGRESS) already exists
     * for this machine and alertType, update its triggerValue and updatedAt instead of inserting a duplicate!
     */
    private void upsertAlert(
            Machine machine,
            RulPrediction pred,
            AlertType alertType,
            AlertSeverity severity,
            String title,
            String description,
            Double triggerValue,
            Double thresholdValue) {

        List<AlertStatus> activeStatuses = List.of(AlertStatus.OPEN, AlertStatus.ACKNOWLEDGED, AlertStatus.IN_PROGRESS);
        Optional<MaintenanceAlert> existingOpt = alertRepository.findFirstByMachineIdAndAlertTypeAndStatusIn(
                machine.getId(), alertType, activeStatuses);

        if (existingOpt.isPresent()) {
            MaintenanceAlert existing = existingOpt.get();
            existing.setTriggerValue(triggerValue);
            existing.setPrediction(pred);
            existing.setSeverity(severity);
            existing.setDescription(description);
            existing.setUpdatedAt(Instant.now());
            alertRepository.save(existing);
            log.debug("Updated existing alert {} for machine {}", existing.getId(), machine.getMachineCode());
        } else {
            MaintenanceAlert newAlert = MaintenanceAlert.builder()
                    .machine(machine)
                    .prediction(pred)
                    .alertType(alertType)
                    .severity(severity)
                    .title(title)
                    .description(description)
                    .triggerValue(triggerValue)
                    .thresholdValue(thresholdValue)
                    .status(AlertStatus.OPEN)
                    .createdAt(Instant.now())
                    .updatedAt(Instant.now())
                    .build();
            alertRepository.save(newAlert);
            log.info("Created new maintenance alert {} [{}] for machine {}", alertType, severity, machine.getMachineCode());
        }
    }

    @Override
    @Transactional(readOnly = true)
    public Page<AlertResponse> getAlerts(
            Long machineId, AlertStatus status, AlertSeverity severity, AlertType alertType, Pageable pageable) {
        return alertRepository.findFilteredAlerts(machineId, status, severity, alertType, pageable)
                .map(AlertResponse::fromEntity);
    }

    @Override
    @Transactional(readOnly = true)
    public AlertResponse getAlertById(Long alertId) {
        return alertRepository.findById(alertId)
                .map(AlertResponse::fromEntity)
                .orElseThrow(() -> new ResourceNotFoundException("Alert not found with id: " + alertId));
    }

    @Override
    @Transactional(readOnly = true)
    public List<AlertResponse> getActiveAlertsForMachine(Long machineId) {
        return alertRepository.findByMachineIdAndStatusIn(machineId, List.of(AlertStatus.OPEN, AlertStatus.ACKNOWLEDGED, AlertStatus.IN_PROGRESS)).stream()
                .map(AlertResponse::fromEntity)
                .toList();
    }

    @Override
    @Transactional
    public AlertResponse acknowledgeAlert(Long alertId, String username) {
        MaintenanceAlert alert = alertRepository.findById(alertId)
                .orElseThrow(() -> new ResourceNotFoundException("Alert not found with id: " + alertId));
        alert.setStatus(AlertStatus.ACKNOWLEDGED);
        alert.setAcknowledgedAt(Instant.now());
        alert.setAcknowledgedBy(username);
        alert.setUpdatedAt(Instant.now());
        return AlertResponse.fromEntity(alertRepository.save(alert));
    }

    @Override
    @Transactional
    public AlertResponse resolveAlert(Long alertId, String username) {
        MaintenanceAlert alert = alertRepository.findById(alertId)
                .orElseThrow(() -> new ResourceNotFoundException("Alert not found with id: " + alertId));
        alert.setStatus(AlertStatus.RESOLVED);
        alert.setResolvedAt(Instant.now());
        alert.setResolvedBy(username);
        alert.setUpdatedAt(Instant.now());
        return AlertResponse.fromEntity(alertRepository.save(alert));
    }

    @Override
    @Transactional(readOnly = true)
    public AlertSummaryResponse getAlertSummary() {
        return AlertSummaryResponse.builder()
                .totalAlerts(alertRepository.count())
                .criticalAlerts(alertRepository.countBySeverity(AlertSeverity.CRITICAL))
                .warningAlerts(alertRepository.countBySeverity(AlertSeverity.WARNING))
                .openAlerts(alertRepository.countByStatus(AlertStatus.OPEN))
                .acknowledgedAlerts(alertRepository.countByStatus(AlertStatus.ACKNOWLEDGED))
                .resolvedAlerts(alertRepository.countByStatus(AlertStatus.RESOLVED))
                .build();
    }
}
