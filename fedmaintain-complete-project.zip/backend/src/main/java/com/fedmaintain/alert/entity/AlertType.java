package com.fedmaintain.alert.entity;

public enum AlertType {
    RUL_LOW,
    RUL_CRITICAL,
    VIBRATION_ANOMALY,
    TEMPERATURE_ANOMALY,
    CURRENT_ANOMALY,
    MULTI_SENSOR_DEGRADATION,
    DATA_QUALITY
}
