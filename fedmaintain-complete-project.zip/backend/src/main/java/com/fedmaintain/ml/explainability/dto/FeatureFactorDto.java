package com.fedmaintain.ml.explainability.dto;

import com.fedmaintain.ml.explainability.entity.ContributionLevel;
import com.fedmaintain.ml.explainability.entity.DeviationDirection;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FeatureFactorDto {
    private String feature;
    private Double value;
    private Double baseline;
    private Double deviationPercentage;
    private ContributionLevel level;
    private DeviationDirection direction;
}
