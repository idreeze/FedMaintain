package com.fedmaintain.ml.explainability.service.impl;

import com.fedmaintain.exception.ResourceNotFoundException;
import com.fedmaintain.feature.entity.MachineBaseline;
import com.fedmaintain.feature.entity.MachineFeature;
import com.fedmaintain.feature.repository.MachineBaselineRepository;
import com.fedmaintain.feature.repository.MachineFeatureRepository;
import com.fedmaintain.feature.service.MachineBaselineService;
import com.fedmaintain.ml.entity.RulPrediction;
import com.fedmaintain.ml.explainability.dto.ExplanationResponse;
import com.fedmaintain.ml.explainability.dto.FeatureFactorDto;
import com.fedmaintain.ml.explainability.entity.ContributionLevel;
import com.fedmaintain.ml.explainability.entity.DeviationDirection;
import com.fedmaintain.ml.explainability.entity.PredictionExplanation;
import com.fedmaintain.ml.explainability.repository.PredictionExplanationRepository;
import com.fedmaintain.ml.explainability.service.ExplainabilityService;
import com.fedmaintain.ml.repository.RulPredictionRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.*;

@Service
public class ExplainabilityServiceImpl implements ExplainabilityService {

    private final RulPredictionRepository predictionRepository;
    private final MachineFeatureRepository featureRepository;
    private final MachineBaselineService baselineService;
    private final PredictionExplanationRepository explanationRepository;

    public ExplainabilityServiceImpl(
            RulPredictionRepository predictionRepository,
            MachineFeatureRepository featureRepository,
            MachineBaselineService baselineService,
            PredictionExplanationRepository explanationRepository) {
        this.predictionRepository = predictionRepository;
        this.featureRepository = featureRepository;
        this.baselineService = baselineService;
        this.explanationRepository = explanationRepository;
    }

    @Override
    @Transactional
    public ExplanationResponse generateExplanation(Long predictionId) {
        RulPrediction prediction = predictionRepository.findById(predictionId)
                .orElseThrow(() -> new ResourceNotFoundException("Prediction not found with id: " + predictionId));

        Long machineId = prediction.getMachine().getId();
        MachineFeature latestFeature = featureRepository.findFirstByMachineIdOrderByWindowEndDesc(machineId)
                .orElse(null);
        MachineBaseline baseline = baselineService.getOrCreateBaseline(machineId);

        List<FeatureFactorDto> factors = new ArrayList<>();

        if (latestFeature != null) {
            addFactor(factors, "temperature_mean", latestFeature.getTemperatureMean(), baseline.getBaselineTemperature());
            addFactor(factors, "temperature_trend", latestFeature.getTemperatureTrend(), 0.01);
            addFactor(factors, "vibration_rms", latestFeature.getVibrationRms(), baseline.getBaselineVibration());
            addFactor(factors, "vibration_trend", latestFeature.getVibrationTrend(), 0.005);
            addFactor(factors, "current_mean", latestFeature.getCurrentMean(), baseline.getBaselineCurrent());
            addFactor(factors, "current_trend", latestFeature.getCurrentTrend(), 0.01);
            addFactor(factors, "pressure_mean", latestFeature.getPressureMean(), baseline.getBaselinePressure());
            addFactor(factors, "rpm_mean", latestFeature.getRpmMean(), baseline.getBaselineRpm());
            addFactor(factors, "acoustic_mean", latestFeature.getAcousticMean(), baseline.getBaselineAcoustic());
        }

        // Sort descending by deviation percentage
        factors.sort(Comparator.comparingDouble(FeatureFactorDto::getDeviationPercentage).reversed());

        // Persist explanations
        List<PredictionExplanation> entities = new ArrayList<>();
        for (FeatureFactorDto f : factors) {
            entities.add(PredictionExplanation.builder()
                    .prediction(prediction)
                    .featureName(f.getFeature())
                    .featureValue(f.getValue())
                    .baselineValue(f.getBaseline())
                    .deviationPercentage(f.getDeviationPercentage())
                    .contributionLevel(f.getLevel())
                    .direction(f.getDirection())
                    .createdAt(Instant.now())
                    .build());
        }
        explanationRepository.saveAll(entities);

        // Approximate health score for summary display
        int healthScore = calculateQuickHealth(prediction.getRulHours(), factors);

        return ExplanationResponse.builder()
                .machineId(prediction.getMachine().getMachineCode())
                .rulHours(prediction.getRulHours())
                .healthScore(healthScore)
                .factors(factors)
                .build();
    }

    private void addFactor(List<FeatureFactorDto> factors, String name, Double current, Double baseline) {
        if (current == null || baseline == null) {
            return;
        }

        double diff = current - baseline;
        double devPct = Math.abs(baseline) > 1e-9 ? Math.abs((diff / baseline) * 100.0) : Math.abs(diff) * 100.0;
        devPct = round(devPct, 2);

        ContributionLevel level;
        if (devPct >= 80.0) {
            level = ContributionLevel.CRITICAL;
        } else if (devPct >= 40.0) {
            level = ContributionLevel.HIGH;
        } else if (devPct >= 15.0) {
            level = ContributionLevel.MEDIUM;
        } else {
            level = ContributionLevel.LOW;
        }

        DeviationDirection dir;
        if (diff > 1e-6) {
            dir = DeviationDirection.POSITIVE;
        } else if (diff < -1e-6) {
            dir = DeviationDirection.NEGATIVE;
        } else {
            dir = DeviationDirection.NEUTRAL;
        }

        factors.add(FeatureFactorDto.builder()
                .feature(name)
                .value(round(current, 2))
                .baseline(round(baseline, 2))
                .deviationPercentage(devPct)
                .level(level)
                .direction(dir)
                .build());
    }

    private int calculateQuickHealth(Double rulHours, List<FeatureFactorDto> factors) {
        double penalty = 0.0;
        for (FeatureFactorDto f : factors) {
            switch (f.getLevel()) {
                case CRITICAL -> penalty += 15.0;
                case HIGH -> penalty += 8.0;
                case MEDIUM -> penalty += 3.0;
                default -> {}
            }
        }
        double rulScore = (rulHours != null) ? Math.min(100.0, (rulHours / 72.0) * 100.0) : 100.0;
        double score = (rulScore * 0.4) + Math.max(0.0, (100.0 - penalty) * 0.6);
        return (int) Math.max(0, Math.min(100, Math.round(score)));
    }

    @Override
    @Transactional
    public ExplanationResponse getLatestExplanation(Long machineId) {
        RulPrediction latestPred = predictionRepository.findFirstByMachineIdOrderByPredictionTimeDesc(machineId)
                .orElse(null);
        if (latestPred == null) {
            return ExplanationResponse.builder()
                    .machineId("MACHINE-" + machineId)
                    .rulHours(null)
                    .healthScore(null)
                    .factors(Collections.emptyList())
                    .build();
        }

        List<PredictionExplanation> existing = explanationRepository.findByPredictionIdOrderByDeviationPercentageDesc(latestPred.getId());
        if (existing.isEmpty()) {
            return generateExplanation(latestPred.getId());
        }

        List<FeatureFactorDto> factors = existing.stream()
                .map(e -> FeatureFactorDto.builder()
                        .feature(e.getFeatureName())
                        .value(e.getFeatureValue())
                        .baseline(e.getBaselineValue())
                        .deviationPercentage(e.getDeviationPercentage())
                        .level(e.getContributionLevel())
                        .direction(e.getDirection())
                        .build())
                .toList();

        int healthScore = calculateQuickHealth(latestPred.getRulHours(), factors);

        return ExplanationResponse.builder()
                .machineId(latestPred.getMachine().getMachineCode())
                .rulHours(latestPred.getRulHours())
                .healthScore(healthScore)
                .factors(factors)
                .build();
    }

    private double round(double val, int places) {
        return BigDecimal.valueOf(val).setScale(places, RoundingMode.HALF_UP).doubleValue();
    }
}
