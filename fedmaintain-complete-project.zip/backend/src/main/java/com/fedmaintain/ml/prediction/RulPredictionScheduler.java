package com.fedmaintain.ml.prediction;

import com.fedmaintain.alert.service.PredictiveAlertService;
import com.fedmaintain.machine.entity.Machine;
import com.fedmaintain.machine.entity.MachineStatus;
import com.fedmaintain.machine.repository.MachineRepository;
import com.fedmaintain.ml.dto.RulPredictionResponse;
import com.fedmaintain.ml.entity.ModelStatus;
import com.fedmaintain.ml.explainability.service.ExplainabilityService;
import com.fedmaintain.ml.repository.ModelVersionRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class RulPredictionScheduler {

    private static final Logger log = LoggerFactory.getLogger(RulPredictionScheduler.class);

    private final MachineRepository machineRepository;
    private final ModelVersionRepository modelVersionRepository;
    private final RulPredictionService predictionService;
    private final ExplainabilityService explainabilityService;
    private final PredictiveAlertService alertService;

    @Value("${ml.prediction.scheduled-enabled:false}")
    private boolean scheduledEnabled;

    public RulPredictionScheduler(
            MachineRepository machineRepository,
            ModelVersionRepository modelVersionRepository,
            RulPredictionService predictionService,
            ExplainabilityService explainabilityService,
            PredictiveAlertService alertService) {
        this.machineRepository = machineRepository;
        this.modelVersionRepository = modelVersionRepository;
        this.predictionService = predictionService;
        this.explainabilityService = explainabilityService;
        this.alertService = alertService;
    }

    @Scheduled(fixedRateString = "${ml.prediction.schedule-ms:300000}")
    public void runScheduledPredictionPipeline() {
        if (!scheduledEnabled) {
            return;
        }

        // Check if an active model exists
        if (modelVersionRepository.findFirstByStatusOrderByCreatedAtDesc(ModelStatus.ACTIVE).isEmpty()) {
            log.debug("Skipping scheduled RUL prediction cycle: No ACTIVE model in registry.");
            return;
        }

        List<Machine> activeMachines = machineRepository.findAll().stream()
                .filter(m -> m.getStatus() == MachineStatus.ACTIVE)
                .toList();

        for (Machine machine : activeMachines) {
            try {
                // 1. Predict RUL
                RulPredictionResponse pred = predictionService.predictForMachine(machine.getId());
                // 2. Generate Explainability Attribution
                explainabilityService.generateExplanation(pred.getId());
                // 3. Evaluate Alerts & Deduplicate
                alertService.evaluateAlertsForMachine(machine.getId());
                log.debug("Completed prediction, explainability, and alert evaluation for machine {}", machine.getMachineCode());
            } catch (Exception e) {
                log.debug("Could not complete prediction cycle for machine {}: {}", machine.getMachineCode(), e.getMessage());
            }
        }
    }
}
