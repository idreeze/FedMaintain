package com.fedmaintain.ml.health.entity;

public enum HealthStatus {
    HEALTHY,
    WATCH,
    WARNING,
    CRITICAL
}
