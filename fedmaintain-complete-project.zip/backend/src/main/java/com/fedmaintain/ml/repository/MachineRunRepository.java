package com.fedmaintain.ml.repository;

import com.fedmaintain.ml.entity.MachineRun;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface MachineRunRepository extends JpaRepository<MachineRun, Long> {
    Optional<MachineRun> findByRunId(String runId);
    List<MachineRun> findByMachineIdOrderByStartTimeDesc(Long machineId);
    List<MachineRun> findByFailureTimestampIsNotNull();
    boolean existsByRunId(String runId);
}
