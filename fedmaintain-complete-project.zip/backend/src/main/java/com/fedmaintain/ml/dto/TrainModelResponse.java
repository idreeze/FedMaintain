package com.fedmaintain.ml.dto;

import com.fedmaintain.ml.entity.ModelAlgorithm;
import com.fedmaintain.ml.entity.ModelStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TrainModelResponse {
    private String modelVersion;
    private ModelAlgorithm algorithm;
    private Double mae;
    private Double rmse;
    private Double r2;
    private Integer trainingSamples;
    private Integer testSamples;
    private ModelStatus status;
}
