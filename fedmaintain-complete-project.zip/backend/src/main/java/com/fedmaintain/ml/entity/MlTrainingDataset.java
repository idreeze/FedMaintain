package com.fedmaintain.ml.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;

@Entity
@Table(name = "ml_training_datasets")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MlTrainingDataset {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "dataset_version", nullable = false, unique = true, length = 50)
    private String datasetVersion;

    @Column(name = "dataset_type", nullable = false, length = 50)
    @Builder.Default
    private String datasetType = "RUL_SUPERVISED";

    @Column(name = "feature_schema_version", nullable = false, length = 30)
    @Builder.Default
    private String featureSchemaVersion = "v1";

    @Column(name = "machine_count", nullable = false)
    @Builder.Default
    private Integer machineCount = 0;

    @Column(name = "sample_count", nullable = false)
    @Builder.Default
    private Integer sampleCount = 0;

    @Column(name = "created_at", nullable = false)
    @Builder.Default
    private Instant createdAt = Instant.now();
}
