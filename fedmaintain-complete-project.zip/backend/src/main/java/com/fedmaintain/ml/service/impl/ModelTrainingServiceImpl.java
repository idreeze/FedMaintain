package com.fedmaintain.ml.service.impl;

import com.fedmaintain.ml.dataset.LeakageFreeDatasetSplitter;
import com.fedmaintain.ml.dataset.LeakageFreeDatasetSplitter.DatasetSplit;
import com.fedmaintain.ml.dataset.RulDatasetBuilder;
import com.fedmaintain.ml.dataset.SyntheticDataSeeder;
import com.fedmaintain.ml.dto.TrainModelRequest;
import com.fedmaintain.ml.dto.TrainModelResponse;
import com.fedmaintain.ml.entity.*;
import com.fedmaintain.ml.evaluation.ModelEvaluationService;
import com.fedmaintain.ml.evaluation.ModelEvaluationService.EvaluationMetrics;
import com.fedmaintain.ml.repository.ModelVersionRepository;
import com.fedmaintain.ml.repository.RulTrainingSampleRepository;
import com.fedmaintain.ml.service.ModelStorageService;
import com.fedmaintain.ml.service.ModelTrainingService;
import com.fedmaintain.ml.training.TribuoDatasetHelper;
import com.fedmaintain.ml.training.TribuoLinearRegressionTrainer;
import com.fedmaintain.ml.training.TribuoRandomForestTrainer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.tribuo.Model;
import org.tribuo.MutableDataset;
import org.tribuo.Prediction;
import org.tribuo.regression.Regressor;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@Service
public class ModelTrainingServiceImpl implements ModelTrainingService {

    private static final Logger log = LoggerFactory.getLogger(ModelTrainingServiceImpl.class);

    private final SyntheticDataSeeder dataSeeder;
    private final RulDatasetBuilder datasetBuilder;
    private final LeakageFreeDatasetSplitter splitter;
    private final RulTrainingSampleRepository sampleRepository;
    private final TribuoLinearRegressionTrainer linearTrainer;
    private final TribuoRandomForestTrainer randomForestTrainer;
    private final ModelEvaluationService evaluationService;
    private final ModelStorageService storageService;
    private final ModelVersionRepository modelVersionRepository;

    public ModelTrainingServiceImpl(
            SyntheticDataSeeder dataSeeder,
            RulDatasetBuilder datasetBuilder,
            LeakageFreeDatasetSplitter splitter,
            RulTrainingSampleRepository sampleRepository,
            TribuoLinearRegressionTrainer linearTrainer,
            TribuoRandomForestTrainer randomForestTrainer,
            ModelEvaluationService evaluationService,
            ModelStorageService storageService,
            ModelVersionRepository modelVersionRepository) {
        this.dataSeeder = dataSeeder;
        this.datasetBuilder = datasetBuilder;
        this.splitter = splitter;
        this.sampleRepository = sampleRepository;
        this.linearTrainer = linearTrainer;
        this.randomForestTrainer = randomForestTrainer;
        this.evaluationService = evaluationService;
        this.storageService = storageService;
        this.modelVersionRepository = modelVersionRepository;
    }

    @Override
    @Transactional
    public TrainModelResponse trainModel(TrainModelRequest request) {
        log.info("Starting RUL model training: algorithm={}, datasetVersion={}",
                request.getAlgorithm(), request.getDatasetVersion());

        Instant startTime = Instant.now();

        // Ensure baseline degradation runs exist
        dataSeeder.seedDegradationRunsIfEmpty();

        // 1. Build supervised dataset
        MlTrainingDataset dataset = datasetBuilder.buildDataset(request.getDatasetVersion());
        List<RulTrainingSample> samples = sampleRepository.findByDatasetId(dataset.getId());

        if (samples.isEmpty()) {
            throw new IllegalStateException("No training samples found in dataset version: " + request.getDatasetVersion());
        }

        // 2. Leakage-free split by run_id
        double ratio = (request.getTrainRatio() != null && request.getTrainRatio() > 0.1 && request.getTrainRatio() < 0.95)
                ? request.getTrainRatio() : 0.75;
        DatasetSplit split = splitter.splitByRun(samples, ratio);

        log.info("Dataset split: trainRuns={}, testRuns={}, trainSamples={}, testSamples={}",
                split.getTrainingRunIds(), split.getTestRunIds(),
                split.getTrainingSet().size(), split.getTestSet().size());

        // 3. Convert to Tribuo datasets
        MutableDataset<Regressor> trainDataset = TribuoDatasetHelper.createDataset(split.getTrainingSet(), "train");
        MutableDataset<Regressor> testDataset = TribuoDatasetHelper.createDataset(split.getTestSet(), "test");

        // 4. Train Model
        Model<Regressor> trainedModel;
        String algoPrefix;
        if (request.getAlgorithm() == ModelAlgorithm.LINEAR_REGRESSION) {
            trainedModel = linearTrainer.train(trainDataset, 25);
            algoPrefix = "RUL-LR";
        } else {
            trainedModel = randomForestTrainer.train(trainDataset, 15);
            algoPrefix = "RUL-RF";
        }

        // 5. Evaluate strictly on holdout test set
        List<Double> actuals = new ArrayList<>();
        List<Double> preds = new ArrayList<>();

        for (var example : testDataset) {
            Prediction<Regressor> pred = trainedModel.predict(example);
            double actual = example.getOutput().getValues()[0];
            double predictedVal = Math.max(0.0, pred.getOutput().getValues()[0]); // RUL >= 0
            actuals.add(actual);
            preds.add(predictedVal);
        }

        EvaluationMetrics metrics = evaluationService.evaluate(actuals, preds);
        log.info("Model evaluation results: MAE={}, RMSE={}, R2={}",
                metrics.getMae(), metrics.getRmse(), metrics.getR2());

        // 6. Save model artifact
        String versionString = algoPrefix + "-v" + (modelVersionRepository.count() + 1) + ".0";
        String artifactPath = storageService.saveModel(versionString, trainedModel);

        // 7. Retire existing active models to ARCHIVED
        List<ModelVersion> activeModels = modelVersionRepository.findByStatus(ModelStatus.ACTIVE);
        for (ModelVersion mv : activeModels) {
            mv.setStatus(ModelStatus.ARCHIVED);
            modelVersionRepository.save(mv);
        }

        // 8. Register new ACTIVE model
        ModelVersion newVersion = ModelVersion.builder()
                .modelName(request.getAlgorithm() == ModelAlgorithm.LINEAR_REGRESSION ? "Linear Regression Baseline" : "Random Forest Regressor")
                .version(versionString)
                .modelType("REGRESSION")
                .algorithm(request.getAlgorithm())
                .featureSchemaVersion("v1")
                .trainingDatasetVersion(request.getDatasetVersion())
                .trainingStartedAt(startTime)
                .trainingCompletedAt(Instant.now())
                .mae(metrics.getMae())
                .rmse(metrics.getRmse())
                .r2(metrics.getR2())
                .trainingSamples(split.getTrainingSet().size())
                .testSamples(split.getTestSet().size())
                .artifactPath(artifactPath)
                .status(ModelStatus.ACTIVE)
                .createdAt(Instant.now())
                .build();

        modelVersionRepository.save(newVersion);

        return TrainModelResponse.builder()
                .modelVersion(versionString)
                .algorithm(request.getAlgorithm())
                .mae(metrics.getMae())
                .rmse(metrics.getRmse())
                .r2(metrics.getR2())
                .trainingSamples(split.getTrainingSet().size())
                .testSamples(split.getTestSet().size())
                .status(ModelStatus.ACTIVE)
                .build();
    }
}
