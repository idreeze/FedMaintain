package com.fedmaintain.ml.explainability.repository;

import com.fedmaintain.ml.explainability.entity.PredictionExplanation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PredictionExplanationRepository extends JpaRepository<PredictionExplanation, Long> {
    List<PredictionExplanation> findByPredictionIdOrderByDeviationPercentageDesc(Long predictionId);
    void deleteByPredictionId(Long predictionId);
}
