package com.fedmaintain.ml.health.service;

import com.fedmaintain.ml.health.dto.MachineHealthResponse;

public interface MachineHealthService {
    MachineHealthResponse calculateHealth(Long machineId);
}
