package com.fedmaintain.ml.prediction.impl;

import com.fedmaintain.exception.ResourceNotFoundException;
import com.fedmaintain.feature.entity.DataQualityState;
import com.fedmaintain.feature.entity.MachineFeature;
import com.fedmaintain.feature.repository.MachineFeatureRepository;
import com.fedmaintain.machine.entity.Machine;
import com.fedmaintain.machine.repository.MachineRepository;
import com.fedmaintain.ml.dto.RulPredictionResponse;
import com.fedmaintain.ml.entity.ModelStatus;
import com.fedmaintain.ml.entity.ModelVersion;
import com.fedmaintain.ml.entity.RulPrediction;
import com.fedmaintain.ml.entity.RulStatus;
import com.fedmaintain.ml.prediction.RulPredictionService;
import com.fedmaintain.ml.repository.ModelVersionRepository;
import com.fedmaintain.ml.repository.RulPredictionRepository;
import com.fedmaintain.ml.service.ModelStorageService;
import com.fedmaintain.ml.training.TribuoDatasetHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.tribuo.Example;
import org.tribuo.Model;
import org.tribuo.Prediction;
import org.tribuo.regression.Regressor;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.List;

@Service
public class RulPredictionServiceImpl implements RulPredictionService {

    private static final Logger log = LoggerFactory.getLogger(RulPredictionServiceImpl.class);

    private final MachineRepository machineRepository;
    private final MachineFeatureRepository featureRepository;
    private final ModelVersionRepository modelVersionRepository;
    private final RulPredictionRepository predictionRepository;
    private final ModelStorageService storageService;

    @Value("${ml.rul.thresholds.normal-hours:72.0}")
    private double normalThreshold;

    @Value("${ml.rul.thresholds.watch-hours:24.0}")
    private double watchThreshold;

    @Value("${ml.rul.thresholds.warning-hours:8.0}")
    private double warningThreshold;

    public RulPredictionServiceImpl(
            MachineRepository machineRepository,
            MachineFeatureRepository featureRepository,
            ModelVersionRepository modelVersionRepository,
            RulPredictionRepository predictionRepository,
            ModelStorageService storageService) {
        this.machineRepository = machineRepository;
        this.featureRepository = featureRepository;
        this.modelVersionRepository = modelVersionRepository;
        this.predictionRepository = predictionRepository;
        this.storageService = storageService;
    }

    @Override
    @Transactional
    public RulPredictionResponse predictForMachine(Long machineId) {
        Machine machine = machineRepository.findById(machineId)
                .orElseThrow(() -> new ResourceNotFoundException("Machine not found with id: " + machineId));

        // 1. Get latest machine features
        MachineFeature latestFeature = featureRepository.findFirstByMachineIdOrderByWindowEndDesc(machineId)
                .orElseThrow(() -> new IllegalStateException("No feature windows found for machine " + machine.getMachineCode() + ". Generate features first."));

        // 2. Validate data quality
        if (latestFeature.getDataQuality() == DataQualityState.INSUFFICIENT) {
            throw new IllegalStateException("Cannot run RUL prediction: latest feature window has INSUFFICIENT data quality.");
        }

        // 3. Load active RUL model
        ModelVersion activeModel = modelVersionRepository.findFirstByStatusOrderByCreatedAtDesc(ModelStatus.ACTIVE)
                .orElseThrow(() -> new IllegalStateException("No ACTIVE RUL model found in registry. Please train an ML model first."));

        @SuppressWarnings("unchecked")
        Model<Regressor> model = (Model<Regressor>) storageService.loadModel(activeModel.getArtifactPath());

        // 4. Construct feature vector and predict
        Example<Regressor> example = TribuoDatasetHelper.createInferenceExample(latestFeature);
        Prediction<Regressor> prediction = model.predict(example);

        double rawRul = prediction.getOutput().getValues()[0];
        double rulHours = BigDecimal.valueOf(Math.max(0.0, rawRul))
                .setScale(2, RoundingMode.HALF_UP)
                .doubleValue();

        // 5. Evaluate RUL status
        RulStatus status = determineRulStatus(rulHours);

        // 6. Persist prediction
        RulPrediction predEntity = RulPrediction.builder()
                .machine(machine)
                .modelVersion(activeModel)
                .predictionTime(Instant.now())
                .rulHours(rulHours)
                .dataQuality(latestFeature.getDataQuality())
                .status(status)
                .createdAt(Instant.now())
                .build();

        predEntity = predictionRepository.save(predEntity);

        log.info("RUL predicted for {}: {} hours, status={}, model={}",
                machine.getMachineCode(), rulHours, status, activeModel.getVersion());

        return RulPredictionResponse.fromEntity(predEntity);
    }

    private RulStatus determineRulStatus(double rulHours) {
        if (rulHours >= normalThreshold) {
            return RulStatus.NORMAL;
        } else if (rulHours >= watchThreshold) {
            return RulStatus.WATCH;
        } else if (rulHours >= warningThreshold) {
            return RulStatus.WARNING;
        } else {
            return RulStatus.CRITICAL;
        }
    }

    @Override
    @Transactional(readOnly = true)
    public RulPredictionResponse getLatestPrediction(Long machineId) {
        return predictionRepository.findFirstByMachineIdOrderByPredictionTimeDesc(machineId)
                .map(RulPredictionResponse::fromEntity)
                .orElse(null);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<RulPredictionResponse> getHistoricalPredictions(Long machineId, Pageable pageable) {
        return predictionRepository.findByMachineIdOrderByPredictionTimeDesc(machineId, pageable)
                .map(RulPredictionResponse::fromEntity);
    }

    @Override
    @Transactional(readOnly = true)
    public List<RulPredictionResponse> getRecentPredictions(Long machineId) {
        return predictionRepository.findTop30ByMachineIdOrderByPredictionTimeDesc(machineId).stream()
                .map(RulPredictionResponse::fromEntity)
                .toList();
    }
}
