package com.fedmaintain.ml.dto;

import com.fedmaintain.feature.entity.DataQualityState;
import com.fedmaintain.ml.entity.RulPrediction;
import com.fedmaintain.ml.entity.RulStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RulPredictionResponse {
    private Long id;
    private Long machineId;
    private String machineCode;
    private String modelVersion;
    private Instant predictionTime;
    private Double rulHours;
    private RulStatus status;
    private DataQualityState dataQuality;

    public static RulPredictionResponse fromEntity(RulPrediction p) {
        if (p == null) return null;
        return RulPredictionResponse.builder()
                .id(p.getId())
                .machineId(p.getMachine() != null ? p.getMachine().getId() : null)
                .machineCode(p.getMachine() != null ? p.getMachine().getMachineCode() : null)
                .modelVersion(p.getModelVersion() != null ? p.getModelVersion().getVersion() : "UNKNOWN")
                .predictionTime(p.getPredictionTime())
                .rulHours(p.getRulHours())
                .status(p.getStatus())
                .dataQuality(p.getDataQuality())
                .build();
    }
}
