package com.fedmaintain.ml.prediction;

import com.fedmaintain.ml.dto.RulPredictionResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface RulPredictionService {
    RulPredictionResponse predictForMachine(Long machineId);
    RulPredictionResponse getLatestPrediction(Long machineId);
    Page<RulPredictionResponse> getHistoricalPredictions(Long machineId, Pageable pageable);
    List<RulPredictionResponse> getRecentPredictions(Long machineId);
}
