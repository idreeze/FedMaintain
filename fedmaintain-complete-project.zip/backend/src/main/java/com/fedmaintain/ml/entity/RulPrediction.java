package com.fedmaintain.ml.entity;

import com.fedmaintain.feature.entity.DataQualityState;
import com.fedmaintain.machine.entity.Machine;
import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;

@Entity
@Table(
        name = "rul_predictions",
        indexes = {
                @Index(name = "idx_rul_predictions_machine_time", columnList = "machine_id, prediction_time DESC")
        }
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RulPrediction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "machine_id", nullable = false)
    private Machine machine;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "model_version_id")
    private ModelVersion modelVersion;

    @Column(name = "prediction_time", nullable = false)
    private Instant predictionTime;

    @Column(name = "rul_hours", nullable = false)
    private Double rulHours;

    @Enumerated(EnumType.STRING)
    @Column(name = "data_quality", nullable = false, length = 20)
    @Builder.Default
    private DataQualityState dataQuality = DataQualityState.GOOD;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    @Builder.Default
    private RulStatus status = RulStatus.NORMAL;

    @Column(name = "created_at", nullable = false)
    @Builder.Default
    private Instant createdAt = Instant.now();
}
