package com.fedmaintain.ml.dataset;

import com.fedmaintain.feature.entity.DataQualityState;
import com.fedmaintain.feature.entity.MachineFeature;
import com.fedmaintain.feature.repository.MachineFeatureRepository;
import com.fedmaintain.ml.entity.MachineRun;
import com.fedmaintain.ml.entity.MlTrainingDataset;
import com.fedmaintain.ml.entity.RulTrainingSample;
import com.fedmaintain.ml.repository.MachineRunRepository;
import com.fedmaintain.ml.repository.MlTrainingDatasetRepository;
import com.fedmaintain.ml.repository.RulTrainingSampleRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@Component
public class RulDatasetBuilder {

    private static final Logger log = LoggerFactory.getLogger(RulDatasetBuilder.class);

    private final MachineRunRepository machineRunRepository;
    private final MachineFeatureRepository machineFeatureRepository;
    private final MlTrainingDatasetRepository datasetRepository;
    private final RulTrainingSampleRepository sampleRepository;

    public RulDatasetBuilder(
            MachineRunRepository machineRunRepository,
            MachineFeatureRepository machineFeatureRepository,
            MlTrainingDatasetRepository datasetRepository,
            RulTrainingSampleRepository sampleRepository) {
        this.machineRunRepository = machineRunRepository;
        this.machineFeatureRepository = machineFeatureRepository;
        this.datasetRepository = datasetRepository;
        this.sampleRepository = sampleRepository;
    }

    /**
     * Constructs an ML training dataset with synthetic RUL labels:
     * RUL hours = (failure_timestamp - window_end) / 3600.0
     *
     * Strict Validation & Leakage Prevention:
     * - Excludes windows where window_end > failure_timestamp
     * - Excludes windows with INSUFFICIENT data quality
     * - Never uses failure_timestamp as an input feature
     * - Never uses rul_hours as an input feature
     */
    @Transactional
    public MlTrainingDataset buildDataset(String datasetVersion) {
        MlTrainingDataset dataset = datasetRepository.findByDatasetVersion(datasetVersion)
                .orElseGet(() -> datasetRepository.save(MlTrainingDataset.builder()
                        .datasetVersion(datasetVersion)
                        .datasetType("RUL_SUPERVISED")
                        .featureSchemaVersion("v1")
                        .machineCount(0)
                        .sampleCount(0)
                        .createdAt(Instant.now())
                        .build()));

        List<MachineRun> completedRuns = machineRunRepository.findByFailureTimestampIsNotNull();
        if (completedRuns.isEmpty()) {
            log.warn("No completed degradation runs found with failure_timestamp ground truth");
            return dataset;
        }

        List<RulTrainingSample> newSamples = new ArrayList<>();

        for (MachineRun run : completedRuns) {
            Instant failureTime = run.getFailureTimestamp();
            if (failureTime == null) {
                continue;
            }

            // Find features belonging to this run interval [start_time, failure_timestamp]
            List<MachineFeature> features = machineFeatureRepository.findFeaturesInWindow(
                    run.getMachine().getId(), run.getStartTime(), failureTime);

            for (MachineFeature mf : features) {
                // Reject invalid or post-failure windows
                if (mf.getWindowEnd().isAfter(failureTime)) {
                    continue;
                }
                if (mf.getDataQuality() == DataQualityState.INSUFFICIENT) {
                    continue;
                }

                // RUL hours calculation
                long secondsToFailure = Duration.between(mf.getWindowEnd(), failureTime).getSeconds();
                double rulHours = BigDecimal.valueOf(secondsToFailure / 3600.0)
                        .setScale(2, RoundingMode.HALF_UP)
                        .doubleValue();

                RulTrainingSample sample = RulTrainingSample.builder()
                        .dataset(dataset)
                        .machine(run.getMachine())
                        .runId(run.getRunId())
                        .windowStart(mf.getWindowStart())
                        .windowEnd(mf.getWindowEnd())
                        .temperatureMean(mf.getTemperatureMean())
                        .temperatureStd(mf.getTemperatureStd())
                        .temperatureMax(mf.getTemperatureMax())
                        .temperatureTrend(mf.getTemperatureTrend())
                        .temperatureDeviationPct(mf.getTemperatureDeviationPct())
                        .vibrationMean(mf.getVibrationMean())
                        .vibrationStd(mf.getVibrationStd())
                        .vibrationRms(mf.getVibrationRms())
                        .vibrationTrend(mf.getVibrationTrend())
                        .vibrationDeviationPct(mf.getVibrationDeviationPct())
                        .currentMean(mf.getCurrentMean())
                        .currentStd(mf.getCurrentStd())
                        .currentTrend(mf.getCurrentTrend())
                        .currentDeviationPct(mf.getCurrentDeviationPct())
                        .pressureMean(mf.getPressureMean())
                        .pressureTrend(mf.getPressureTrend())
                        .rpmMean(mf.getRpmMean())
                        .rpmTrend(mf.getRpmTrend())
                        .acousticMean(mf.getAcousticMean())
                        .acousticTrend(mf.getAcousticTrend())
                        .rulHours(rulHours)
                        .dataQuality(mf.getDataQuality())
                        .createdAt(Instant.now())
                        .build();

                newSamples.add(sample);
            }
        }

        if (!newSamples.isEmpty()) {
            sampleRepository.saveAll(newSamples);
            dataset.setSampleCount(newSamples.size());
            dataset.setMachineCount((int) newSamples.stream()
                    .map(s -> s.getMachine().getId())
                    .distinct()
                    .count());
            dataset = datasetRepository.save(dataset);
        }

        return dataset;
    }
}
