package com.fedmaintain.ml.health.dto;

import com.fedmaintain.ml.explainability.entity.ContributionLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class HealthFactorDto {
    private String feature;
    private ContributionLevel level;
    private Double value;
    private Double baseline;
    private Double deviationPercentage;
}
