package com.fedmaintain.ml.dto;

import com.fedmaintain.ml.entity.ModelAlgorithm;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TrainModelRequest {
    @Builder.Default
    private String datasetVersion = "v1";
    @Builder.Default
    private ModelAlgorithm algorithm = ModelAlgorithm.RANDOM_FOREST;
    @Builder.Default
    private Double trainRatio = 0.75;
}
