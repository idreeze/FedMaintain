package com.fedmaintain.ml.health.service.impl;

import com.fedmaintain.exception.ResourceNotFoundException;
import com.fedmaintain.feature.entity.MachineBaseline;
import com.fedmaintain.feature.entity.MachineFeature;
import com.fedmaintain.feature.repository.MachineFeatureRepository;
import com.fedmaintain.feature.service.MachineBaselineService;
import com.fedmaintain.machine.entity.Machine;
import com.fedmaintain.machine.repository.MachineRepository;
import com.fedmaintain.ml.entity.RulPrediction;
import com.fedmaintain.ml.explainability.entity.ContributionLevel;
import com.fedmaintain.ml.health.dto.HealthFactorDto;
import com.fedmaintain.ml.health.dto.MachineHealthResponse;
import com.fedmaintain.ml.health.entity.HealthStatus;
import com.fedmaintain.ml.health.service.MachineHealthService;
import com.fedmaintain.ml.repository.RulPredictionRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@Service
public class MachineHealthServiceImpl implements MachineHealthService {

    private static final Logger log = LoggerFactory.getLogger(MachineHealthServiceImpl.class);

    private final MachineRepository machineRepository;
    private final MachineFeatureRepository featureRepository;
    private final MachineBaselineService baselineService;
    private final RulPredictionRepository predictionRepository;

    @Value("${health-score.vibration-weight:0.30}")
    private double vibrationWeight;

    @Value("${health-score.temperature-weight:0.20}")
    private double temperatureWeight;

    @Value("${health-score.current-weight:0.15}")
    private double currentWeight;

    @Value("${health-score.pressure-weight:0.10}")
    private double pressureWeight;

    @Value("${health-score.rpm-weight:0.10}")
    private double rpmWeight;

    @Value("${health-score.rul-weight:0.15}")
    private double rulWeight;

    public MachineHealthServiceImpl(
            MachineRepository machineRepository,
            MachineFeatureRepository featureRepository,
            MachineBaselineService baselineService,
            RulPredictionRepository predictionRepository) {
        this.machineRepository = machineRepository;
        this.featureRepository = featureRepository;
        this.baselineService = baselineService;
        this.predictionRepository = predictionRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public MachineHealthResponse calculateHealth(Long machineId) {
        Machine machine = machineRepository.findById(machineId)
                .orElseThrow(() -> new ResourceNotFoundException("Machine not found with id: " + machineId));

        MachineFeature feature = featureRepository.findFirstByMachineIdOrderByWindowEndDesc(machineId)
                .orElse(null);
        MachineBaseline baseline = baselineService.getOrCreateBaseline(machineId);
        RulPrediction pred = predictionRepository.findFirstByMachineIdOrderByPredictionTimeDesc(machineId)
                .orElse(null);

        double vibScore = 100.0;
        double tempScore = 100.0;
        double currScore = 100.0;
        double pressScore = 100.0;
        double rpmScore = 100.0;
        double rulScore = 100.0;

        List<HealthFactorDto> factors = new ArrayList<>();

        if (feature != null) {
            // Vibration (1.5 healthy -> 12.0 mm/s failure)
            double vib = (feature.getVibrationRms() != null) ? feature.getVibrationRms() : baseline.getBaselineVibration();
            vibScore = calculateSubScore(vib, baseline.getBaselineVibration(), 12.0);
            factors.add(createFactor("vibration_rms", vib, baseline.getBaselineVibration()));

            // Temperature (50 C healthy -> 95 C failure)
            double temp = (feature.getTemperatureMean() != null) ? feature.getTemperatureMean() : baseline.getBaselineTemperature();
            tempScore = calculateSubScore(temp, baseline.getBaselineTemperature(), 95.0);
            factors.add(createFactor("temperature_mean", temp, baseline.getBaselineTemperature()));

            // Current (16 A healthy -> 46 A failure)
            double curr = (feature.getCurrentMean() != null) ? feature.getCurrentMean() : baseline.getBaselineCurrent();
            currScore = calculateSubScore(curr, baseline.getBaselineCurrent(), 46.0);
            factors.add(createFactor("current_mean", curr, baseline.getBaselineCurrent()));

            // Pressure (45 psi healthy -> 85 psi failure)
            double press = (feature.getPressureMean() != null) ? feature.getPressureMean() : baseline.getBaselinePressure();
            pressScore = calculateSubScore(press, baseline.getBaselinePressure(), 85.0);
            factors.add(createFactor("pressure_mean", press, baseline.getBaselinePressure()));

            // RPM (1800 healthy -> 1100 failure)
            double rpm = (feature.getRpmMean() != null) ? feature.getRpmMean() : baseline.getBaselineRpm();
            rpmScore = calculateSubScore(Math.abs(1800.0 - rpm), 0.0, 700.0);
            factors.add(createFactor("rpm_mean", rpm, baseline.getBaselineRpm()));
        }

        Double rulHours = (pred != null) ? pred.getRulHours() : 72.0;
        rulScore = Math.max(0.0, Math.min(100.0, (rulHours / 72.0) * 100.0));

        // Weighted Average
        double totalScore = (vibScore * vibrationWeight) +
                            (tempScore * temperatureWeight) +
                            (currScore * currentWeight) +
                            (pressScore * pressureWeight) +
                            (rpmScore * rpmWeight) +
                            (rulScore * rulWeight);

        int healthScore = (int) Math.max(0, Math.min(100, Math.round(totalScore)));
        HealthStatus status = mapStatus(healthScore);

        // Sort factors by highest degradation
        factors.sort((a, b) -> Double.compare(b.getDeviationPercentage(), a.getDeviationPercentage()));

        return MachineHealthResponse.builder()
                .machineId(machine.getMachineCode())
                .healthScore(healthScore)
                .status(status)
                .rulHours(rulHours)
                .calculatedAt(Instant.now())
                .factors(factors)
                .build();
    }

    private double calculateSubScore(double val, double healthyBase, double failLimit) {
        if (val <= healthyBase) {
            return 100.0;
        }
        if (val >= failLimit) {
            return 0.0;
        }
        double ratio = (val - healthyBase) / (failLimit - healthyBase);
        return Math.max(0.0, Math.min(100.0, (1.0 - ratio) * 100.0));
    }

    private HealthFactorDto createFactor(String name, double val, double baseline) {
        double diff = Math.abs(val - baseline);
        double devPct = Math.abs(baseline) > 1e-6 ? (diff / baseline) * 100.0 : diff;
        ContributionLevel level;
        if (devPct >= 80.0) {
            level = ContributionLevel.CRITICAL;
        } else if (devPct >= 40.0) {
            level = ContributionLevel.HIGH;
        } else if (devPct >= 15.0) {
            level = ContributionLevel.MEDIUM;
        } else {
            level = ContributionLevel.LOW;
        }

        return HealthFactorDto.builder()
                .feature(name)
                .level(level)
                .value(Math.round(val * 100.0) / 100.0)
                .baseline(Math.round(baseline * 100.0) / 100.0)
                .deviationPercentage(Math.round(devPct * 100.0) / 100.0)
                .build();
    }

    private HealthStatus mapStatus(int score) {
        if (score >= 80) {
            return HealthStatus.HEALTHY;
        } else if (score >= 60) {
            return HealthStatus.WATCH;
        } else if (score >= 30) {
            return HealthStatus.WARNING;
        } else {
            return HealthStatus.CRITICAL;
        }
    }
}
