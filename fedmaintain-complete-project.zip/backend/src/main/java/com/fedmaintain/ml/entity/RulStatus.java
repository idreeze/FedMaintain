package com.fedmaintain.ml.entity;

public enum RulStatus {
    NORMAL,
    WATCH,
    WARNING,
    CRITICAL
}
