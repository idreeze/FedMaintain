package com.fedmaintain.ml.entity;

public enum ModelAlgorithm {
    LINEAR_REGRESSION,
    RANDOM_FOREST
}
