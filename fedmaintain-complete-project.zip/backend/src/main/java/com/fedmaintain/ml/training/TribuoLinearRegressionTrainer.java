package com.fedmaintain.ml.training;

import org.springframework.stereotype.Component;
import org.tribuo.Dataset;
import org.tribuo.Model;
import org.tribuo.math.optimisers.AdaGrad;
import org.tribuo.regression.Regressor;
import org.tribuo.regression.sgd.linear.LinearSGDTrainer;
import org.tribuo.regression.sgd.objectives.SquaredLoss;

@Component
public class TribuoLinearRegressionTrainer {

    public Model<Regressor> train(Dataset<Regressor> dataset, int epochs) {
        LinearSGDTrainer trainer = new LinearSGDTrainer(
                new SquaredLoss(),
                new AdaGrad(0.01),
                Math.max(5, epochs),
                1L);
        return trainer.train(dataset);
    }
}
