package com.fedmaintain.ml.controller;

import com.fedmaintain.common.ApiResponse;
import com.fedmaintain.ml.dto.TrainModelRequest;
import com.fedmaintain.ml.dto.TrainModelResponse;
import com.fedmaintain.ml.service.ModelTrainingService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/ml")
public class TrainingController {

    private final ModelTrainingService trainingService;

    public TrainingController(ModelTrainingService trainingService) {
        this.trainingService = trainingService;
    }

    @PostMapping("/train/rul")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<TrainModelResponse>> trainRulModel(
            @RequestBody(required = false) TrainModelRequest request) {
        if (request == null) {
            request = new TrainModelRequest();
        }
        TrainModelResponse response = trainingService.trainModel(request);
        return ResponseEntity.ok(ApiResponse.success("Model trained and activated successfully", response));
    }
}
