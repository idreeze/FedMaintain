package com.fedmaintain.ml.repository;

import com.fedmaintain.ml.entity.ModelStatus;
import com.fedmaintain.ml.entity.ModelVersion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ModelVersionRepository extends JpaRepository<ModelVersion, Long> {
    Optional<ModelVersion> findByVersion(String version);
    Optional<ModelVersion> findFirstByStatusOrderByCreatedAtDesc(ModelStatus status);
    List<ModelVersion> findByStatus(ModelStatus status);
    List<ModelVersion> findAllByOrderByCreatedAtDesc();
}
