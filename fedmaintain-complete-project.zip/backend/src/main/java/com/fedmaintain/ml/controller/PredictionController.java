package com.fedmaintain.ml.controller;

import com.fedmaintain.common.ApiResponse;
import com.fedmaintain.common.PageResponse;
import com.fedmaintain.ml.dto.RulPredictionResponse;
import com.fedmaintain.ml.prediction.RulPredictionService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class PredictionController {

    private final RulPredictionService predictionService;

    public PredictionController(RulPredictionService predictionService) {
        this.predictionService = predictionService;
    }

    @PostMapping("/ml/predict/{machineId}")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER')")
    public ResponseEntity<ApiResponse<RulPredictionResponse>> predictRul(@PathVariable Long machineId) {
        RulPredictionResponse response = predictionService.predictForMachine(machineId);
        return ResponseEntity.ok(ApiResponse.success("RUL predicted successfully", response));
    }

    @GetMapping("/machines/{id}/rul/latest")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER', 'OPERATOR')")
    public ResponseEntity<ApiResponse<RulPredictionResponse>> getLatestRul(@PathVariable Long id) {
        RulPredictionResponse latest = predictionService.getLatestPrediction(id);
        return ResponseEntity.ok(ApiResponse.success(latest));
    }

    @GetMapping("/machines/{id}/rul")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER', 'OPERATOR')")
    public ResponseEntity<ApiResponse<PageResponse<RulPredictionResponse>>> getHistoricalRul(
            @PathVariable Long id,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        Page<RulPredictionResponse> predictions = predictionService.getHistoricalPredictions(
                id, PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "predictionTime")));
        return ResponseEntity.ok(ApiResponse.success(PageResponse.fromPage(predictions)));
    }

    @GetMapping("/machines/{id}/rul/recent")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER', 'OPERATOR')")
    public ResponseEntity<ApiResponse<List<RulPredictionResponse>>> getRecentRul(@PathVariable Long id) {
        List<RulPredictionResponse> list = predictionService.getRecentPredictions(id);
        return ResponseEntity.ok(ApiResponse.success(list));
    }
}
