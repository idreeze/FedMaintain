package com.fedmaintain.ml.entity;

public enum ModelStatus {
    TRAINING,
    ACTIVE,
    ARCHIVED,
    FAILED
}
