package com.fedmaintain.ml.service;

import com.fedmaintain.ml.dto.TrainModelRequest;
import com.fedmaintain.ml.dto.TrainModelResponse;

public interface ModelTrainingService {
    TrainModelResponse trainModel(TrainModelRequest request);
}
