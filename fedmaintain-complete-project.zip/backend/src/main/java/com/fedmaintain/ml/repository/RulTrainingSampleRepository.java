package com.fedmaintain.ml.repository;

import com.fedmaintain.ml.entity.RulTrainingSample;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RulTrainingSampleRepository extends JpaRepository<RulTrainingSample, Long> {
    List<RulTrainingSample> findByDatasetId(Long datasetId);

    @Query("SELECT DISTINCT s.runId FROM RulTrainingSample s WHERE s.dataset.id = :datasetId")
    List<String> findDistinctRunIdsByDatasetId(@Param("datasetId") Long datasetId);

    List<RulTrainingSample> findByDatasetIdAndRunIdIn(Long datasetId, List<String> runIds);
}
