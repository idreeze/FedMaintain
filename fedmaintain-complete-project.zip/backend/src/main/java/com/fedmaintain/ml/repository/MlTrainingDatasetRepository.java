package com.fedmaintain.ml.repository;

import com.fedmaintain.ml.entity.MlTrainingDataset;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface MlTrainingDatasetRepository extends JpaRepository<MlTrainingDataset, Long> {
    Optional<MlTrainingDataset> findByDatasetVersion(String datasetVersion);
    boolean existsByDatasetVersion(String datasetVersion);
}
