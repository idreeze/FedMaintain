package com.fedmaintain.ml.health.controller;

import com.fedmaintain.alert.dto.AlertResponse;
import com.fedmaintain.alert.dto.RecommendationResponse;
import com.fedmaintain.alert.service.PredictiveAlertService;
import com.fedmaintain.alert.service.RecommendationService;
import com.fedmaintain.common.ApiResponse;
import com.fedmaintain.ml.explainability.dto.ExplanationResponse;
import com.fedmaintain.ml.explainability.service.ExplainabilityService;
import com.fedmaintain.ml.health.dto.MachineHealthResponse;
import com.fedmaintain.ml.health.service.MachineHealthService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/machines")
public class MachineHealthController {

    private final MachineHealthService healthService;
    private final ExplainabilityService explainabilityService;
    private final RecommendationService recommendationService;
    private final PredictiveAlertService alertService;

    public MachineHealthController(
            MachineHealthService healthService,
            ExplainabilityService explainabilityService,
            RecommendationService recommendationService,
            PredictiveAlertService alertService) {
        this.healthService = healthService;
        this.explainabilityService = explainabilityService;
        this.recommendationService = recommendationService;
        this.alertService = alertService;
    }

    @GetMapping("/{id}/health")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER', 'OPERATOR')")
    public ResponseEntity<ApiResponse<MachineHealthResponse>> getMachineHealth(@PathVariable Long id) {
        MachineHealthResponse response = healthService.calculateHealth(id);
        return ResponseEntity.ok(ApiResponse.success(response));
    }

    @GetMapping("/{id}/explanations/latest")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER', 'OPERATOR')")
    public ResponseEntity<ApiResponse<ExplanationResponse>> getLatestExplanation(@PathVariable Long id) {
        ExplanationResponse response = explainabilityService.getLatestExplanation(id);
        return ResponseEntity.ok(ApiResponse.success(response));
    }

    @GetMapping("/{id}/recommendations")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER', 'OPERATOR')")
    public ResponseEntity<ApiResponse<RecommendationResponse>> getRecommendations(@PathVariable Long id) {
        RecommendationResponse response = recommendationService.getRecommendationsForMachine(id);
        return ResponseEntity.ok(ApiResponse.success(response));
    }

    @GetMapping("/{id}/alerts")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER', 'OPERATOR')")
    public ResponseEntity<ApiResponse<List<AlertResponse>>> getMachineAlerts(@PathVariable Long id) {
        List<AlertResponse> alerts = alertService.getActiveAlertsForMachine(id);
        return ResponseEntity.ok(ApiResponse.success(alerts));
    }
}
