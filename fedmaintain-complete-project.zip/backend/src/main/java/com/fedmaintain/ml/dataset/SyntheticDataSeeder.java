package com.fedmaintain.ml.dataset;

import com.fedmaintain.feature.entity.DataQualityState;
import com.fedmaintain.feature.entity.MachineFeature;
import com.fedmaintain.feature.repository.MachineFeatureRepository;
import com.fedmaintain.machine.entity.Machine;
import com.fedmaintain.machine.repository.MachineRepository;
import com.fedmaintain.ml.entity.MachineRun;
import com.fedmaintain.ml.repository.MachineRunRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Generates synthetic semiconductor equipment degradation lifecycles.
 * Clearly documented as synthetic benchmark ground truth for predictive maintenance validation.
 */
@Component
public class SyntheticDataSeeder {

    private static final Logger log = LoggerFactory.getLogger(SyntheticDataSeeder.class);
    private final MachineRepository machineRepository;
    private final MachineRunRepository machineRunRepository;
    private final MachineFeatureRepository featureRepository;
    private final Random random = new Random(42);

    public SyntheticDataSeeder(
            MachineRepository machineRepository,
            MachineRunRepository machineRunRepository,
            MachineFeatureRepository featureRepository) {
        this.machineRepository = machineRepository;
        this.machineRunRepository = machineRunRepository;
        this.featureRepository = featureRepository;
    }

    @Transactional
    public void seedDegradationRunsIfEmpty() {
        if (machineRunRepository.count() > 0) {
            return;
        }

        List<Machine> machines = machineRepository.findAll();
        if (machines.isEmpty()) {
            return;
        }

        log.info("Seeding synthetic semiconductor degradation runs and feature lifecycles...");

        Instant now = Instant.now();

        // Create 5 distinct degradation runs across machines
        String[] runCodes = {
                "RUN-CMP001-CYCLE-01",
                "RUN-CMP001-CYCLE-02",
                "RUN-CMP001-CYCLE-03",
                "RUN-ETCH001-CYCLE-01",
                "RUN-ETCH001-CYCLE-02"
        };

        Machine cmp = machines.get(0);
        Machine etch = machines.size() > 1 ? machines.get(1) : cmp;

        for (int i = 0; i < runCodes.length; i++) {
            String runId = runCodes[i];
            Machine targetMachine = (i < 3) ? cmp : etch;

            // Run duration: 48 hours. Disjoint non-overlapping intervals per machine.
            int cycleIndex = (i < 3) ? i : (i - 3);
            long startHoursAgo = 160 - (cycleIndex * 52);
            Instant runStart = now.minus(startHoursAgo, ChronoUnit.HOURS);
            Instant runFailure = runStart.plus(48, ChronoUnit.HOURS);

            MachineRun run = MachineRun.builder()
                    .runId(runId)
                    .machine(targetMachine)
                    .startTime(runStart)
                    .failureTimestamp(runFailure)
                    .status("COMPLETED")
                    .notes("Synthetic degradation lifecycle (NORMAL -> DEGRADING -> CRITICAL -> FAILURE) for semiconductor tool " + targetMachine.getMachineCode())
                    .createdAt(Instant.now())
                    .build();
            machineRunRepository.save(run);

            // Generate 30-minute windows with 2-hour increments across the 48-hour degradation curve
            Instant curStart = runStart;
            while (curStart.plus(30, ChronoUnit.MINUTES).isBefore(runFailure)) {
                Instant curEnd = curStart.plus(30, ChronoUnit.MINUTES);

                // Progress ratio along degradation cycle: 0.0 (fresh) -> 1.0 (failure)
                double progress = (double) Duration.between(runStart, curEnd).toMillis() / Duration.between(runStart, runFailure).toMillis();

                double tempMean = round(50.0 + (progress * 42.0) + (random.nextDouble() * 2.0), 2); // 50 -> 92 C
                double tempStd = round(0.5 + (progress * 3.5), 2);
                double tempTrend = round(0.01 + (progress * 0.25), 4);
                double tempDev = round(((tempMean - 50.0) / 50.0) * 100.0, 2);

                double vibMean = round(1.5 + (progress * 11.5) + (random.nextDouble() * 0.5), 2); // 1.5 -> 13.0 mm/s
                double vibStd = round(0.2 + (progress * 1.8), 2);
                double vibRms = round(vibMean * 1.08, 2);
                double vibTrend = round(0.005 + (progress * 0.15), 4);
                double vibDev = round(((vibMean - 1.5) / 1.5) * 100.0, 2);

                double currMean = round(16.0 + (progress * 30.0) + (random.nextDouble() * 1.0), 2); // 16 -> 46 A
                double currStd = round(0.4 + (progress * 2.5), 2);
                double currTrend = round(0.01 + (progress * 0.12), 4);
                double currDev = round(((currMean - 16.0) / 16.0) * 100.0, 2);

                double pressMean = round(45.0 + (progress * 40.0), 2);
                double pressTrend = round(0.02 + (progress * 0.10), 4);

                double rpmMean = round(1800.0 - (progress * 700.0), 2); // 1800 -> 1100 RPM
                double rpmTrend = round(-0.1 - (progress * 1.5), 4);

                double acoMean = round(52.0 + (progress * 48.0), 2); // 52 -> 100 dB
                double acoTrend = round(0.02 + (progress * 0.20), 4);

                MachineFeature feature = MachineFeature.builder()
                        .machine(targetMachine)
                        .windowStart(curStart)
                        .windowEnd(curEnd)
                        .temperatureMean(tempMean)
                        .temperatureStd(tempStd)
                        .temperatureMin(round(tempMean - tempStd, 2))
                        .temperatureMax(round(tempMean + tempStd, 2))
                        .temperatureRange(round(tempStd * 2, 2))
                        .temperatureTrend(tempTrend)
                        .temperatureDeviationPct(tempDev)
                        .vibrationMean(vibMean)
                        .vibrationStd(vibStd)
                        .vibrationMin(round(vibMean - vibStd, 2))
                        .vibrationMax(round(vibMean + vibStd, 2))
                        .vibrationRange(round(vibStd * 2, 2))
                        .vibrationRms(vibRms)
                        .vibrationTrend(vibTrend)
                        .vibrationDeviationPct(vibDev)
                        .currentMean(currMean)
                        .currentStd(currStd)
                        .currentMin(round(currMean - currStd, 2))
                        .currentMax(round(currMean + currStd, 2))
                        .currentRange(round(currStd * 2, 2))
                        .currentTrend(currTrend)
                        .currentDeviationPct(currDev)
                        .pressureMean(pressMean)
                        .pressureStd(round(1.0 + progress * 2.0, 2))
                        .pressureMin(round(pressMean - 2.0, 2))
                        .pressureMax(round(pressMean + 2.0, 2))
                        .pressureTrend(pressTrend)
                        .rpmMean(rpmMean)
                        .rpmStd(round(10.0 + progress * 40.0, 2))
                        .rpmMin(round(rpmMean - 30.0, 2))
                        .rpmMax(round(rpmMean + 30.0, 2))
                        .rpmTrend(rpmTrend)
                        .acousticMean(acoMean)
                        .acousticStd(round(1.0 + progress * 3.0, 2))
                        .acousticMax(round(acoMean + 5.0, 2))
                        .acousticTrend(acoTrend)
                        .dataQuality(DataQualityState.GOOD)
                        .readingCount(60)
                        .createdAt(Instant.now())
                        .build();

                if (!featureRepository.existsByMachineIdAndWindowStartAndWindowEnd(targetMachine.getId(), curStart, curEnd)) {
                    featureRepository.save(feature);
                }
                curStart = curStart.plus(2, ChronoUnit.HOURS);
            }
        }

        log.info("Successfully seeded 5 synthetic degradation runs with 120 feature windows across 2 semiconductor tools.");
    }

    private double round(double val, int places) {
        return BigDecimal.valueOf(val).setScale(places, RoundingMode.HALF_UP).doubleValue();
    }
}
