package com.fedmaintain.ml.explainability.service;

import com.fedmaintain.ml.explainability.dto.ExplanationResponse;

public interface ExplainabilityService {
    ExplanationResponse generateExplanation(Long predictionId);
    ExplanationResponse getLatestExplanation(Long machineId);
}
