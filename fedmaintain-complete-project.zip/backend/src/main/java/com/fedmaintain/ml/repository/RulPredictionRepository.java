package com.fedmaintain.ml.repository;

import com.fedmaintain.ml.entity.RulPrediction;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface RulPredictionRepository extends JpaRepository<RulPrediction, Long> {
    Page<RulPrediction> findByMachineIdOrderByPredictionTimeDesc(Long machineId, Pageable pageable);
    Optional<RulPrediction> findFirstByMachineIdOrderByPredictionTimeDesc(Long machineId);
    List<RulPrediction> findTop30ByMachineIdOrderByPredictionTimeDesc(Long machineId);
}
