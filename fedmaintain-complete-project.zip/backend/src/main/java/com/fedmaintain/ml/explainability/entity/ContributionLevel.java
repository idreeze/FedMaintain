package com.fedmaintain.ml.explainability.entity;

public enum ContributionLevel {
    LOW,
    MEDIUM,
    HIGH,
    CRITICAL
}
