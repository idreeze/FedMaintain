package com.fedmaintain.ml.training;

import org.springframework.stereotype.Component;
import org.tribuo.Dataset;
import org.tribuo.Model;
import org.tribuo.common.tree.RandomForestTrainer;
import org.tribuo.regression.Regressor;
import org.tribuo.regression.ensemble.AveragingCombiner;
import org.tribuo.regression.rtree.CARTRegressionTrainer;

import org.tribuo.regression.rtree.impurity.MeanSquaredError;

@Component
public class TribuoRandomForestTrainer {

    public Model<Regressor> train(Dataset<Regressor> dataset, int numTrees) {
        CARTRegressionTrainer subTrainer = new CARTRegressionTrainer(
                8,
                5.0f,
                0.0f,
                0.7f,
                new MeanSquaredError(),
                42L);
        AveragingCombiner combiner = new AveragingCombiner();
        RandomForestTrainer<Regressor> trainer = new RandomForestTrainer<>(
                subTrainer,
                combiner,
                Math.max(5, numTrees),
                42L);
        return trainer.train(dataset);
    }
}
