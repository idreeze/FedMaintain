package com.fedmaintain.ml.explainability.entity;

public enum DeviationDirection {
    POSITIVE,
    NEGATIVE,
    NEUTRAL
}
