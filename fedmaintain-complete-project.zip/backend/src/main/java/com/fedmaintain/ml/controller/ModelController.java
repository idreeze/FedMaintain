package com.fedmaintain.ml.controller;

import com.fedmaintain.common.ApiResponse;
import com.fedmaintain.exception.ResourceNotFoundException;
import com.fedmaintain.ml.dto.ModelVersionResponse;
import com.fedmaintain.ml.entity.ModelStatus;
import com.fedmaintain.ml.entity.ModelVersion;
import com.fedmaintain.ml.repository.ModelVersionRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/ml/models")
public class ModelController {

    private final ModelVersionRepository modelVersionRepository;

    public ModelController(ModelVersionRepository modelVersionRepository) {
        this.modelVersionRepository = modelVersionRepository;
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER')")
    public ResponseEntity<ApiResponse<List<ModelVersionResponse>>> getAllModels() {
        List<ModelVersionResponse> list = modelVersionRepository.findAllByOrderByCreatedAtDesc().stream()
                .map(ModelVersionResponse::fromEntity)
                .toList();
        return ResponseEntity.ok(ApiResponse.success(list));
    }

    @GetMapping("/active")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER')")
    public ResponseEntity<ApiResponse<ModelVersionResponse>> getActiveModel() {
        ModelVersion mv = modelVersionRepository.findFirstByStatusOrderByCreatedAtDesc(ModelStatus.ACTIVE)
                .orElseThrow(() -> new ResourceNotFoundException("No ACTIVE model found in registry"));
        return ResponseEntity.ok(ApiResponse.success(ModelVersionResponse.fromEntity(mv)));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER')")
    public ResponseEntity<ApiResponse<ModelVersionResponse>> getModelById(@PathVariable Long id) {
        ModelVersion mv = modelVersionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Model version not found with id: " + id));
        return ResponseEntity.ok(ApiResponse.success(ModelVersionResponse.fromEntity(mv)));
    }
}
