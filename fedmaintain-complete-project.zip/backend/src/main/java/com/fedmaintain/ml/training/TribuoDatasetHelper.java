package com.fedmaintain.ml.training;

import com.fedmaintain.feature.entity.MachineFeature;
import com.fedmaintain.ml.entity.RulTrainingSample;
import org.tribuo.Example;
import org.tribuo.MutableDataset;
import org.tribuo.impl.ArrayExample;
import org.tribuo.provenance.SimpleDataSourceProvenance;
import org.tribuo.regression.RegressionFactory;
import org.tribuo.regression.Regressor;

import java.util.List;

public class TribuoDatasetHelper {

    private static final RegressionFactory FACTORY = new RegressionFactory();

    public static MutableDataset<Regressor> createDataset(List<RulTrainingSample> samples, String datasetName) {
        SimpleDataSourceProvenance provenance = new SimpleDataSourceProvenance(
                datasetName, FACTORY);
        MutableDataset<Regressor> dataset = new MutableDataset<>(provenance, FACTORY);

        for (RulTrainingSample s : samples) {
            Regressor target = new Regressor("RUL", s.getRulHours());
            ArrayExample<Regressor> ex = new ArrayExample<>(target);
            populateFeatures(ex,
                    s.getTemperatureMean(), s.getTemperatureStd(), s.getTemperatureMax(), s.getTemperatureTrend(), s.getTemperatureDeviationPct(),
                    s.getVibrationMean(), s.getVibrationStd(), s.getVibrationRms(), s.getVibrationTrend(), s.getVibrationDeviationPct(),
                    s.getCurrentMean(), s.getCurrentStd(), s.getCurrentTrend(), s.getCurrentDeviationPct(),
                    s.getPressureMean(), s.getPressureTrend(),
                    s.getRpmMean(), s.getRpmTrend(),
                    s.getAcousticMean(), s.getAcousticTrend());
            dataset.add(ex);
        }

        return dataset;
    }

    public static Example<Regressor> createInferenceExample(MachineFeature mf) {
        Regressor dummyTarget = new Regressor("RUL", 0.0);
        ArrayExample<Regressor> ex = new ArrayExample<>(dummyTarget);
        populateFeatures(ex,
                mf.getTemperatureMean(), mf.getTemperatureStd(), mf.getTemperatureMax(), mf.getTemperatureTrend(), mf.getTemperatureDeviationPct(),
                mf.getVibrationMean(), mf.getVibrationStd(), mf.getVibrationRms(), mf.getVibrationTrend(), mf.getVibrationDeviationPct(),
                mf.getCurrentMean(), mf.getCurrentStd(), mf.getCurrentTrend(), mf.getCurrentDeviationPct(),
                mf.getPressureMean(), mf.getPressureTrend(),
                mf.getRpmMean(), mf.getRpmTrend(),
                mf.getAcousticMean(), mf.getAcousticTrend());
        return ex;
    }

    private static void populateFeatures(
            ArrayExample<Regressor> ex,
            Double tempMean, Double tempStd, Double tempMax, Double tempTrend, Double tempDev,
            Double vibMean, Double vibStd, Double vibRms, Double vibTrend, Double vibDev,
            Double currMean, Double currStd, Double currTrend, Double currDev,
            Double pressMean, Double pressTrend,
            Double rpmMean, Double rpmTrend,
            Double acoMean, Double acoTrend) {

        addFeatureIfNotNull(ex, "temperature_mean", tempMean);
        addFeatureIfNotNull(ex, "temperature_std", tempStd);
        addFeatureIfNotNull(ex, "temperature_max", tempMax);
        addFeatureIfNotNull(ex, "temperature_trend", tempTrend);
        addFeatureIfNotNull(ex, "temperature_deviation_pct", tempDev);

        addFeatureIfNotNull(ex, "vibration_mean", vibMean);
        addFeatureIfNotNull(ex, "vibration_std", vibStd);
        addFeatureIfNotNull(ex, "vibration_rms", vibRms);
        addFeatureIfNotNull(ex, "vibration_trend", vibTrend);
        addFeatureIfNotNull(ex, "vibration_deviation_pct", vibDev);

        addFeatureIfNotNull(ex, "current_mean", currMean);
        addFeatureIfNotNull(ex, "current_std", currStd);
        addFeatureIfNotNull(ex, "current_trend", currTrend);
        addFeatureIfNotNull(ex, "current_deviation_pct", currDev);

        addFeatureIfNotNull(ex, "pressure_mean", pressMean);
        addFeatureIfNotNull(ex, "pressure_trend", pressTrend);

        addFeatureIfNotNull(ex, "rpm_mean", rpmMean);
        addFeatureIfNotNull(ex, "rpm_trend", rpmTrend);

        addFeatureIfNotNull(ex, "acoustic_mean", acoMean);
        addFeatureIfNotNull(ex, "acoustic_trend", acoTrend);
    }

    private static void addFeatureIfNotNull(ArrayExample<Regressor> ex, String name, Double val) {
        if (val != null && !Double.isNaN(val) && !Double.isInfinite(val)) {
            ex.add(name, val);
        } else {
            ex.add(name, 0.0);
        }
    }
}
