package com.fedmaintain.ml.entity;

import com.fedmaintain.feature.entity.DataQualityState;
import com.fedmaintain.machine.entity.Machine;
import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;

@Entity
@Table(
        name = "rul_training_samples",
        indexes = {
                @Index(name = "idx_rul_samples_dataset_run", columnList = "dataset_id, run_id")
        }
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RulTrainingSample {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "dataset_id", nullable = false)
    private MlTrainingDataset dataset;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "machine_id", nullable = false)
    private Machine machine;

    @Column(name = "run_id", nullable = false, length = 64)
    private String runId;

    @Column(name = "window_start", nullable = false)
    private Instant windowStart;

    @Column(name = "window_end", nullable = false)
    private Instant windowEnd;

    // Engineered Features snapshot from Phase 5
    @Column(name = "temperature_mean")
    private Double temperatureMean;

    @Column(name = "temperature_std")
    private Double temperatureStd;

    @Column(name = "temperature_max")
    private Double temperatureMax;

    @Column(name = "temperature_trend")
    private Double temperatureTrend;

    @Column(name = "temperature_deviation_pct")
    private Double temperatureDeviationPct;

    @Column(name = "vibration_mean")
    private Double vibrationMean;

    @Column(name = "vibration_std")
    private Double vibrationStd;

    @Column(name = "vibration_rms")
    private Double vibrationRms;

    @Column(name = "vibration_trend")
    private Double vibrationTrend;

    @Column(name = "vibration_deviation_pct")
    private Double vibrationDeviationPct;

    @Column(name = "current_mean")
    private Double currentMean;

    @Column(name = "current_std")
    private Double currentStd;

    @Column(name = "current_trend")
    private Double currentTrend;

    @Column(name = "current_deviation_pct")
    private Double currentDeviationPct;

    @Column(name = "pressure_mean")
    private Double pressureMean;

    @Column(name = "pressure_trend")
    private Double pressureTrend;

    @Column(name = "rpm_mean")
    private Double rpmMean;

    @Column(name = "rpm_trend")
    private Double rpmTrend;

    @Column(name = "acoustic_mean")
    private Double acousticMean;

    @Column(name = "acoustic_trend")
    private Double acousticTrend;

    // Ground Truth Target (Hours to Failure)
    @Column(name = "rul_hours", nullable = false)
    private Double rulHours;

    @Enumerated(EnumType.STRING)
    @Column(name = "data_quality", nullable = false, length = 20)
    @Builder.Default
    private DataQualityState dataQuality = DataQualityState.GOOD;

    @Column(name = "created_at", nullable = false)
    @Builder.Default
    private Instant createdAt = Instant.now();
}
