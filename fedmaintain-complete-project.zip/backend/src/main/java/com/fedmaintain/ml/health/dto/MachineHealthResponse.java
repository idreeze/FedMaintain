package com.fedmaintain.ml.health.dto;

import com.fedmaintain.ml.health.entity.HealthStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MachineHealthResponse {
    private String machineId;
    private Integer healthScore;
    private HealthStatus status;
    private Double rulHours;
    private Instant calculatedAt;
    private List<HealthFactorDto> factors;
}
