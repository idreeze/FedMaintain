package com.fedmaintain.ml.dataset;

import com.fedmaintain.ml.entity.RulTrainingSample;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

@Component
public class LeakageFreeDatasetSplitter {

    public static class DatasetSplit {
        private final List<RulTrainingSample> trainingSet;
        private final List<RulTrainingSample> testSet;
        private final Set<String> trainingRunIds;
        private final Set<String> testRunIds;

        public DatasetSplit(
                List<RulTrainingSample> trainingSet,
                List<RulTrainingSample> testSet,
                Set<String> trainingRunIds,
                Set<String> testRunIds) {
            this.trainingSet = trainingSet;
            this.testSet = testSet;
            this.trainingRunIds = trainingRunIds;
            this.testRunIds = testRunIds;
        }

        public List<RulTrainingSample> getTrainingSet() {
            return trainingSet;
        }

        public List<RulTrainingSample> getTestSet() {
            return testSet;
        }

        public Set<String> getTrainingRunIds() {
            return trainingRunIds;
        }

        public Set<String> getTestRunIds() {
            return testRunIds;
        }
    }

    /**
     * Splits samples grouped strictly by runId.
     * Guaranteed ZERO overlapping windows across training and test partitions.
     *
     * @param samples    List of all labeled RUL samples
     * @param trainRatio Target ratio for training set (e.g. 0.70 to 0.80)
     * @return DatasetSplit containing training and test sets with disjoint run IDs
     */
    public DatasetSplit splitByRun(List<RulTrainingSample> samples, double trainRatio) {
        if (samples == null || samples.isEmpty()) {
            return new DatasetSplit(Collections.emptyList(), Collections.emptyList(), Collections.emptySet(), Collections.emptySet());
        }

        // Group samples by runId
        Map<String, List<RulTrainingSample>> samplesByRun = samples.stream()
                .collect(Collectors.groupingBy(RulTrainingSample::getRunId, LinkedHashMap::new, Collectors.toList()));

        List<String> distinctRuns = new ArrayList<>(samplesByRun.keySet());
        Collections.sort(distinctRuns); // Deterministic ordering

        Set<String> trainRunIds = new LinkedHashSet<>();
        Set<String> testRunIds = new LinkedHashSet<>();

        if (distinctRuns.size() <= 1) {
            // Edge case: only 1 run available; put 70% of chronological windows in train, remaining in test
            List<RulTrainingSample> singleRunSamples = samplesByRun.get(distinctRuns.get(0));
            int splitIdx = Math.max(1, (int) (singleRunSamples.size() * trainRatio));
            List<RulTrainingSample> trainList = new ArrayList<>(singleRunSamples.subList(0, splitIdx));
            List<RulTrainingSample> testList = new ArrayList<>(singleRunSamples.subList(splitIdx, singleRunSamples.size()));
            return new DatasetSplit(trainList, testList, Collections.singleton(distinctRuns.get(0)), Collections.singleton(distinctRuns.get(0)));
        }

        int totalSamples = samples.size();
        int targetTrainCount = (int) (totalSamples * trainRatio);
        int currentTrainCount = 0;

        for (String runId : distinctRuns) {
            List<RulTrainingSample> runSamples = samplesByRun.get(runId);
            if (currentTrainCount + runSamples.size() <= targetTrainCount || trainRunIds.isEmpty()) {
                trainRunIds.add(runId);
                currentTrainCount += runSamples.size();
            } else {
                testRunIds.add(runId);
            }
        }

        // Safety check: ensure both sets have at least one run if at least 2 distinct runs exist
        if (testRunIds.isEmpty() && distinctRuns.size() >= 2) {
            String lastRun = distinctRuns.get(distinctRuns.size() - 1);
            trainRunIds.remove(lastRun);
            testRunIds.add(lastRun);
        }

        List<RulTrainingSample> trainSet = new ArrayList<>();
        for (String rId : trainRunIds) {
            trainSet.addAll(samplesByRun.get(rId));
        }

        List<RulTrainingSample> testSet = new ArrayList<>();
        for (String rId : testRunIds) {
            testSet.addAll(samplesByRun.get(rId));
        }

        return new DatasetSplit(trainSet, testSet, trainRunIds, testRunIds);
    }
}
