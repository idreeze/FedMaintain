package com.fedmaintain.ml.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;

@Entity
@Table(name = "model_versions")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ModelVersion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "model_name", nullable = false, length = 100)
    private String modelName;

    @Column(nullable = false, unique = true, length = 50)
    private String version;

    @Column(name = "model_type", nullable = false, length = 50)
    @Builder.Default
    private String modelType = "REGRESSION";

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 50)
    private ModelAlgorithm algorithm;

    @Column(name = "feature_schema_version", nullable = false, length = 30)
    @Builder.Default
    private String featureSchemaVersion = "v1";

    @Column(name = "training_dataset_version", length = 50)
    private String trainingDatasetVersion;

    @Column(name = "training_started_at")
    private Instant trainingStartedAt;

    @Column(name = "training_completed_at")
    private Instant trainingCompletedAt;

    @Column(name = "mae")
    private Double mae;

    @Column(name = "rmse")
    private Double rmse;

    @Column(name = "r2")
    private Double r2;

    @Column(name = "training_samples")
    @Builder.Default
    private Integer trainingSamples = 0;

    @Column(name = "test_samples")
    @Builder.Default
    private Integer testSamples = 0;

    @Column(name = "artifact_path")
    private String artifactPath;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    @Builder.Default
    private ModelStatus status = ModelStatus.TRAINING;

    @Column(name = "created_at", nullable = false)
    @Builder.Default
    private Instant createdAt = Instant.now();
}
