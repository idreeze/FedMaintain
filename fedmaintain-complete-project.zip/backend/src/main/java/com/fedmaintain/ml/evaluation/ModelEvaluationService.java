package com.fedmaintain.ml.evaluation;

import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

@Service
public class ModelEvaluationService {

    public static class EvaluationMetrics {
        private final double mae;
        private final double rmse;
        private final double r2;

        public EvaluationMetrics(double mae, double rmse, double r2) {
            this.mae = mae;
            this.rmse = rmse;
            this.r2 = r2;
        }

        public double getMae() {
            return mae;
        }

        public double getRmse() {
            return rmse;
        }

        public double getR2() {
            return r2;
        }
    }

    /**
     * Evaluates actual vs predicted values on holdout test set.
     * All metrics are strictly calculated from genuine test samples.
     */
    public EvaluationMetrics evaluate(List<Double> actuals, List<Double> predicted) {
        if (actuals == null || predicted == null || actuals.isEmpty() || actuals.size() != predicted.size()) {
            return new EvaluationMetrics(0.0, 0.0, 0.0);
        }

        int n = actuals.size();
        double sumAbsErr = 0.0;
        double sumSqErr = 0.0;
        double sumActual = 0.0;

        for (int i = 0; i < n; i++) {
            double actual = actuals.get(i);
            double pred = predicted.get(i);
            double diff = actual - pred;
            sumAbsErr += Math.abs(diff);
            sumSqErr += diff * diff;
            sumActual += actual;
        }

        double meanActual = sumActual / n;
        double totalSumSq = 0.0;
        for (double actual : actuals) {
            totalSumSq += Math.pow(actual - meanActual, 2);
        }

        double mae = sumAbsErr / n;
        double rmse = Math.sqrt(sumSqErr / n);
        double r2 = (totalSumSq > 1e-9) ? 1.0 - (sumSqErr / totalSumSq) : 0.0;

        return new EvaluationMetrics(
                round(mae, 4),
                round(rmse, 4),
                round(r2, 4));
    }

    private double round(double val, int places) {
        if (Double.isNaN(val) || Double.isInfinite(val)) {
            return 0.0;
        }
        return BigDecimal.valueOf(val).setScale(places, RoundingMode.HALF_UP).doubleValue();
    }
}
