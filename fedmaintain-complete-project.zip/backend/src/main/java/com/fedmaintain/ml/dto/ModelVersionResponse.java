package com.fedmaintain.ml.dto;

import com.fedmaintain.ml.entity.ModelAlgorithm;
import com.fedmaintain.ml.entity.ModelStatus;
import com.fedmaintain.ml.entity.ModelVersion;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ModelVersionResponse {
    private Long id;
    private String modelName;
    private String version;
    private String modelType;
    private ModelAlgorithm algorithm;
    private String featureSchemaVersion;
    private String trainingDatasetVersion;
    private Instant trainingStartedAt;
    private Instant trainingCompletedAt;
    private Double mae;
    private Double rmse;
    private Double r2;
    private Integer trainingSamples;
    private Integer testSamples;
    private ModelStatus status;
    private Instant createdAt;

    public static ModelVersionResponse fromEntity(ModelVersion mv) {
        if (mv == null) return null;
        return ModelVersionResponse.builder()
                .id(mv.getId())
                .modelName(mv.getModelName())
                .version(mv.getVersion())
                .modelType(mv.getModelType())
                .algorithm(mv.getAlgorithm())
                .featureSchemaVersion(mv.getFeatureSchemaVersion())
                .trainingDatasetVersion(mv.getTrainingDatasetVersion())
                .trainingStartedAt(mv.getTrainingStartedAt())
                .trainingCompletedAt(mv.getTrainingCompletedAt())
                .mae(mv.getMae())
                .rmse(mv.getRmse())
                .r2(mv.getR2())
                .trainingSamples(mv.getTrainingSamples())
                .testSamples(mv.getTestSamples())
                .status(mv.getStatus())
                .createdAt(mv.getCreatedAt())
                .build();
    }
}
