package com.fedmaintain.ml.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@Service
public class ModelStorageService {

    private static final Logger log = LoggerFactory.getLogger(ModelStorageService.class);

    @Value("${ml.model-artifacts-dir:model-artifacts/rul}")
    private String modelArtifactsDir;

    public String saveModel(String version, Object modelObject) {
        try {
            Path dirPath = Paths.get(modelArtifactsDir);
            if (!Files.exists(dirPath)) {
                Files.createDirectories(dirPath);
            }

            String filename = "model-" + version + ".ser";
            Path filePath = dirPath.resolve(filename);

            try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filePath.toFile()))) {
                oos.writeObject(modelObject);
            }

            log.info("Saved trained model artifact to: {}", filePath.toAbsolutePath());
            return filePath.toAbsolutePath().toString();
        } catch (Exception e) {
            log.error("Failed to save model artifact for version {}: {}", version, e.getMessage(), e);
            throw new RuntimeException("Failed to persist model artifact: " + e.getMessage(), e);
        }
    }

    public Object loadModel(String artifactPath) {
        try {
            File file = new File(artifactPath);
            if (!file.exists()) {
                // Handle cross-platform path resolution (e.g. Windows paths accessed in Linux Docker containers)
                String fileName = artifactPath;
                int lastSlash = Math.max(fileName.lastIndexOf('/'), fileName.lastIndexOf('\\'));
                if (lastSlash >= 0 && lastSlash < fileName.length() - 1) {
                    fileName = fileName.substring(lastSlash + 1);
                }

                Path fallbackPath = Paths.get(modelArtifactsDir).resolve(fileName);
                if (Files.exists(fallbackPath)) {
                    file = fallbackPath.toFile();
                } else {
                    throw new FileNotFoundException("Model artifact not found at: " + artifactPath + " (fallback checked: " + fallbackPath.toAbsolutePath() + ")");
                }
            }

            try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
                return ois.readObject();
            }
        } catch (Exception e) {
            log.error("Failed to load model artifact from {}: {}", artifactPath, e.getMessage(), e);
            throw new RuntimeException("Failed to load model artifact: " + e.getMessage(), e);
        }
    }
}
