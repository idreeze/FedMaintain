package com.fedmaintain.ml.explainability.entity;

import com.fedmaintain.ml.entity.RulPrediction;
import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;

@Entity
@Table(
        name = "prediction_explanations",
        indexes = {
                @Index(name = "idx_pred_explanations_pred_id", columnList = "prediction_id")
        }
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PredictionExplanation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "prediction_id", nullable = false)
    private RulPrediction prediction;

    @Column(name = "feature_name", nullable = false, length = 100)
    private String featureName;

    @Column(name = "feature_value", nullable = false)
    private Double featureValue;

    @Column(name = "baseline_value", nullable = false)
    private Double baselineValue;

    @Column(name = "deviation_percentage", nullable = false)
    private Double deviationPercentage;

    @Enumerated(EnumType.STRING)
    @Column(name = "contribution_level", nullable = false, length = 20)
    @Builder.Default
    private ContributionLevel contributionLevel = ContributionLevel.LOW;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    @Builder.Default
    private DeviationDirection direction = DeviationDirection.NEUTRAL;

    @Column(name = "created_at", nullable = false)
    @Builder.Default
    private Instant createdAt = Instant.now();
}
