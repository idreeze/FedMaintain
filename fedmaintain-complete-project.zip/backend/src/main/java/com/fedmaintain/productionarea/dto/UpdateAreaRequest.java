package com.fedmaintain.productionarea.dto;

import com.fedmaintain.productionarea.entity.AreaStatus;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateAreaRequest {

    @NotBlank(message = "Area name is required")
    @Size(min = 2, max = 100, message = "Area name must be between 2 and 100 characters")
    private String name;

    private String description;

    private AreaStatus status;
}
