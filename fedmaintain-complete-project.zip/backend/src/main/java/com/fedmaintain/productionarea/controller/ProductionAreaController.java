package com.fedmaintain.productionarea.controller;

import com.fedmaintain.productionarea.dto.AreaResponse;
import com.fedmaintain.productionarea.dto.CreateAreaRequest;
import com.fedmaintain.productionarea.dto.UpdateAreaRequest;
import com.fedmaintain.productionarea.service.ProductionAreaService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class ProductionAreaController {

    private final ProductionAreaService areaService;

    public ProductionAreaController(ProductionAreaService areaService) {
        this.areaService = areaService;
    }

    @GetMapping("/plants/{plantId}/areas")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER', 'OPERATOR')")
    public ResponseEntity<List<AreaResponse>> getAreasByPlantId(@PathVariable Long plantId) {
        return ResponseEntity.ok(areaService.getAreasByPlantId(plantId));
    }

    @GetMapping("/areas/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER', 'OPERATOR')")
    public ResponseEntity<AreaResponse> getAreaById(@PathVariable Long id) {
        return ResponseEntity.ok(areaService.getAreaById(id));
    }

    @PostMapping("/plants/{plantId}/areas")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER')")
    public ResponseEntity<AreaResponse> createArea(
            @PathVariable Long plantId,
            @Valid @RequestBody CreateAreaRequest request) {
        AreaResponse response = areaService.createArea(plantId, request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @PutMapping("/areas/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER')")
    public ResponseEntity<AreaResponse> updateArea(
            @PathVariable Long id,
            @Valid @RequestBody UpdateAreaRequest request) {
        return ResponseEntity.ok(areaService.updateArea(id, request));
    }

    @DeleteMapping("/areas/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER')")
    public ResponseEntity<Void> deleteArea(@PathVariable Long id) {
        areaService.deleteArea(id);
        return ResponseEntity.noContent().build();
    }
}
