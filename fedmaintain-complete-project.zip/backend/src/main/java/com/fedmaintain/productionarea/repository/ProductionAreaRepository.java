package com.fedmaintain.productionarea.repository;

import com.fedmaintain.productionarea.entity.ProductionArea;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ProductionAreaRepository extends JpaRepository<ProductionArea, Long> {

    List<ProductionArea> findByPlantId(Long plantId);

    Optional<ProductionArea> findByPlantIdAndCode(Long plantId, String code);

    boolean existsByPlantIdAndCode(Long plantId, String code);

    long countByPlantId(Long plantId);
}
