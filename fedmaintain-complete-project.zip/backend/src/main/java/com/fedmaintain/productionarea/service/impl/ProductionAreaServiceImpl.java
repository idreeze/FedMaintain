package com.fedmaintain.productionarea.service.impl;

import com.fedmaintain.exception.ResourceNotFoundException;
import com.fedmaintain.exception.UserAlreadyExistsException;
import com.fedmaintain.machine.repository.MachineRepository;
import com.fedmaintain.plant.entity.Plant;
import com.fedmaintain.plant.repository.PlantRepository;
import com.fedmaintain.productionarea.dto.AreaResponse;
import com.fedmaintain.productionarea.dto.CreateAreaRequest;
import com.fedmaintain.productionarea.dto.UpdateAreaRequest;
import com.fedmaintain.productionarea.entity.ProductionArea;
import com.fedmaintain.productionarea.repository.ProductionAreaRepository;
import com.fedmaintain.productionarea.service.ProductionAreaService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional(readOnly = true)
public class ProductionAreaServiceImpl implements ProductionAreaService {

    private final ProductionAreaRepository productionAreaRepository;
    private final PlantRepository plantRepository;
    private final MachineRepository machineRepository;

    public ProductionAreaServiceImpl(
            ProductionAreaRepository productionAreaRepository,
            PlantRepository plantRepository,
            MachineRepository machineRepository) {
        this.productionAreaRepository = productionAreaRepository;
        this.plantRepository = plantRepository;
        this.machineRepository = machineRepository;
    }

    @Override
    public List<AreaResponse> getAreasByPlantId(Long plantId) {
        if (!plantRepository.existsById(plantId)) {
            throw new ResourceNotFoundException("Plant not found with id: " + plantId);
        }
        return productionAreaRepository.findByPlantId(plantId).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public AreaResponse getAreaById(Long id) {
        ProductionArea area = getAreaEntityById(id);
        return mapToResponse(area);
    }

    @Override
    public ProductionArea getAreaEntityById(Long id) {
        return productionAreaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Production area not found with id: " + id));
    }

    @Override
    @Transactional
    public AreaResponse createArea(Long plantId, CreateAreaRequest request) {
        Plant plant = plantRepository.findById(plantId)
                .orElseThrow(() -> new ResourceNotFoundException("Plant not found with id: " + plantId));

        String code = request.getCode().trim().toUpperCase();
        if (productionAreaRepository.existsByPlantIdAndCode(plantId, code)) {
            throw new UserAlreadyExistsException("Production area with code '" + code + "' already exists in plant: " + plant.getName());
        }

        ProductionArea area = ProductionArea.builder()
                .plant(plant)
                .name(request.getName().trim())
                .code(code)
                .description(request.getDescription())
                .status(request.getStatus())
                .build();

        ProductionArea saved = productionAreaRepository.save(area);
        return mapToResponse(saved);
    }

    @Override
    @Transactional
    public AreaResponse updateArea(Long id, UpdateAreaRequest request) {
        ProductionArea area = getAreaEntityById(id);

        area.setName(request.getName().trim());
        if (request.getDescription() != null) {
            area.setDescription(request.getDescription());
        }
        if (request.getStatus() != null) {
            area.setStatus(request.getStatus());
        }

        ProductionArea updated = productionAreaRepository.save(area);
        return mapToResponse(updated);
    }

    @Override
    @Transactional
    public void deleteArea(Long id) {
        ProductionArea area = getAreaEntityById(id);

        long machineCount = machineRepository.countByProductionAreaId(id);
        if (machineCount > 0) {
            throw new IllegalArgumentException(
                    "Cannot delete production area '" + area.getName() + "'. It contains " + machineCount +
                    " machine(s). Please decommission or reassign machines first.");
        }

        productionAreaRepository.delete(area);
    }

    private AreaResponse mapToResponse(ProductionArea area) {
        long machineCount = machineRepository.countByProductionAreaId(area.getId());
        return AreaResponse.fromEntity(area, machineCount);
    }
}
