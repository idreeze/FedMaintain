package com.fedmaintain.productionarea.entity;

public enum AreaStatus {
    ACTIVE,
    INACTIVE
}
