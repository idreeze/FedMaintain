package com.fedmaintain.productionarea.dto;

import com.fedmaintain.productionarea.entity.AreaStatus;
import com.fedmaintain.productionarea.entity.ProductionArea;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AreaResponse {

    private Long id;
    private Long plantId;
    private String plantName;
    private String plantCode;
    private String name;
    private String code;
    private String description;
    private AreaStatus status;
    private long machineCount;
    private Instant createdAt;
    private Instant updatedAt;

    public static AreaResponse fromEntity(ProductionArea area, long machineCount) {
        return AreaResponse.builder()
                .id(area.getId())
                .plantId(area.getPlant().getId())
                .plantName(area.getPlant().getName())
                .plantCode(area.getPlant().getCode())
                .name(area.getName())
                .code(area.getCode())
                .description(area.getDescription())
                .status(area.getStatus())
                .machineCount(machineCount)
                .createdAt(area.getCreatedAt())
                .updatedAt(area.getUpdatedAt())
                .build();
    }
}
