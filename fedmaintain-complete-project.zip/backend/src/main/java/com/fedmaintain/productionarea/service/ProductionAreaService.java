package com.fedmaintain.productionarea.service;

import com.fedmaintain.productionarea.dto.AreaResponse;
import com.fedmaintain.productionarea.dto.CreateAreaRequest;
import com.fedmaintain.productionarea.dto.UpdateAreaRequest;
import com.fedmaintain.productionarea.entity.ProductionArea;

import java.util.List;

public interface ProductionAreaService {

    List<AreaResponse> getAreasByPlantId(Long plantId);

    AreaResponse getAreaById(Long id);

    ProductionArea getAreaEntityById(Long id);

    AreaResponse createArea(Long plantId, CreateAreaRequest request);

    AreaResponse updateArea(Long id, UpdateAreaRequest request);

    void deleteArea(Long id);
}
