package com.fedmaintain.feature.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class GenerateFeaturesRequest {
    private Instant startTime;
    private Instant endTime;
    @Builder.Default
    private Integer windowMinutes = 30;
    @Builder.Default
    private Integer stepMinutes = 5;
}
