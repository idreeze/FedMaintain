package com.fedmaintain.feature.repository;

import com.fedmaintain.feature.entity.MachineFeature;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

@Repository
public interface MachineFeatureRepository extends JpaRepository<MachineFeature, Long> {

    Optional<MachineFeature> findByMachineIdAndWindowStartAndWindowEnd(
            Long machineId, Instant windowStart, Instant windowEnd);

    boolean existsByMachineIdAndWindowStartAndWindowEnd(
            Long machineId, Instant windowStart, Instant windowEnd);

    Page<MachineFeature> findByMachineIdOrderByWindowStartDesc(Long machineId, Pageable pageable);

    @Query("SELECT mf FROM MachineFeature mf WHERE mf.machine.id = :machineId " +
           "AND mf.windowStart >= :startTime AND mf.windowEnd <= :endTime " +
           "ORDER BY mf.windowStart ASC")
    List<MachineFeature> findFeaturesInWindow(
            @Param("machineId") Long machineId,
            @Param("startTime") Instant startTime,
            @Param("endTime") Instant endTime);

    Optional<MachineFeature> findFirstByMachineIdOrderByWindowEndDesc(Long machineId);

    List<MachineFeature> findTop50ByMachineIdOrderByWindowEndDesc(Long machineId);
}
