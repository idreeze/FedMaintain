package com.fedmaintain.feature.calculator;

import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.Instant;
import java.util.List;

@Component
public class StatisticsCalculator {

    public static class TimeValuePoint {
        private final Instant timestamp;
        private final double value;

        public TimeValuePoint(Instant timestamp, double value) {
            this.timestamp = timestamp;
            this.value = value;
        }

        public Instant getTimestamp() {
            return timestamp;
        }

        public double getValue() {
            return value;
        }
    }

    public Double mean(List<Double> values) {
        if (values == null || values.isEmpty()) {
            return null;
        }
        double sum = 0.0;
        for (double v : values) {
            sum += v;
        }
        return round(sum / values.size(), 4);
    }

    public Double min(List<Double> values) {
        if (values == null || values.isEmpty()) {
            return null;
        }
        double min = Double.MAX_VALUE;
        for (double v : values) {
            if (v < min) {
                min = v;
            }
        }
        return round(min, 4);
    }

    public Double max(List<Double> values) {
        if (values == null || values.isEmpty()) {
            return null;
        }
        double max = -Double.MAX_VALUE;
        for (double v : values) {
            if (v > max) {
                max = v;
            }
        }
        return round(max, 4);
    }

    public Double range(List<Double> values) {
        if (values == null || values.isEmpty()) {
            return null;
        }
        Double min = min(values);
        Double max = max(values);
        if (min == null || max == null) {
            return null;
        }
        return round(max - min, 4);
    }

    public Double standardDeviation(List<Double> values) {
        if (values == null || values.size() < 2) {
            return 0.0;
        }
        double m = mean(values);
        double sumSq = 0.0;
        for (double v : values) {
            sumSq += Math.pow(v - m, 2);
        }
        // Sample standard deviation (N - 1)
        double variance = sumSq / (values.size() - 1);
        return round(Math.sqrt(variance), 4);
    }

    public Double rootMeanSquare(List<Double> values) {
        if (values == null || values.isEmpty()) {
            return null;
        }
        double sumSq = 0.0;
        for (double v : values) {
            sumSq += v * v;
        }
        return round(Math.sqrt(sumSq / values.size()), 4);
    }

    /**
     * Calculates linear trend (slope beta1) in units per minute.
     * x represents elapsed time from first point in fractional minutes.
     * y represents measurement value.
     */
    public Double calculateSlope(List<TimeValuePoint> points) {
        if (points == null || points.size() < 2) {
            return 0.0;
        }

        Instant t0 = points.get(0).getTimestamp();
        int n = points.size();

        double sumX = 0.0;
        double sumY = 0.0;
        double[] xMinutes = new double[n];
        double[] yValues = new double[n];

        for (int i = 0; i < n; i++) {
            TimeValuePoint pt = points.get(i);
            double minutes = Duration.between(t0, pt.getTimestamp()).toMillis() / 60000.0;
            xMinutes[i] = minutes;
            yValues[i] = pt.getValue();
            sumX += minutes;
            sumY += pt.getValue();
        }

        double meanX = sumX / n;
        double meanY = sumY / n;

        double numerator = 0.0;
        double denominator = 0.0;

        for (int i = 0; i < n; i++) {
            double dx = xMinutes[i] - meanX;
            double dy = yValues[i] - meanY;
            numerator += dx * dy;
            denominator += dx * dx;
        }

        if (Math.abs(denominator) < 1e-12) {
            return 0.0;
        }

        double beta1 = numerator / denominator;
        return round(beta1, 5);
    }

    private double round(double val, int places) {
        if (Double.isNaN(val) || Double.isInfinite(val)) {
            return 0.0;
        }
        return BigDecimal.valueOf(val).setScale(places, RoundingMode.HALF_UP).doubleValue();
    }
}
