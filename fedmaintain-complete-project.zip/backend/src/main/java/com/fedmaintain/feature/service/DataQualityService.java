package com.fedmaintain.feature.service;

import com.fedmaintain.feature.dto.DataQualityReportResponse;

public interface DataQualityService {
    DataQualityReportResponse evaluateDataQuality(Long machineId);
}
