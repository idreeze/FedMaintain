package com.fedmaintain.feature.calculator;

import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;

@Component
public class DerivedFeatureCalculator {

    /**
     * Calculates percentage deviation relative to a healthy baseline:
     * Deviation % = ((value - baseline) / baseline) * 100
     */
    public Double calculateDeviationPercentage(Double currentValue, Double baselineValue) {
        if (currentValue == null || baselineValue == null || Math.abs(baselineValue) < 1e-9) {
            return 0.0;
        }
        double deviationPct = ((currentValue - baselineValue) / baselineValue) * 100.0;
        return round(deviationPct, 2);
    }

    private double round(double val, int places) {
        if (Double.isNaN(val) || Double.isInfinite(val)) {
            return 0.0;
        }
        return BigDecimal.valueOf(val).setScale(places, RoundingMode.HALF_UP).doubleValue();
    }
}
