package com.fedmaintain.feature.processor;

import com.fedmaintain.feature.entity.DataQualityState;
import com.fedmaintain.sensor.entity.SensorReading;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.time.Instant;
import java.util.*;

@Component
public class DataPreprocessor {

    public static class CleanedTelemetryResult {
        private final List<SensorReading> readings;
        private final DataQualityState qualityState;
        private final int duplicateCount;
        private final int totalInputCount;
        private final int missingIntervalsCount;

        public CleanedTelemetryResult(
                List<SensorReading> readings,
                DataQualityState qualityState,
                int duplicateCount,
                int totalInputCount,
                int missingIntervalsCount) {
            this.readings = readings;
            this.qualityState = qualityState;
            this.duplicateCount = duplicateCount;
            this.totalInputCount = totalInputCount;
            this.missingIntervalsCount = missingIntervalsCount;
        }

        public List<SensorReading> getReadings() {
            return readings;
        }

        public DataQualityState getQualityState() {
            return qualityState;
        }

        public int getDuplicateCount() {
            return duplicateCount;
        }

        public int getTotalInputCount() {
            return totalInputCount;
        }

        public int getMissingIntervalsCount() {
            return missingIntervalsCount;
        }
    }

    public CleanedTelemetryResult preprocessReadings(
            List<SensorReading> rawReadings,
            Instant expectedStart,
            Instant expectedEnd,
            Duration expectedSamplingInterval) {

        if (rawReadings == null || rawReadings.isEmpty()) {
            return new CleanedTelemetryResult(
                    Collections.emptyList(),
                    DataQualityState.INSUFFICIENT,
                    0, 0, 0);
        }

        int totalInputCount = rawReadings.size();

        // Deduplication using a unique composite key (sensor_id + time epoch millis)
        Map<String, SensorReading> deduplicatedMap = new LinkedHashMap<>();
        int duplicateCount = 0;

        for (SensorReading reading : rawReadings) {
            if (reading == null || reading.getTime() == null || reading.getSensorId() == null) {
                continue;
            }
            String key = reading.getSensorId() + "_" + reading.getTime().toEpochMilli();
            if (deduplicatedMap.containsKey(key)) {
                duplicateCount++;
            } else {
                deduplicatedMap.put(key, reading);
            }
        }

        // Chronological sorting
        List<SensorReading> cleanedList = new ArrayList<>(deduplicatedMap.values());
        cleanedList.sort(Comparator.comparing(SensorReading::getTime));

        // Gap detection
        int missingIntervals = 0;
        if (expectedSamplingInterval != null && expectedSamplingInterval.toMillis() > 0 && cleanedList.size() >= 2) {
            long expectedStepMs = expectedSamplingInterval.toMillis();
            for (int i = 1; i < cleanedList.size(); i++) {
                long diffMs = Duration.between(
                        cleanedList.get(i - 1).getTime(),
                        cleanedList.get(i).getTime()).toMillis();
                if (diffMs > expectedStepMs * 2.5) {
                    missingIntervals += (int) (diffMs / expectedStepMs) - 1;
                }
            }
        }

        // Determine DataQualityState
        DataQualityState qualityState = DataQualityState.GOOD;
        if (cleanedList.size() < 5) {
            qualityState = DataQualityState.INSUFFICIENT;
        } else if (missingIntervals > 10 || duplicateCount > totalInputCount * 0.3) {
            qualityState = DataQualityState.DEGRADED;
        }

        return new CleanedTelemetryResult(
                cleanedList,
                qualityState,
                duplicateCount,
                totalInputCount,
                missingIntervals);
    }
}
