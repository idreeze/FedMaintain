package com.fedmaintain.feature.dto;

import com.fedmaintain.feature.entity.DataQualityState;
import com.fedmaintain.feature.entity.MachineFeature;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MachineFeatureDto {
    private Long id;
    private Long machineId;
    private String machineCode;
    private Instant windowStart;
    private Instant windowEnd;

    // Temperature
    private Double temperatureMean;
    private Double temperatureStd;
    private Double temperatureMin;
    private Double temperatureMax;
    private Double temperatureRange;
    private Double temperatureTrend;
    private Double temperatureDeviationPct;

    // Vibration
    private Double vibrationMean;
    private Double vibrationStd;
    private Double vibrationMin;
    private Double vibrationMax;
    private Double vibrationRange;
    private Double vibrationRms;
    private Double vibrationTrend;
    private Double vibrationDeviationPct;

    // Current
    private Double currentMean;
    private Double currentStd;
    private Double currentMin;
    private Double currentMax;
    private Double currentRange;
    private Double currentTrend;
    private Double currentDeviationPct;

    // Pressure
    private Double pressureMean;
    private Double pressureStd;
    private Double pressureMin;
    private Double pressureMax;
    private Double pressureTrend;

    // RPM
    private Double rpmMean;
    private Double rpmStd;
    private Double rpmMin;
    private Double rpmMax;
    private Double rpmTrend;

    // Acoustic
    private Double acousticMean;
    private Double acousticStd;
    private Double acousticMax;
    private Double acousticTrend;

    private DataQualityState dataQuality;
    private Integer readingCount;
    private Instant createdAt;

    public static MachineFeatureDto fromEntity(MachineFeature f) {
        if (f == null) return null;
        return MachineFeatureDto.builder()
                .id(f.getId())
                .machineId(f.getMachine() != null ? f.getMachine().getId() : null)
                .machineCode(f.getMachine() != null ? f.getMachine().getMachineCode() : null)
                .windowStart(f.getWindowStart())
                .windowEnd(f.getWindowEnd())
                .temperatureMean(f.getTemperatureMean())
                .temperatureStd(f.getTemperatureStd())
                .temperatureMin(f.getTemperatureMin())
                .temperatureMax(f.getTemperatureMax())
                .temperatureRange(f.getTemperatureRange())
                .temperatureTrend(f.getTemperatureTrend())
                .temperatureDeviationPct(f.getTemperatureDeviationPct())
                .vibrationMean(f.getVibrationMean())
                .vibrationStd(f.getVibrationStd())
                .vibrationMin(f.getVibrationMin())
                .vibrationMax(f.getVibrationMax())
                .vibrationRange(f.getVibrationRange())
                .vibrationRms(f.getVibrationRms())
                .vibrationTrend(f.getVibrationTrend())
                .vibrationDeviationPct(f.getVibrationDeviationPct())
                .currentMean(f.getCurrentMean())
                .currentStd(f.getCurrentStd())
                .currentMin(f.getCurrentMin())
                .currentMax(f.getCurrentMax())
                .currentRange(f.getCurrentRange())
                .currentTrend(f.getCurrentTrend())
                .currentDeviationPct(f.getCurrentDeviationPct())
                .pressureMean(f.getPressureMean())
                .pressureStd(f.getPressureStd())
                .pressureMin(f.getPressureMin())
                .pressureMax(f.getPressureMax())
                .pressureTrend(f.getPressureTrend())
                .rpmMean(f.getRpmMean())
                .rpmStd(f.getRpmStd())
                .rpmMin(f.getRpmMin())
                .rpmMax(f.getRpmMax())
                .rpmTrend(f.getRpmTrend())
                .acousticMean(f.getAcousticMean())
                .acousticStd(f.getAcousticStd())
                .acousticMax(f.getAcousticMax())
                .acousticTrend(f.getAcousticTrend())
                .dataQuality(f.getDataQuality())
                .readingCount(f.getReadingCount())
                .createdAt(f.getCreatedAt())
                .build();
    }
}
