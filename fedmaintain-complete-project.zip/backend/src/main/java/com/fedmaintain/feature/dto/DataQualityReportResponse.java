package com.fedmaintain.feature.dto;

import com.fedmaintain.feature.entity.DataQualityState;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DataQualityReportResponse {
    private Long machineId;
    private String machineCode;
    private Instant calculatedAt;
    private long totalReadings;
    private long validReadings;
    private long duplicateReadings;
    private long missingReadings;
    private DataQualityState overallQuality;
    private int goodWindows;
    private int degradedWindows;
    private int insufficientWindows;
}
