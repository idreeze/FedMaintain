package com.fedmaintain.feature.processor;

import org.springframework.stereotype.Component;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@Component
public class WindowGenerator {

    public static class TimeWindow {
        private final Instant start;
        private final Instant end;

        public TimeWindow(Instant start, Instant end) {
            this.start = start;
            this.end = end;
        }

        public Instant getStart() {
            return start;
        }

        public Instant getEnd() {
            return end;
        }

        @Override
        public String toString() {
            return "[" + start + " -> " + end + "]";
        }
    }

    /**
     * Generates sliding time windows across [rangeStart, rangeEnd].
     *
     * @param rangeStart Range start instant
     * @param rangeEnd   Range end instant
     * @param windowSize Duration of each window (default 30 min)
     * @param stepSize   Duration of step increment (default 5 min)
     * @return Ordered list of time windows
     */
    public List<TimeWindow> generateWindows(
            Instant rangeStart,
            Instant rangeEnd,
            Duration windowSize,
            Duration stepSize) {

        List<TimeWindow> windows = new ArrayList<>();
        if (rangeStart == null || rangeEnd == null || windowSize == null || stepSize == null) {
            return windows;
        }

        if (rangeStart.plus(windowSize).isAfter(rangeEnd)) {
            // Range is shorter than window size, create one window if range has duration
            if (rangeStart.isBefore(rangeEnd)) {
                windows.add(new TimeWindow(rangeStart, rangeEnd));
            }
            return windows;
        }

        Instant currentStart = rangeStart;
        while (!currentStart.plus(windowSize).isAfter(rangeEnd)) {
            Instant currentEnd = currentStart.plus(windowSize);
            windows.add(new TimeWindow(currentStart, currentEnd));
            currentStart = currentStart.plus(stepSize);
        }

        return windows;
    }
}
