package com.fedmaintain.feature.service.impl;

import com.fedmaintain.exception.ResourceNotFoundException;
import com.fedmaintain.feature.calculator.DerivedFeatureCalculator;
import com.fedmaintain.feature.calculator.StatisticsCalculator;
import com.fedmaintain.feature.calculator.StatisticsCalculator.TimeValuePoint;
import com.fedmaintain.feature.dto.GenerateFeaturesRequest;
import com.fedmaintain.feature.dto.GenerateFeaturesResponse;
import com.fedmaintain.feature.dto.MachineFeatureDto;
import com.fedmaintain.feature.entity.DataQualityState;
import com.fedmaintain.feature.entity.MachineBaseline;
import com.fedmaintain.feature.entity.MachineFeature;
import com.fedmaintain.feature.processor.DataPreprocessor;
import com.fedmaintain.feature.processor.DataPreprocessor.CleanedTelemetryResult;
import com.fedmaintain.feature.processor.TelemetryResampler;
import com.fedmaintain.feature.processor.WindowGenerator;
import com.fedmaintain.feature.processor.WindowGenerator.TimeWindow;
import com.fedmaintain.feature.repository.MachineFeatureRepository;
import com.fedmaintain.feature.service.FeatureService;
import com.fedmaintain.feature.service.MachineBaselineService;
import com.fedmaintain.machine.entity.Machine;
import com.fedmaintain.machine.repository.MachineRepository;
import com.fedmaintain.sensor.entity.Sensor;
import com.fedmaintain.sensor.entity.SensorReading;
import com.fedmaintain.sensor.entity.SensorType;
import com.fedmaintain.sensor.repository.SensorReadingRepository;
import com.fedmaintain.sensor.repository.SensorRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class FeatureServiceImpl implements FeatureService {

    private static final Logger log = LoggerFactory.getLogger(FeatureServiceImpl.class);

    private final MachineRepository machineRepository;
    private final SensorRepository sensorRepository;
    private final SensorReadingRepository readingRepository;
    private final MachineFeatureRepository featureRepository;
    private final MachineBaselineService baselineService;
    private final DataPreprocessor preprocessor;
    private final TelemetryResampler resampler;
    private final WindowGenerator windowGenerator;
    private final StatisticsCalculator statsCalculator;
    private final DerivedFeatureCalculator derivedCalculator;

    public FeatureServiceImpl(
            MachineRepository machineRepository,
            SensorRepository sensorRepository,
            SensorReadingRepository readingRepository,
            MachineFeatureRepository featureRepository,
            MachineBaselineService baselineService,
            DataPreprocessor preprocessor,
            TelemetryResampler resampler,
            WindowGenerator windowGenerator,
            StatisticsCalculator statsCalculator,
            DerivedFeatureCalculator derivedCalculator) {
        this.machineRepository = machineRepository;
        this.sensorRepository = sensorRepository;
        this.readingRepository = readingRepository;
        this.featureRepository = featureRepository;
        this.baselineService = baselineService;
        this.preprocessor = preprocessor;
        this.resampler = resampler;
        this.windowGenerator = windowGenerator;
        this.statsCalculator = statsCalculator;
        this.derivedCalculator = derivedCalculator;
    }

    @Override
    @Transactional
    public GenerateFeaturesResponse generateFeatures(Long machineId, GenerateFeaturesRequest request) {
        Machine machine = machineRepository.findById(machineId)
                .orElseThrow(() -> new ResourceNotFoundException("Machine not found with id: " + machineId));

        Instant end = request.getEndTime() != null ? request.getEndTime() : Instant.now();
        Instant start = request.getStartTime() != null ? request.getStartTime() : end.minus(2, ChronoUnit.HOURS);
        int windowMinutes = (request.getWindowMinutes() != null && request.getWindowMinutes() > 0)
                ? request.getWindowMinutes() : 30;
        int stepMinutes = (request.getStepMinutes() != null && request.getStepMinutes() > 0)
                ? request.getStepMinutes() : 5;

        // Fetch sensors and baseline
        List<Sensor> sensors = sensorRepository.findByMachineId(machineId);
        Map<Long, SensorType> sensorTypeMap = sensors.stream()
                .collect(Collectors.toMap(Sensor::getId, Sensor::getSensorType, (s1, s2) -> s1));

        MachineBaseline baseline = baselineService.getOrCreateBaseline(machineId);

        // Fetch and preprocess raw telemetry
        List<SensorReading> rawReadings = readingRepository.findReadingsForMachineInRange(machineId, start, end);
        CleanedTelemetryResult cleanedResult = preprocessor.preprocessReadings(
                rawReadings, start, end, Duration.ofSeconds(4));

        List<SensorReading> cleanedReadings = cleanedResult.getReadings();

        // Generate sliding windows
        List<TimeWindow> windows = windowGenerator.generateWindows(
                start, end, Duration.ofMinutes(windowMinutes), Duration.ofMinutes(stepMinutes));

        List<MachineFeature> generatedFeatures = new ArrayList<>();
        int skipped = 0;

        for (TimeWindow window : windows) {
            // Check deduplication in database
            if (featureRepository.existsByMachineIdAndWindowStartAndWindowEnd(
                    machineId, window.getStart(), window.getEnd())) {
                skipped++;
                continue;
            }

            // Extract window readings
            List<SensorReading> windowReadings = cleanedReadings.stream()
                    .filter(r -> !r.getTime().isBefore(window.getStart()) && !r.getTime().isAfter(window.getEnd()))
                    .toList();

            MachineFeature mf = computeWindowFeatures(machine, window, windowReadings, sensorTypeMap, baseline, cleanedResult.getQualityState());
            generatedFeatures.add(featureRepository.save(mf));
        }

        List<MachineFeatureDto> dtoList = generatedFeatures.stream()
                .map(MachineFeatureDto::fromEntity)
                .toList();

        return GenerateFeaturesResponse.builder()
                .machineId(machine.getId())
                .machineCode(machine.getMachineCode())
                .generatedWindowsCount(generatedFeatures.size())
                .skippedWindowsCount(skipped)
                .features(dtoList)
                .build();
    }

    private MachineFeature computeWindowFeatures(
            Machine machine,
            TimeWindow window,
            List<SensorReading> windowReadings,
            Map<Long, SensorType> sensorTypeMap,
            MachineBaseline baseline,
            DataQualityState pipelineQuality) {

        // Group readings by sensor type
        Map<SensorType, List<SensorReading>> readingsByType = new EnumMap<>(SensorType.class);
        for (SensorReading r : windowReadings) {
            SensorType type = sensorTypeMap.get(r.getSensorId());
            if (type != null) {
                readingsByType.computeIfAbsent(type, k -> new ArrayList<>()).add(r);
            }
        }

        MachineFeature.MachineFeatureBuilder b = MachineFeature.builder()
                .machine(machine)
                .windowStart(window.getStart())
                .windowEnd(window.getEnd())
                .readingCount(windowReadings.size())
                .dataQuality(windowReadings.size() < 6 ? DataQualityState.INSUFFICIENT : pipelineQuality)
                .createdAt(Instant.now());

        // Temperature
        List<SensorReading> tempReadings = readingsByType.getOrDefault(SensorType.TEMPERATURE, Collections.emptyList());
        List<TimeValuePoint> tempPts = resampler.resampleToMinuteIntervals(tempReadings, window.getStart(), window.getEnd());
        List<Double> tempVals = tempPts.stream().map(TimeValuePoint::getValue).toList();
        if (!tempVals.isEmpty()) {
            Double mean = statsCalculator.mean(tempVals);
            b.temperatureMean(mean);
            b.temperatureStd(statsCalculator.standardDeviation(tempVals));
            b.temperatureMin(statsCalculator.min(tempVals));
            b.temperatureMax(statsCalculator.max(tempVals));
            b.temperatureRange(statsCalculator.range(tempVals));
            b.temperatureTrend(statsCalculator.calculateSlope(tempPts));
            b.temperatureDeviationPct(derivedCalculator.calculateDeviationPercentage(mean, baseline.getBaselineTemperature()));
        }

        // Vibration
        List<SensorReading> vibReadings = readingsByType.getOrDefault(SensorType.VIBRATION, Collections.emptyList());
        List<TimeValuePoint> vibPts = resampler.resampleToMinuteIntervals(vibReadings, window.getStart(), window.getEnd());
        List<Double> vibVals = vibPts.stream().map(TimeValuePoint::getValue).toList();
        if (!vibVals.isEmpty()) {
            Double mean = statsCalculator.mean(vibVals);
            b.vibrationMean(mean);
            b.vibrationStd(statsCalculator.standardDeviation(vibVals));
            b.vibrationMin(statsCalculator.min(vibVals));
            b.vibrationMax(statsCalculator.max(vibVals));
            b.vibrationRange(statsCalculator.range(vibVals));
            b.vibrationRms(statsCalculator.rootMeanSquare(vibVals));
            b.vibrationTrend(statsCalculator.calculateSlope(vibPts));
            b.vibrationDeviationPct(derivedCalculator.calculateDeviationPercentage(mean, baseline.getBaselineVibration()));
        }

        // Current
        List<SensorReading> currReadings = readingsByType.getOrDefault(SensorType.CURRENT, Collections.emptyList());
        List<TimeValuePoint> currPts = resampler.resampleToMinuteIntervals(currReadings, window.getStart(), window.getEnd());
        List<Double> currVals = currPts.stream().map(TimeValuePoint::getValue).toList();
        if (!currVals.isEmpty()) {
            Double mean = statsCalculator.mean(currVals);
            b.currentMean(mean);
            b.currentStd(statsCalculator.standardDeviation(currVals));
            b.currentMin(statsCalculator.min(currVals));
            b.currentMax(statsCalculator.max(currVals));
            b.currentRange(statsCalculator.range(currVals));
            b.currentTrend(statsCalculator.calculateSlope(currPts));
            b.currentDeviationPct(derivedCalculator.calculateDeviationPercentage(mean, baseline.getBaselineCurrent()));
        }

        // Pressure
        List<SensorReading> pressReadings = readingsByType.getOrDefault(SensorType.PRESSURE, Collections.emptyList());
        List<TimeValuePoint> pressPts = resampler.resampleToMinuteIntervals(pressReadings, window.getStart(), window.getEnd());
        List<Double> pressVals = pressPts.stream().map(TimeValuePoint::getValue).toList();
        if (!pressVals.isEmpty()) {
            b.pressureMean(statsCalculator.mean(pressVals));
            b.pressureStd(statsCalculator.standardDeviation(pressVals));
            b.pressureMin(statsCalculator.min(pressVals));
            b.pressureMax(statsCalculator.max(pressVals));
            b.pressureTrend(statsCalculator.calculateSlope(pressPts));
        }

        // RPM
        List<SensorReading> rpmReadings = readingsByType.getOrDefault(SensorType.RPM, Collections.emptyList());
        List<TimeValuePoint> rpmPts = resampler.resampleToMinuteIntervals(rpmReadings, window.getStart(), window.getEnd());
        List<Double> rpmVals = rpmPts.stream().map(TimeValuePoint::getValue).toList();
        if (!rpmVals.isEmpty()) {
            b.rpmMean(statsCalculator.mean(rpmVals));
            b.rpmStd(statsCalculator.standardDeviation(rpmVals));
            b.rpmMin(statsCalculator.min(rpmVals));
            b.rpmMax(statsCalculator.max(rpmVals));
            b.rpmTrend(statsCalculator.calculateSlope(rpmPts));
        }

        // Acoustic
        List<SensorReading> acoReadings = readingsByType.getOrDefault(SensorType.ACOUSTIC, Collections.emptyList());
        List<TimeValuePoint> acoPts = resampler.resampleToMinuteIntervals(acoReadings, window.getStart(), window.getEnd());
        List<Double> acoVals = acoPts.stream().map(TimeValuePoint::getValue).toList();
        if (!acoVals.isEmpty()) {
            b.acousticMean(statsCalculator.mean(acoVals));
            b.acousticStd(statsCalculator.standardDeviation(acoVals));
            b.acousticMax(statsCalculator.max(acoVals));
            b.acousticTrend(statsCalculator.calculateSlope(acoPts));
        }

        return b.build();
    }

    @Override
    @Transactional(readOnly = true)
    public Page<MachineFeatureDto> getMachineFeatures(Long machineId, Pageable pageable) {
        return featureRepository.findByMachineIdOrderByWindowStartDesc(machineId, pageable)
                .map(MachineFeatureDto::fromEntity);
    }

    @Override
    @Transactional(readOnly = true)
    public MachineFeatureDto getLatestFeature(Long machineId) {
        return featureRepository.findFirstByMachineIdOrderByWindowEndDesc(machineId)
                .map(MachineFeatureDto::fromEntity)
                .orElse(null);
    }

    @Override
    @Transactional(readOnly = true)
    public List<MachineFeatureDto> getFeaturesInRange(Long machineId, Instant start, Instant end) {
        return featureRepository.findFeaturesInWindow(machineId, start, end).stream()
                .map(MachineFeatureDto::fromEntity)
                .toList();
    }
}
