package com.fedmaintain.feature.controller;

import com.fedmaintain.common.ApiResponse;
import com.fedmaintain.common.PageResponse;
import com.fedmaintain.feature.dto.GenerateFeaturesRequest;
import com.fedmaintain.feature.dto.GenerateFeaturesResponse;
import com.fedmaintain.feature.dto.MachineFeatureDto;
import com.fedmaintain.feature.service.FeatureService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.List;

@RestController
@RequestMapping("/api")
public class FeatureController {

    private final FeatureService featureService;

    public FeatureController(FeatureService featureService) {
        this.featureService = featureService;
    }

    @PostMapping("/features/generate/{machineId}")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER')")
    public ResponseEntity<ApiResponse<GenerateFeaturesResponse>> generateFeatures(
            @PathVariable Long machineId,
            @RequestBody(required = false) GenerateFeaturesRequest request) {
        if (request == null) {
            request = new GenerateFeaturesRequest();
        }
        GenerateFeaturesResponse response = featureService.generateFeatures(machineId, request);
        return ResponseEntity.ok(ApiResponse.success("Features generated successfully", response));
    }

    @GetMapping("/machines/{id}/features")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER', 'OPERATOR')")
    public ResponseEntity<ApiResponse<PageResponse<MachineFeatureDto>>> getMachineFeatures(
            @PathVariable Long id,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @RequestParam(required = false) Instant startTime,
            @RequestParam(required = false) Instant endTime) {

        if (startTime != null && endTime != null) {
            List<MachineFeatureDto> features = featureService.getFeaturesInRange(id, startTime, endTime);
            PageResponse<MachineFeatureDto> pageResponse = PageResponse.<MachineFeatureDto>builder()
                    .content(features)
                    .pageNumber(0)
                    .pageSize(features.size())
                    .totalElements(features.size())
                    .totalPages(1)
                    .last(true)
                    .build();
            return ResponseEntity.ok(ApiResponse.success(pageResponse));
        }

        Page<MachineFeatureDto> featurePage = featureService.getMachineFeatures(
                id, PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "windowStart")));

        return ResponseEntity.ok(ApiResponse.success(PageResponse.fromPage(featurePage)));
    }

    @GetMapping("/machines/{id}/features/latest")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER', 'OPERATOR')")
    public ResponseEntity<ApiResponse<MachineFeatureDto>> getLatestFeature(@PathVariable Long id) {
        MachineFeatureDto latest = featureService.getLatestFeature(id);
        return ResponseEntity.ok(ApiResponse.success(latest));
    }
}
