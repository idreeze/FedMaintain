package com.fedmaintain.feature.service;

import com.fedmaintain.feature.entity.MachineBaseline;

public interface MachineBaselineService {
    MachineBaseline getOrCreateBaseline(Long machineId);
    MachineBaseline updateBaseline(Long machineId, MachineBaseline baseline);
}
