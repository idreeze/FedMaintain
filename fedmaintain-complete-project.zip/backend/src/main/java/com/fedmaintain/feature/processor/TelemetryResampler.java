package com.fedmaintain.feature.processor;

import com.fedmaintain.feature.calculator.StatisticsCalculator.TimeValuePoint;
import com.fedmaintain.sensor.entity.SensorReading;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.*;

@Component
public class TelemetryResampler {

    /**
     * Resamples sensor readings into uniform minute intervals.
     * Takes the arithmetic mean of all readings within each 1-minute interval.
     */
    public List<TimeValuePoint> resampleToMinuteIntervals(
            List<SensorReading> readings,
            Instant windowStart,
            Instant windowEnd) {

        if (readings == null || readings.isEmpty()) {
            return Collections.emptyList();
        }

        // Group readings by truncated minute
        Map<Instant, List<Double>> minuteBuckets = new TreeMap<>();

        for (SensorReading r : readings) {
            Instant t = r.getTime().truncatedTo(ChronoUnit.MINUTES);
            minuteBuckets.computeIfAbsent(t, k -> new ArrayList<>()).add(r.getValue());
        }

        List<TimeValuePoint> resampledPoints = new ArrayList<>();
        for (Map.Entry<Instant, List<Double>> entry : minuteBuckets.entrySet()) {
            List<Double> vals = entry.getValue();
            double sum = 0.0;
            for (double v : vals) {
                sum += v;
            }
            double mean = sum / vals.size();
            resampledPoints.add(new TimeValuePoint(entry.getKey(), mean));
        }

        return resampledPoints;
    }
}
