package com.fedmaintain.feature.entity;

import com.fedmaintain.machine.entity.Machine;
import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;

@Entity
@Table(name = "machine_baselines")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MachineBaseline {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "machine_id", nullable = false, unique = true)
    private Machine machine;

    @Column(name = "baseline_temperature", nullable = false)
    @Builder.Default
    private Double baselineTemperature = 50.0;

    @Column(name = "baseline_vibration", nullable = false)
    @Builder.Default
    private Double baselineVibration = 1.5;

    @Column(name = "baseline_current", nullable = false)
    @Builder.Default
    private Double baselineCurrent = 16.0;

    @Column(name = "baseline_pressure", nullable = false)
    @Builder.Default
    private Double baselinePressure = 45.0;

    @Column(name = "baseline_rpm", nullable = false)
    @Builder.Default
    private Double baselineRpm = 1800.0;

    @Column(name = "baseline_acoustic", nullable = false)
    @Builder.Default
    private Double baselineAcoustic = 52.0;

    @Column(name = "sample_count", nullable = false)
    @Builder.Default
    private Integer sampleCount = 0;

    @Column(name = "calculated_at", nullable = false)
    @Builder.Default
    private Instant calculatedAt = Instant.now();

    @Column(name = "updated_at", nullable = false)
    @Builder.Default
    private Instant updatedAt = Instant.now();
}
