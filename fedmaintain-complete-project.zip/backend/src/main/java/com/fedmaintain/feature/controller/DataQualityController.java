package com.fedmaintain.feature.controller;

import com.fedmaintain.common.ApiResponse;
import com.fedmaintain.feature.dto.DataQualityReportResponse;
import com.fedmaintain.feature.service.DataQualityService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class DataQualityController {

    private final DataQualityService dataQualityService;

    public DataQualityController(DataQualityService dataQualityService) {
        this.dataQualityService = dataQualityService;
    }

    @GetMapping("/machines/{id}/data-quality")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER', 'OPERATOR')")
    public ResponseEntity<ApiResponse<DataQualityReportResponse>> getDataQuality(@PathVariable Long id) {
        DataQualityReportResponse report = dataQualityService.evaluateDataQuality(id);
        return ResponseEntity.ok(ApiResponse.success(report));
    }
}
