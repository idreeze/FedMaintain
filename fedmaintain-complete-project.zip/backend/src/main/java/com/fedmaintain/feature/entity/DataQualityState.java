package com.fedmaintain.feature.entity;

public enum DataQualityState {
    GOOD,
    DEGRADED,
    INSUFFICIENT
}
