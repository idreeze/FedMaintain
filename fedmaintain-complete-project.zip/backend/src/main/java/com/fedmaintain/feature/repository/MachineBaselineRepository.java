package com.fedmaintain.feature.repository;

import com.fedmaintain.feature.entity.MachineBaseline;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface MachineBaselineRepository extends JpaRepository<MachineBaseline, Long> {
    Optional<MachineBaseline> findByMachineId(Long machineId);
    boolean existsByMachineId(Long machineId);
}
