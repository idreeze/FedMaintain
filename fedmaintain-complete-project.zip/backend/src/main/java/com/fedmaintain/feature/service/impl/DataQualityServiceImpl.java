package com.fedmaintain.feature.service.impl;

import com.fedmaintain.exception.ResourceNotFoundException;
import com.fedmaintain.feature.dto.DataQualityReportResponse;
import com.fedmaintain.feature.entity.DataQualityState;
import com.fedmaintain.feature.entity.MachineFeature;
import com.fedmaintain.feature.repository.MachineFeatureRepository;
import com.fedmaintain.feature.service.DataQualityService;
import com.fedmaintain.machine.entity.Machine;
import com.fedmaintain.machine.repository.MachineRepository;
import com.fedmaintain.sensor.entity.SensorReading;
import com.fedmaintain.sensor.repository.SensorReadingRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Service
public class DataQualityServiceImpl implements DataQualityService {

    private final MachineRepository machineRepository;
    private final SensorReadingRepository sensorReadingRepository;
    private final MachineFeatureRepository machineFeatureRepository;

    public DataQualityServiceImpl(
            MachineRepository machineRepository,
            SensorReadingRepository sensorReadingRepository,
            MachineFeatureRepository machineFeatureRepository) {
        this.machineRepository = machineRepository;
        this.sensorReadingRepository = sensorReadingRepository;
        this.machineFeatureRepository = machineFeatureRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public DataQualityReportResponse evaluateDataQuality(Long machineId) {
        Machine machine = machineRepository.findById(machineId)
                .orElseThrow(() -> new ResourceNotFoundException("Machine not found with id: " + machineId));

        Instant now = Instant.now();
        Instant past24h = now.minus(24, ChronoUnit.HOURS);

        List<SensorReading> readings = sensorReadingRepository.findReadingsForMachineInRange(machineId, past24h, now);
        List<MachineFeature> recentFeatures = machineFeatureRepository.findTop50ByMachineIdOrderByWindowEndDesc(machineId);

        long total = readings.size();
        long valid = readings.stream().filter(r -> "GOOD".equalsIgnoreCase(r.getQuality().name())).count();
        long duplicate = 0; // Handled in preprocessor
        long missing = total < 100 ? (100 - total) : 0;

        int goodWin = (int) recentFeatures.stream().filter(f -> f.getDataQuality() == DataQualityState.GOOD).count();
        int degWin = (int) recentFeatures.stream().filter(f -> f.getDataQuality() == DataQualityState.DEGRADED).count();
        int insWin = (int) recentFeatures.stream().filter(f -> f.getDataQuality() == DataQualityState.INSUFFICIENT).count();

        DataQualityState overall = DataQualityState.GOOD;
        if (total < 10 || insWin > goodWin) {
            overall = DataQualityState.INSUFFICIENT;
        } else if (degWin > 0 || (double) valid / Math.max(1, total) < 0.85) {
            overall = DataQualityState.DEGRADED;
        }

        return DataQualityReportResponse.builder()
                .machineId(machine.getId())
                .machineCode(machine.getMachineCode())
                .calculatedAt(now)
                .totalReadings(total)
                .validReadings(valid)
                .duplicateReadings(duplicate)
                .missingReadings(missing)
                .overallQuality(overall)
                .goodWindows(goodWin)
                .degradedWindows(degWin)
                .insufficientWindows(insWin)
                .build();
    }
}
