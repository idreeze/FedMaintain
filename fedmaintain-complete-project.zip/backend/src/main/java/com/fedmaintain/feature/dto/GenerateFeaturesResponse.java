package com.fedmaintain.feature.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class GenerateFeaturesResponse {
    private Long machineId;
    private String machineCode;
    private int generatedWindowsCount;
    private int skippedWindowsCount;
    private List<MachineFeatureDto> features;
}
