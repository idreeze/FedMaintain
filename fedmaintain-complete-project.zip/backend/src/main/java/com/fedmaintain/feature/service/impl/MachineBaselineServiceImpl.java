package com.fedmaintain.feature.service.impl;

import com.fedmaintain.exception.ResourceNotFoundException;
import com.fedmaintain.feature.entity.MachineBaseline;
import com.fedmaintain.feature.repository.MachineBaselineRepository;
import com.fedmaintain.feature.service.MachineBaselineService;
import com.fedmaintain.machine.entity.Machine;
import com.fedmaintain.machine.repository.MachineRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;

@Service
public class MachineBaselineServiceImpl implements MachineBaselineService {

    private final MachineBaselineRepository baselineRepository;
    private final MachineRepository machineRepository;

    public MachineBaselineServiceImpl(
            MachineBaselineRepository baselineRepository,
            MachineRepository machineRepository) {
        this.baselineRepository = baselineRepository;
        this.machineRepository = machineRepository;
    }

    @Override
    @Transactional
    public MachineBaseline getOrCreateBaseline(Long machineId) {
        return baselineRepository.findByMachineId(machineId)
                .orElseGet(() -> {
                    Machine machine = machineRepository.findById(machineId)
                            .orElseThrow(() -> new ResourceNotFoundException("Machine not found with id: " + machineId));
                    MachineBaseline defaultBaseline = MachineBaseline.builder()
                            .machine(machine)
                            .baselineTemperature(50.0)
                            .baselineVibration(1.5)
                            .baselineCurrent(16.0)
                            .baselinePressure(45.0)
                            .baselineRpm(1800.0)
                            .baselineAcoustic(52.0)
                            .sampleCount(100)
                            .calculatedAt(Instant.now())
                            .updatedAt(Instant.now())
                            .build();
                    return baselineRepository.save(defaultBaseline);
                });
    }

    @Override
    @Transactional
    public MachineBaseline updateBaseline(Long machineId, MachineBaseline updated) {
        MachineBaseline existing = getOrCreateBaseline(machineId);
        if (updated.getBaselineTemperature() != null) existing.setBaselineTemperature(updated.getBaselineTemperature());
        if (updated.getBaselineVibration() != null) existing.setBaselineVibration(updated.getBaselineVibration());
        if (updated.getBaselineCurrent() != null) existing.setBaselineCurrent(updated.getBaselineCurrent());
        if (updated.getBaselinePressure() != null) existing.setBaselinePressure(updated.getBaselinePressure());
        if (updated.getBaselineRpm() != null) existing.setBaselineRpm(updated.getBaselineRpm());
        if (updated.getBaselineAcoustic() != null) existing.setBaselineAcoustic(updated.getBaselineAcoustic());
        existing.setUpdatedAt(Instant.now());
        return baselineRepository.save(existing);
    }
}
