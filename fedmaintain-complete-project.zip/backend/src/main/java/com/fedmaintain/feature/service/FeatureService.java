package com.fedmaintain.feature.service;

import com.fedmaintain.feature.dto.GenerateFeaturesRequest;
import com.fedmaintain.feature.dto.GenerateFeaturesResponse;
import com.fedmaintain.feature.dto.MachineFeatureDto;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.time.Instant;
import java.util.List;

public interface FeatureService {
    GenerateFeaturesResponse generateFeatures(Long machineId, GenerateFeaturesRequest request);
    Page<MachineFeatureDto> getMachineFeatures(Long machineId, Pageable pageable);
    MachineFeatureDto getLatestFeature(Long machineId);
    List<MachineFeatureDto> getFeaturesInRange(Long machineId, Instant start, Instant end);
}
