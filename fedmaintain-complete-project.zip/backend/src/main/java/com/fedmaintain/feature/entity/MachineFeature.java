package com.fedmaintain.feature.entity;

import com.fedmaintain.machine.entity.Machine;
import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;

@Entity
@Table(
        name = "machine_features",
        uniqueConstraints = {
                @UniqueConstraint(name = "uq_machine_window", columnNames = {"machine_id", "window_start", "window_end"})
        },
        indexes = {
                @Index(name = "idx_machine_features_machine_window", columnList = "machine_id, window_start")
        }
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MachineFeature {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "machine_id", nullable = false)
    private Machine machine;

    @Column(name = "window_start", nullable = false)
    private Instant windowStart;

    @Column(name = "window_end", nullable = false)
    private Instant windowEnd;

    // Temperature Features
    @Column(name = "temperature_mean")
    private Double temperatureMean;

    @Column(name = "temperature_std")
    private Double temperatureStd;

    @Column(name = "temperature_min")
    private Double temperatureMin;

    @Column(name = "temperature_max")
    private Double temperatureMax;

    @Column(name = "temperature_range")
    private Double temperatureRange;

    @Column(name = "temperature_trend")
    private Double temperatureTrend;

    @Column(name = "temperature_deviation_pct")
    private Double temperatureDeviationPct;

    // Vibration Features
    @Column(name = "vibration_mean")
    private Double vibrationMean;

    @Column(name = "vibration_std")
    private Double vibrationStd;

    @Column(name = "vibration_min")
    private Double vibrationMin;

    @Column(name = "vibration_max")
    private Double vibrationMax;

    @Column(name = "vibration_range")
    private Double vibrationRange;

    @Column(name = "vibration_rms")
    private Double vibrationRms;

    @Column(name = "vibration_trend")
    private Double vibrationTrend;

    @Column(name = "vibration_deviation_pct")
    private Double vibrationDeviationPct;

    // Current Features
    @Column(name = "current_mean")
    private Double currentMean;

    @Column(name = "current_std")
    private Double currentStd;

    @Column(name = "current_min")
    private Double currentMin;

    @Column(name = "current_max")
    private Double currentMax;

    @Column(name = "current_range")
    private Double currentRange;

    @Column(name = "current_trend")
    private Double currentTrend;

    @Column(name = "current_deviation_pct")
    private Double currentDeviationPct;

    // Pressure Features
    @Column(name = "pressure_mean")
    private Double pressureMean;

    @Column(name = "pressure_std")
    private Double pressureStd;

    @Column(name = "pressure_min")
    private Double pressureMin;

    @Column(name = "pressure_max")
    private Double pressureMax;

    @Column(name = "pressure_trend")
    private Double pressureTrend;

    // RPM Features
    @Column(name = "rpm_mean")
    private Double rpmMean;

    @Column(name = "rpm_std")
    private Double rpmStd;

    @Column(name = "rpm_min")
    private Double rpmMin;

    @Column(name = "rpm_max")
    private Double rpmMax;

    @Column(name = "rpm_trend")
    private Double rpmTrend;

    // Acoustic Features
    @Column(name = "acoustic_mean")
    private Double acousticMean;

    @Column(name = "acoustic_std")
    private Double acousticStd;

    @Column(name = "acoustic_max")
    private Double acousticMax;

    @Column(name = "acoustic_trend")
    private Double acousticTrend;

    // Quality Metadata
    @Enumerated(EnumType.STRING)
    @Column(name = "data_quality", nullable = false)
    @Builder.Default
    private DataQualityState dataQuality = DataQualityState.GOOD;

    @Column(name = "reading_count", nullable = false)
    @Builder.Default
    private Integer readingCount = 0;

    @Column(name = "created_at", nullable = false)
    @Builder.Default
    private Instant createdAt = Instant.now();
}
