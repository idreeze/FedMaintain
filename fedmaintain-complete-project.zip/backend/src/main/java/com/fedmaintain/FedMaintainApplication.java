package com.fedmaintain;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class FedMaintainApplication {

    public static void main(String[] args) {
        SpringApplication.run(FedMaintainApplication.class, args);
    }
}
