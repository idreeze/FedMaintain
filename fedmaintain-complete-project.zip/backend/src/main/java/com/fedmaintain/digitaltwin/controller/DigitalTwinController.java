package com.fedmaintain.digitaltwin.controller;

import com.fedmaintain.alert.dto.AlertResponse;
import com.fedmaintain.common.ApiResponse;
import com.fedmaintain.common.PageResponse;
import com.fedmaintain.digitaltwin.dto.*;
import com.fedmaintain.digitaltwin.service.DigitalTwinService;
import com.fedmaintain.digitaltwin.service.DigitalTwinSynchronizationService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/digital-twins")
public class DigitalTwinController {

    private final DigitalTwinService digitalTwinService;
    private final DigitalTwinSynchronizationService syncService;

    public DigitalTwinController(
            DigitalTwinService digitalTwinService,
            DigitalTwinSynchronizationService syncService) {
        this.digitalTwinService = digitalTwinService;
        this.syncService = syncService;
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER', 'OPERATOR')")
    public ResponseEntity<ApiResponse<List<DigitalTwinSummaryResponse>>> getAllDigitalTwins() {
        List<DigitalTwinSummaryResponse> twins = digitalTwinService.getAllDigitalTwins();
        return ResponseEntity.ok(ApiResponse.success(twins));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER', 'OPERATOR')")
    public ResponseEntity<ApiResponse<DigitalTwinResponse>> getDigitalTwinById(@PathVariable Long id) {
        DigitalTwinResponse twin = digitalTwinService.getDigitalTwinById(id);
        return ResponseEntity.ok(ApiResponse.success(twin));
    }

    @GetMapping("/machine/{machineId}")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER', 'OPERATOR')")
    public ResponseEntity<ApiResponse<DigitalTwinResponse>> getDigitalTwinByMachineId(@PathVariable Long machineId) {
        DigitalTwinResponse twin = digitalTwinService.getDigitalTwinByMachineId(machineId);
        return ResponseEntity.ok(ApiResponse.success(twin));
    }

    @GetMapping("/{id}/state")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER', 'OPERATOR')")
    public ResponseEntity<ApiResponse<DigitalTwinStateResponse>> getDigitalTwinState(@PathVariable Long id) {
        DigitalTwinStateResponse state = digitalTwinService.getDigitalTwinState(id);
        return ResponseEntity.ok(ApiResponse.success(state));
    }

    @GetMapping("/{id}/history")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER', 'OPERATOR')")
    public ResponseEntity<ApiResponse<PageResponse<DigitalTwinHistoryResponse>>> getDigitalTwinHistory(
            @PathVariable Long id,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        Page<DigitalTwinHistoryResponse> historyPage = digitalTwinService.getDigitalTwinHistory(
                id, PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "timestamp")));
        return ResponseEntity.ok(ApiResponse.success(PageResponse.fromPage(historyPage)));
    }

    @GetMapping("/{id}/sensors")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER', 'OPERATOR')")
    public ResponseEntity<ApiResponse<List<DigitalTwinSensorViewDto>>> getDigitalTwinSensors(@PathVariable Long id) {
        List<DigitalTwinSensorViewDto> sensors = digitalTwinService.getDigitalTwinSensors(id);
        return ResponseEntity.ok(ApiResponse.success(sensors));
    }

    @GetMapping("/{id}/alerts")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER', 'OPERATOR')")
    public ResponseEntity<ApiResponse<List<AlertResponse>>> getDigitalTwinAlerts(@PathVariable Long id) {
        List<AlertResponse> alerts = digitalTwinService.getDigitalTwinAlerts(id);
        return ResponseEntity.ok(ApiResponse.success(alerts));
    }

    @GetMapping("/{id}/timeline")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER', 'OPERATOR')")
    public ResponseEntity<ApiResponse<List<DigitalTwinTimelineEventDto>>> getDigitalTwinTimeline(@PathVariable Long id) {
        List<DigitalTwinTimelineEventDto> timeline = digitalTwinService.getDigitalTwinTimeline(id);
        return ResponseEntity.ok(ApiResponse.success(timeline));
    }

    @PostMapping("/{machineId}/sync")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER')")
    public ResponseEntity<ApiResponse<DigitalTwinStateResponse>> synchronizeMachine(@PathVariable Long machineId) {
        DigitalTwinStateResponse state = syncService.synchronizeMachine(machineId);
        return ResponseEntity.ok(ApiResponse.success("Digital Twin synchronized successfully", state));
    }
}
