package com.fedmaintain.digitaltwin.service.impl;

import com.fedmaintain.alert.dto.AlertResponse;
import com.fedmaintain.alert.entity.AlertSeverity;
import com.fedmaintain.alert.entity.AlertStatus;
import com.fedmaintain.alert.entity.MaintenanceAlert;
import com.fedmaintain.alert.repository.MaintenanceAlertRepository;
import com.fedmaintain.digitaltwin.dto.*;
import com.fedmaintain.digitaltwin.entity.*;
import com.fedmaintain.digitaltwin.repository.DigitalTwinRepository;
import com.fedmaintain.digitaltwin.repository.DigitalTwinStateHistoryRepository;
import com.fedmaintain.digitaltwin.repository.DigitalTwinStateRepository;
import com.fedmaintain.digitaltwin.service.DigitalTwinService;
import com.fedmaintain.digitaltwin.service.DigitalTwinSynchronizationService;
import com.fedmaintain.exception.ResourceNotFoundException;
import com.fedmaintain.machine.entity.Machine;
import com.fedmaintain.machine.repository.MachineRepository;
import com.fedmaintain.ml.entity.RulPrediction;
import com.fedmaintain.ml.repository.RulPredictionRepository;
import com.fedmaintain.sensor.entity.Sensor;
import com.fedmaintain.sensor.entity.SensorReading;
import com.fedmaintain.sensor.repository.SensorReadingRepository;
import com.fedmaintain.sensor.repository.SensorRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.*;

@Service
@Transactional(readOnly = true)
public class DigitalTwinServiceImpl implements DigitalTwinService {

    private static final Logger log = LoggerFactory.getLogger(DigitalTwinServiceImpl.class);

    private final DigitalTwinRepository digitalTwinRepository;
    private final DigitalTwinStateRepository stateRepository;
    private final DigitalTwinStateHistoryRepository historyRepository;
    private final MachineRepository machineRepository;
    private final SensorRepository sensorRepository;
    private final SensorReadingRepository readingRepository;
    private final MaintenanceAlertRepository alertRepository;
    private final RulPredictionRepository predictionRepository;
    private final DigitalTwinSynchronizationService syncService;

    public DigitalTwinServiceImpl(
            DigitalTwinRepository digitalTwinRepository,
            DigitalTwinStateRepository stateRepository,
            DigitalTwinStateHistoryRepository historyRepository,
            MachineRepository machineRepository,
            SensorRepository sensorRepository,
            SensorReadingRepository readingRepository,
            MaintenanceAlertRepository alertRepository,
            RulPredictionRepository predictionRepository,
            DigitalTwinSynchronizationService syncService) {
        this.digitalTwinRepository = digitalTwinRepository;
        this.stateRepository = stateRepository;
        this.historyRepository = historyRepository;
        this.machineRepository = machineRepository;
        this.sensorRepository = sensorRepository;
        this.readingRepository = readingRepository;
        this.alertRepository = alertRepository;
        this.predictionRepository = predictionRepository;
        this.syncService = syncService;
    }

    @Override
    @Transactional
    public List<DigitalTwinSummaryResponse> getAllDigitalTwins() {
        List<Machine> machines = machineRepository.findAll();
        List<DigitalTwinSummaryResponse> result = new ArrayList<>();

        for (Machine machine : machines) {
            DigitalTwin twin = digitalTwinRepository.findByMachineId(machine.getId())
                    .orElseGet(() -> {
                        DigitalTwin newTwin = DigitalTwin.builder()
                                .twinCode("DT-" + machine.getMachineCode())
                                .machine(machine)
                                .status(DigitalTwinStatus.ACTIVE)
                                .createdAt(Instant.now())
                                .updatedAt(Instant.now())
                                .build();
                        return digitalTwinRepository.save(newTwin);
                    });

            DigitalTwinState state = stateRepository.findByDigitalTwinId(twin.getId())
                    .orElseGet(() -> {
                        try {
                            syncService.synchronizeMachine(machine.getId());
                            return stateRepository.findByDigitalTwinId(twin.getId()).orElse(null);
                        } catch (Exception e) {
                            return null;
                        }
                    });

            result.add(DigitalTwinSummaryResponse.fromEntity(twin, state));
        }

        return result;
    }

    @Override
    @Transactional
    public DigitalTwinResponse getDigitalTwinById(Long id) {
        DigitalTwin twin = digitalTwinRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Digital Twin not found with ID: " + id));

        DigitalTwinState state = stateRepository.findByDigitalTwinId(twin.getId())
                .orElseGet(() -> {
                    try {
                        syncService.synchronizeMachine(twin.getMachine().getId());
                        return stateRepository.findByDigitalTwinId(twin.getId()).orElse(null);
                    } catch (Exception e) {
                        return null;
                    }
                });

        String fedModelVersion = extractFederatedModelVersion(twin.getMachine().getId());

        return DigitalTwinResponse.fromEntity(twin, DigitalTwinStateResponse.fromEntity(state), fedModelVersion);
    }

    @Override
    @Transactional
    public DigitalTwinResponse getDigitalTwinByMachineId(Long machineId) {
        Machine machine = machineRepository.findById(machineId)
                .orElseThrow(() -> new ResourceNotFoundException("Machine not found with ID: " + machineId));

        DigitalTwin twin = digitalTwinRepository.findByMachineId(machineId)
                .orElseGet(() -> {
                    DigitalTwin newTwin = DigitalTwin.builder()
                            .twinCode("DT-" + machine.getMachineCode())
                            .machine(machine)
                            .status(DigitalTwinStatus.ACTIVE)
                            .createdAt(Instant.now())
                            .updatedAt(Instant.now())
                            .build();
                    return digitalTwinRepository.save(newTwin);
                });

        DigitalTwinState state = stateRepository.findByDigitalTwinId(twin.getId())
                .orElseGet(() -> {
                    try {
                        syncService.synchronizeMachine(machineId);
                        return stateRepository.findByDigitalTwinId(twin.getId()).orElse(null);
                    } catch (Exception e) {
                        return null;
                    }
                });

        String fedModelVersion = extractFederatedModelVersion(machineId);

        return DigitalTwinResponse.fromEntity(twin, DigitalTwinStateResponse.fromEntity(state), fedModelVersion);
    }

    private String extractFederatedModelVersion(Long machineId) {
        try {
            Optional<RulPrediction> predOpt = predictionRepository.findFirstByMachineIdOrderByPredictionTimeDesc(machineId);
            if (predOpt.isPresent()) {
                var mv = predOpt.get().getModelVersion();
                if (mv != null && mv.getVersion() != null && mv.getVersion().toUpperCase().startsWith("FED")) {
                    return mv.getVersion();
                }
            }
        } catch (Exception e) {
            log.debug("No federated model version attribution found for machine {}: {}", machineId, e.getMessage());
        }
        return null;
    }

    @Override
    @Transactional
    public DigitalTwinStateResponse getDigitalTwinState(Long id) {
        DigitalTwin twin = digitalTwinRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Digital Twin not found with ID: " + id));

        DigitalTwinState state = stateRepository.findByDigitalTwinId(twin.getId())
                .orElseGet(() -> {
                    syncService.synchronizeMachine(twin.getMachine().getId());
                    return stateRepository.findByDigitalTwinId(twin.getId())
                            .orElseThrow(() -> new ResourceNotFoundException("Digital Twin state not available for ID: " + id));
                });

        return DigitalTwinStateResponse.fromEntity(state);
    }

    @Override
    public Page<DigitalTwinHistoryResponse> getDigitalTwinHistory(Long id, Pageable pageable) {
        if (!digitalTwinRepository.existsById(id)) {
            throw new ResourceNotFoundException("Digital Twin not found with ID: " + id);
        }
        return historyRepository.findByDigitalTwinIdOrderByTimestampDesc(id, pageable)
                .map(DigitalTwinHistoryResponse::fromEntity);
    }

    @Override
    public List<DigitalTwinSensorViewDto> getDigitalTwinSensors(Long id) {
        DigitalTwin twin = digitalTwinRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Digital Twin not found with ID: " + id));

        Long machineId = twin.getMachine().getId();
        List<Sensor> sensors = sensorRepository.findByMachineId(machineId);
        List<DigitalTwinSensorViewDto> views = new ArrayList<>();

        for (Sensor s : sensors) {
            Optional<SensorReading> latestReadingOpt = readingRepository.findFirstBySensorIdOrderByTimeDesc(s.getId());
            Double currentValue = null;
            Instant timestamp = null;
            String status = s.getHealthState() != null ? s.getHealthState().name() : "NORMAL";

            if (latestReadingOpt.isPresent()) {
                SensorReading sr = latestReadingOpt.get();
                currentValue = sr.getValue();
                timestamp = sr.getTime();
            }

            // Calculate trend from recent readings
            SensorTrend trend = calculateSensorTrend(s.getId(), currentValue);

            views.add(DigitalTwinSensorViewDto.builder()
                    .sensorId(s.getId())
                    .sensorCode(s.getSensorCode())
                    .sensorType(s.getSensorType())
                    .value(currentValue)
                    .unit(s.getUnit())
                    .status(status)
                    .timestamp(timestamp)
                    .trend(trend)
                    .build());
        }

        return views;
    }

    private SensorTrend calculateSensorTrend(Long sensorId, Double currentValue) {
        if (currentValue == null) return SensorTrend.UNKNOWN;
        try {
            Instant end = Instant.now();
            Instant start = end.minus(10, ChronoUnit.MINUTES);
            List<SensorReading> readings = readingRepository.findBySensorIdAndTimeBetweenOrderByTimeAsc(
                    sensorId, start, end, PageRequest.of(0, 10));

            if (readings.size() < 2) {
                return SensorTrend.STABLE;
            }

            double firstVal = readings.get(0).getValue();
            double diff = currentValue - firstVal;
            double baseline = Math.abs(firstVal) > 0.0001 ? Math.abs(firstVal) : 1.0;
            double relativeChange = diff / baseline;

            if (relativeChange > 0.01) {
                return SensorTrend.INCREASING;
            } else if (relativeChange < -0.01) {
                return SensorTrend.DECREASING;
            } else {
                return SensorTrend.STABLE;
            }
        } catch (Exception e) {
            return SensorTrend.UNKNOWN;
        }
    }

    @Override
    public List<AlertResponse> getDigitalTwinAlerts(Long id) {
        DigitalTwin twin = digitalTwinRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Digital Twin not found with ID: " + id));

        Long machineId = twin.getMachine().getId();
        return alertRepository.findByMachineIdAndStatusIn(machineId, List.of(AlertStatus.OPEN, AlertStatus.ACKNOWLEDGED))
                .stream()
                .map(AlertResponse::fromEntity)
                .toList();
    }

    @Override
    public List<DigitalTwinTimelineEventDto> getDigitalTwinTimeline(Long id) {
        DigitalTwin twin = digitalTwinRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Digital Twin not found with ID: " + id));

        Long machineId = twin.getMachine().getId();
        List<DigitalTwinTimelineEventDto> events = new ArrayList<>();

        // 1. Machine creation / setup event
        if (twin.getCreatedAt() != null) {
            events.add(DigitalTwinTimelineEventDto.builder()
                    .timestamp(twin.getCreatedAt())
                    .eventType("STATE_CHANGE")
                    .severity("INFO")
                    .title("Digital Twin Initialized")
                    .description("Digital Twin bound to machine " + twin.getMachine().getMachineCode())
                    .build());
        }

        // 2. State changes from History
        List<DigitalTwinStateHistory> historyList = historyRepository.findTop30ByDigitalTwinIdOrderByTimestampDesc(id);
        MachineOperatingState lastState = null;
        for (int i = historyList.size() - 1; i >= 0; i--) {
            DigitalTwinStateHistory h = historyList.get(i);
            if (lastState != null && lastState != h.getOperatingState()) {
                String sev = h.getOperatingState() == MachineOperatingState.CRITICAL || h.getOperatingState() == MachineOperatingState.FAILURE
                        ? "CRITICAL"
                        : h.getOperatingState() == MachineOperatingState.WARNING ? "WARNING" : "INFO";
                events.add(DigitalTwinTimelineEventDto.builder()
                        .timestamp(h.getTimestamp())
                        .eventType("STATE_CHANGE")
                        .severity(sev)
                        .title("Operating State Transition: " + h.getOperatingState())
                        .description(String.format("State shifted from %s to %s (Health: %.0f, RUL: %.1fh)",
                                lastState, h.getOperatingState(),
                                h.getHealthScore() != null ? h.getHealthScore() : 100,
                                h.getRulHours() != null ? h.getRulHours() : 0.0))
                        .build());
            }
            lastState = h.getOperatingState();
        }

        // 3. Alerts
        try {
            Page<MaintenanceAlert> alertPage = alertRepository.findByMachineIdOrderByCreatedAtDesc(machineId, PageRequest.of(0, 20));
            for (MaintenanceAlert a : alertPage.getContent()) {
                String sev = a.getSeverity() == AlertSeverity.CRITICAL ? "CRITICAL" : a.getSeverity() == AlertSeverity.WARNING ? "WARNING" : "INFO";
                if (a.getCreatedAt() != null) {
                    events.add(DigitalTwinTimelineEventDto.builder()
                            .timestamp(a.getCreatedAt())
                            .eventType("ALERT_CREATED")
                            .severity(sev)
                            .title("Alert Raised: " + a.getTitle())
                            .description(a.getDescription())
                            .build());
                }
                if (a.getAcknowledgedAt() != null) {
                    events.add(DigitalTwinTimelineEventDto.builder()
                            .timestamp(a.getAcknowledgedAt())
                            .eventType("ALERT_ACKNOWLEDGED")
                            .severity("INFO")
                            .title("Alert Acknowledged: " + a.getTitle())
                            .description("Acknowledged by " + (a.getAcknowledgedBy() != null ? a.getAcknowledgedBy() : "ENGINEER"))
                            .build());
                }
                if (a.getResolvedAt() != null) {
                    events.add(DigitalTwinTimelineEventDto.builder()
                            .timestamp(a.getResolvedAt())
                            .eventType("ALERT_RESOLVED")
                            .severity("INFO")
                            .title("Alert Resolved: " + a.getTitle())
                            .description("Resolved by " + (a.getResolvedBy() != null ? a.getResolvedBy() : "ENGINEER"))
                            .build());
                }
            }
        } catch (Exception e) {
            log.debug("Alert timeline query exception: {}", e.getMessage());
        }

        // 4. Meaningful RUL predictions (recent predictions)
        try {
            List<RulPrediction> preds = predictionRepository.findTop30ByMachineIdOrderByPredictionTimeDesc(machineId);
            for (int i = 0; i < Math.min(preds.size(), 10); i++) {
                RulPrediction p = preds.get(i);
                if (p != null && p.getPredictionTime() != null) {
                    Double rulHours = p.getRulHours();
                    String sev = (rulHours != null && rulHours <= 24.0) ? "CRITICAL"
                            : (rulHours != null && rulHours <= 72.0) ? "WARNING" : "INFO";
                    String versionStr = (p.getModelVersion() != null && p.getModelVersion().getVersion() != null)
                            ? p.getModelVersion().getVersion() : "Tribuo";
                    events.add(DigitalTwinTimelineEventDto.builder()
                            .timestamp(p.getPredictionTime())
                            .eventType("RUL_CHANGE")
                            .severity(sev)
                            .title(String.format("RUL Forecast: %.1f hours", rulHours != null ? rulHours : 0.0))
                            .description("Model " + versionStr + " estimated RUL with status " + p.getStatus())
                            .build());
                }
            }
        } catch (Exception e) {
            log.debug("RUL timeline query exception: {}", e.getMessage());
        }

        // Sort descending by timestamp
        events.sort((a, b) -> {
            if (a == null && b == null) return 0;
            if (a == null || a.getTimestamp() == null) return 1;
            if (b == null || b.getTimestamp() == null) return -1;
            return b.getTimestamp().compareTo(a.getTimestamp());
        });

        if (events.size() > 50) {
            return events.subList(0, 50);
        }
        return events;
    }
}
