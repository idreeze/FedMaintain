package com.fedmaintain.digitaltwin.entity;

import com.fedmaintain.machine.entity.Machine;
import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;

@Entity
@Table(
        name = "digital_twin_state_history",
        indexes = {
                @Index(name = "idx_dt_history_twin_time", columnList = "digital_twin_id, timestamp DESC"),
                @Index(name = "idx_dt_history_machine_time", columnList = "machine_id, timestamp DESC")
        }
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DigitalTwinStateHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "digital_twin_id", nullable = false)
    private DigitalTwin digitalTwin;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "machine_id", nullable = false)
    private Machine machine;

    @Column(name = "timestamp", nullable = false)
    @Builder.Default
    private Instant timestamp = Instant.now();

    @Enumerated(EnumType.STRING)
    @Column(name = "operating_state", nullable = false, length = 30)
    private MachineOperatingState operatingState;

    @Column(name = "health_score")
    private Double healthScore;

    @Column(name = "health_status", length = 30)
    private String healthStatus;

    @Column(name = "rul_hours")
    private Double rulHours;

    @Column(name = "rul_status", length = 30)
    private String rulStatus;

    @Column(name = "temperature")
    private Double temperature;

    @Column(name = "vibration")
    private Double vibration;

    @Column(name = "current")
    private Double current;

    @Column(name = "pressure")
    private Double pressure;

    @Column(name = "rpm")
    private Double rpm;

    @Column(name = "acoustic")
    private Double acoustic;

    @Column(name = "active_alert_count", nullable = false)
    @Builder.Default
    private Integer activeAlertCount = 0;
}
