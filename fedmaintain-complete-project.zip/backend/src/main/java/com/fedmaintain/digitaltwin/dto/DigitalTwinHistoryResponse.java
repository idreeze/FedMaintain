package com.fedmaintain.digitaltwin.dto;

import com.fedmaintain.digitaltwin.entity.DigitalTwinStateHistory;
import com.fedmaintain.digitaltwin.entity.MachineOperatingState;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DigitalTwinHistoryResponse {

    private Long id;
    private Long digitalTwinId;
    private Long machineId;
    private Instant timestamp;
    private MachineOperatingState operatingState;
    private Double healthScore;
    private String healthStatus;
    private Double rulHours;
    private String rulStatus;
    private Double temperature;
    private Double vibration;
    private Double current;
    private Double pressure;
    private Double rpm;
    private Double acoustic;
    private Integer activeAlertCount;

    public static DigitalTwinHistoryResponse fromEntity(DigitalTwinStateHistory h) {
        if (h == null) return null;
        return DigitalTwinHistoryResponse.builder()
                .id(h.getId())
                .digitalTwinId(h.getDigitalTwin() != null ? h.getDigitalTwin().getId() : null)
                .machineId(h.getMachine() != null ? h.getMachine().getId() : null)
                .timestamp(h.getTimestamp())
                .operatingState(h.getOperatingState())
                .healthScore(h.getHealthScore())
                .healthStatus(h.getHealthStatus())
                .rulHours(h.getRulHours())
                .rulStatus(h.getRulStatus())
                .temperature(h.getTemperature())
                .vibration(h.getVibration())
                .current(h.getCurrent())
                .pressure(h.getPressure())
                .rpm(h.getRpm())
                .acoustic(h.getAcoustic())
                .activeAlertCount(h.getActiveAlertCount())
                .build();
    }
}
