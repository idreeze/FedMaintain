package com.fedmaintain.digitaltwin.service;

import com.fedmaintain.alert.entity.AlertSeverity;
import com.fedmaintain.alert.entity.AlertType;
import com.fedmaintain.alert.entity.MaintenanceAlert;
import com.fedmaintain.digitaltwin.config.DigitalTwinProperties;
import com.fedmaintain.digitaltwin.entity.MachineOperatingState;
import com.fedmaintain.machine.entity.MachineStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.time.Instant;
import java.util.List;

/**
 * Deterministic State Transition Engine for Machine Digital Twins.
 * <p>
 * Evaluates operational conditions in strict priority order:
 * 1. MAINTENANCE
 * 2. OFFLINE
 * 3. FAILURE
 * 4. CRITICAL
 * 5. WARNING
 * 6. DEGRADING
 * 7. NORMAL
 * <p>
 * All thresholds are configurable engineering assumptions.
 */
@Component
public class DigitalTwinStateTransitionEngine {

    private static final Logger log = LoggerFactory.getLogger(DigitalTwinStateTransitionEngine.class);

    private final DigitalTwinProperties properties;

    public DigitalTwinStateTransitionEngine(DigitalTwinProperties properties) {
        this.properties = properties;
    }

    public MachineOperatingState determineOperatingState(
            MachineStatus machineStatus,
            Instant lastTelemetryTimestamp,
            Instant now,
            Double healthScore,
            String healthStatus,
            Double rulHours,
            String rulStatus,
            List<MaintenanceAlert> activeAlerts) {

        // 1. MAINTENANCE (explicit maintenance override)
        if (machineStatus == MachineStatus.MAINTENANCE) {
            return MachineOperatingState.MAINTENANCE;
        }

        // 2. OFFLINE (telemetry freshness verification)
        if (lastTelemetryTimestamp == null) {
            return MachineOperatingState.OFFLINE;
        }
        long secondsSinceTelemetry = Duration.between(lastTelemetryTimestamp, now).getSeconds();
        if (secondsSinceTelemetry > properties.getOfflineTimeoutSeconds()) {
            return MachineOperatingState.OFFLINE;
        }

        // 3. FAILURE (strong failure evidence required)
        boolean hasCriticalAlert = false;
        boolean hasWarningAlert = false;
        boolean hasFailureAlert = false;

        if (activeAlerts != null && !activeAlerts.isEmpty()) {
            for (MaintenanceAlert alert : activeAlerts) {
                if (alert.getSeverity() == AlertSeverity.CRITICAL) {
                    hasCriticalAlert = true;
                    if (alert.getAlertType() == AlertType.MULTI_SENSOR_DEGRADATION ||
                        (alert.getTitle() != null && alert.getTitle().toUpperCase().contains("FAILURE"))) {
                        hasFailureAlert = true;
                    }
                } else if (alert.getSeverity() == AlertSeverity.WARNING) {
                    hasWarningAlert = true;
                }
            }
        }

        double failureHealthThreshold = properties.getState().getFailureHealthScore();
        if (hasFailureAlert || (healthScore != null && healthScore <= failureHealthThreshold)) {
            return MachineOperatingState.FAILURE;
        }

        // 4. CRITICAL
        double criticalHealthThreshold = properties.getState().getCriticalHealthScore();
        double criticalRulThreshold = properties.getState().getCriticalRulHours();

        boolean isCriticalHealth = (healthScore != null && healthScore < criticalHealthThreshold) ||
                (healthStatus != null && healthStatus.equalsIgnoreCase("CRITICAL"));
        boolean isCriticalRul = (rulHours != null && rulHours <= criticalRulThreshold) ||
                (rulStatus != null && rulStatus.equalsIgnoreCase("CRITICAL"));

        if (hasCriticalAlert || isCriticalHealth || isCriticalRul) {
            return MachineOperatingState.CRITICAL;
        }

        // 5. WARNING
        double warningHealthThreshold = properties.getState().getWarningHealthScore();
        double warningRulThreshold = properties.getState().getWarningRulHours();

        boolean isWarningHealth = (healthScore != null && healthScore < warningHealthThreshold) ||
                (healthStatus != null && healthStatus.equalsIgnoreCase("WARNING"));
        boolean isWarningRul = (rulHours != null && rulHours <= warningRulThreshold) ||
                (rulStatus != null && rulStatus.equalsIgnoreCase("WARNING"));

        if (hasWarningAlert || isWarningHealth || isWarningRul) {
            return MachineOperatingState.WARNING;
        }

        // 6. DEGRADING
        double degradingHealthThreshold = properties.getState().getDegradingHealthScore();
        boolean isDegradingHealth = (healthScore != null && healthScore < degradingHealthThreshold) ||
                (healthStatus != null && (healthStatus.equalsIgnoreCase("WATCH") || healthStatus.equalsIgnoreCase("DEGRADED")));

        if (isDegradingHealth) {
            return MachineOperatingState.DEGRADING;
        }

        // 7. NORMAL
        return MachineOperatingState.NORMAL;
    }
}
