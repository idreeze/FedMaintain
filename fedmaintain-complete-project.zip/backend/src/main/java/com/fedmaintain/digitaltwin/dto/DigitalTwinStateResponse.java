package com.fedmaintain.digitaltwin.dto;

import com.fedmaintain.digitaltwin.entity.DigitalTwinState;
import com.fedmaintain.digitaltwin.entity.MachineOperatingState;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DigitalTwinStateResponse {

    private Long id;
    private Long digitalTwinId;
    private Long machineId;
    private MachineOperatingState operatingState;
    private Double temperature;
    private Double vibration;
    private Double current;
    private Double pressure;
    private Double rpm;
    private Double acoustic;
    private Double healthScore;
    private String healthStatus;
    private Double rulHours;
    private String rulStatus;
    private Instant lastTelemetryTimestamp;
    private Instant lastPredictionTimestamp;
    private Integer activeAlertCount;
    private Instant updatedAt;

    public static DigitalTwinStateResponse fromEntity(DigitalTwinState s) {
        if (s == null) return null;
        return DigitalTwinStateResponse.builder()
                .id(s.getId())
                .digitalTwinId(s.getDigitalTwin() != null ? s.getDigitalTwin().getId() : null)
                .machineId(s.getMachine() != null ? s.getMachine().getId() : null)
                .operatingState(s.getOperatingState())
                .temperature(s.getTemperature())
                .vibration(s.getVibration())
                .current(s.getCurrent())
                .pressure(s.getPressure())
                .rpm(s.getRpm())
                .acoustic(s.getAcoustic())
                .healthScore(s.getHealthScore())
                .healthStatus(s.getHealthStatus())
                .rulHours(s.getRulHours())
                .rulStatus(s.getRulStatus())
                .lastTelemetryTimestamp(s.getLastTelemetryTimestamp())
                .lastPredictionTimestamp(s.getLastPredictionTimestamp())
                .activeAlertCount(s.getActiveAlertCount())
                .updatedAt(s.getUpdatedAt())
                .build();
    }
}
