package com.fedmaintain.digitaltwin.entity;

public enum DigitalTwinStatus {
    ACTIVE,
    INACTIVE,
    OFFLINE,
    MAINTENANCE
}
