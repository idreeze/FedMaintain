package com.fedmaintain.digitaltwin.service.impl;

import com.fedmaintain.alert.entity.AlertStatus;
import com.fedmaintain.alert.entity.MaintenanceAlert;
import com.fedmaintain.alert.repository.MaintenanceAlertRepository;
import com.fedmaintain.digitaltwin.config.DigitalTwinProperties;
import com.fedmaintain.digitaltwin.dto.DigitalTwinStateResponse;
import com.fedmaintain.digitaltwin.entity.*;
import com.fedmaintain.digitaltwin.repository.DigitalTwinRepository;
import com.fedmaintain.digitaltwin.repository.DigitalTwinStateHistoryRepository;
import com.fedmaintain.digitaltwin.repository.DigitalTwinStateRepository;
import com.fedmaintain.digitaltwin.service.DigitalTwinStateTransitionEngine;
import com.fedmaintain.digitaltwin.service.DigitalTwinSynchronizationService;
import com.fedmaintain.exception.ResourceNotFoundException;
import com.fedmaintain.feature.dto.MachineFeatureDto;
import com.fedmaintain.feature.service.FeatureService;
import com.fedmaintain.machine.entity.Machine;
import com.fedmaintain.machine.entity.MachineStatus;
import com.fedmaintain.machine.repository.MachineRepository;
import com.fedmaintain.ml.dto.RulPredictionResponse;
import com.fedmaintain.ml.health.dto.MachineHealthResponse;
import com.fedmaintain.ml.health.service.MachineHealthService;
import com.fedmaintain.ml.prediction.RulPredictionService;
import com.fedmaintain.sensor.entity.SensorType;
import com.fedmaintain.telemetry.dto.MachineLatestReadingsResponse;
import com.fedmaintain.telemetry.service.TelemetryService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Optional;

@Service
public class DigitalTwinSynchronizationServiceImpl implements DigitalTwinSynchronizationService {

    private static final Logger log = LoggerFactory.getLogger(DigitalTwinSynchronizationServiceImpl.class);

    private final DigitalTwinRepository digitalTwinRepository;
    private final DigitalTwinStateRepository digitalTwinStateRepository;
    private final DigitalTwinStateHistoryRepository historyRepository;
    private final MachineRepository machineRepository;
    private final TelemetryService telemetryService;
    private final FeatureService featureService;
    private final RulPredictionService rulPredictionService;
    private final MachineHealthService machineHealthService;
    private final MaintenanceAlertRepository alertRepository;
    private final DigitalTwinStateTransitionEngine transitionEngine;
    private final DigitalTwinProperties properties;

    public DigitalTwinSynchronizationServiceImpl(
            DigitalTwinRepository digitalTwinRepository,
            DigitalTwinStateRepository digitalTwinStateRepository,
            DigitalTwinStateHistoryRepository historyRepository,
            MachineRepository machineRepository,
            TelemetryService telemetryService,
            FeatureService featureService,
            RulPredictionService rulPredictionService,
            MachineHealthService machineHealthService,
            MaintenanceAlertRepository alertRepository,
            DigitalTwinStateTransitionEngine transitionEngine,
            DigitalTwinProperties properties) {
        this.digitalTwinRepository = digitalTwinRepository;
        this.digitalTwinStateRepository = digitalTwinStateRepository;
        this.historyRepository = historyRepository;
        this.machineRepository = machineRepository;
        this.telemetryService = telemetryService;
        this.featureService = featureService;
        this.rulPredictionService = rulPredictionService;
        this.machineHealthService = machineHealthService;
        this.alertRepository = alertRepository;
        this.transitionEngine = transitionEngine;
        this.properties = properties;
    }

    @Override
    @Transactional
    public DigitalTwinStateResponse synchronizeMachine(Long machineId) {
        Machine machine = machineRepository.findById(machineId)
                .orElseThrow(() -> new ResourceNotFoundException("Machine not found with ID: " + machineId));

        // Auto-register Digital Twin if none exists yet
        DigitalTwin digitalTwin = getOrCreateDigitalTwin(machine);

        Instant now = Instant.now();

        // 1. Telemetry Ingestion
        Double temp = null;
        Double vib = null;
        Double current = null;
        Double pressure = null;
        Double rpm = null;
        Double acoustic = null;
        Instant lastTelemetryTs = null;

        try {
            MachineLatestReadingsResponse latestReadings = telemetryService.getLatestReadingsByMachine(machineId);
            if (latestReadings != null && latestReadings.getReadings() != null) {
                for (var r : latestReadings.getReadings()) {
                    if (r.getTimestamp() != null && (lastTelemetryTs == null || r.getTimestamp().isAfter(lastTelemetryTs))) {
                        lastTelemetryTs = r.getTimestamp();
                    }
                    if (r.getSensorType() == SensorType.TEMPERATURE) temp = r.getValue();
                    else if (r.getSensorType() == SensorType.VIBRATION) vib = r.getValue();
                    else if (r.getSensorType() == SensorType.CURRENT) current = r.getValue();
                    else if (r.getSensorType() == SensorType.PRESSURE) pressure = r.getValue();
                    else if (r.getSensorType() == SensorType.RPM) rpm = r.getValue();
                    else if (r.getSensorType() == SensorType.ACOUSTIC) acoustic = r.getValue();
                }
            }
        } catch (Exception e) {
            log.debug("Telemetry query fallback for machine {}: {}", machineId, e.getMessage());
        }

        // 2. Feature Engineering Ingestion (fallback values if telemetry list was partial)
        try {
            MachineFeatureDto latestFeature = featureService.getLatestFeature(machineId);
            if (latestFeature != null) {
                if (temp == null && latestFeature.getTemperatureMean() != null) temp = latestFeature.getTemperatureMean();
                if (vib == null && latestFeature.getVibrationRms() != null) vib = latestFeature.getVibrationRms();
                if (current == null && latestFeature.getCurrentMean() != null) current = latestFeature.getCurrentMean();
                if (pressure == null && latestFeature.getPressureMean() != null) pressure = latestFeature.getPressureMean();
                if (rpm == null && latestFeature.getRpmMean() != null) rpm = latestFeature.getRpmMean();
                if (acoustic == null && latestFeature.getAcousticMean() != null) acoustic = latestFeature.getAcousticMean();
                if (lastTelemetryTs == null && latestFeature.getWindowEnd() != null) lastTelemetryTs = latestFeature.getWindowEnd();
            }
        } catch (Exception e) {
            log.debug("Feature query fallback for machine {}: {}", machineId, e.getMessage());
        }

        // 3. RUL Prediction Ingestion
        Double rulHours = null;
        String rulStatus = null;
        Instant lastPredictionTs = null;
        try {
            RulPredictionResponse latestRul = rulPredictionService.getLatestPrediction(machineId);
            if (latestRul != null) {
                rulHours = latestRul.getRulHours();
                rulStatus = latestRul.getStatus() != null ? latestRul.getStatus().name() : null;
                lastPredictionTs = latestRul.getPredictionTime();
            }
        } catch (Exception e) {
            log.debug("RUL prediction lookup fallback for machine {}: {}", machineId, e.getMessage());
        }

        // 4. Health Score Ingestion
        Double healthScore = null;
        String healthStatus = null;
        try {
            MachineHealthResponse health = machineHealthService.calculateHealth(machineId);
            if (health != null) {
                healthScore = health.getHealthScore() != null ? health.getHealthScore().doubleValue() : null;
                healthStatus = health.getStatus() != null ? health.getStatus().name() : null;
            }
        } catch (Exception e) {
            log.debug("Machine health lookup fallback for machine {}: {}", machineId, e.getMessage());
        }

        // 5. Active Alerts Ingestion
        List<MaintenanceAlert> activeAlerts = alertRepository.findByMachineIdAndStatusIn(
                machineId, List.of(AlertStatus.OPEN, AlertStatus.ACKNOWLEDGED));
        int activeAlertCount = activeAlerts.size();

        // 6. State Transition Determination
        MachineOperatingState operatingState = transitionEngine.determineOperatingState(
                machine.getStatus(),
                lastTelemetryTs,
                now,
                healthScore,
                healthStatus,
                rulHours,
                rulStatus,
                activeAlerts
        );

        // 7. Persist or Update DigitalTwinState
        DigitalTwinState state = digitalTwinStateRepository.findByDigitalTwinId(digitalTwin.getId())
                .orElseGet(() -> DigitalTwinState.builder()
                        .digitalTwin(digitalTwin)
                        .machine(machine)
                        .build());

        MachineOperatingState previousState = state.getOperatingState();

        state.setOperatingState(operatingState);
        state.setTemperature(temp);
        state.setVibration(vib);
        state.setCurrent(current);
        state.setPressure(pressure);
        state.setRpm(rpm);
        state.setAcoustic(acoustic);
        state.setHealthScore(healthScore);
        state.setHealthStatus(healthStatus);
        state.setRulHours(rulHours);
        state.setRulStatus(rulStatus);
        state.setLastTelemetryTimestamp(lastTelemetryTs);
        state.setLastPredictionTimestamp(lastPredictionTs);
        state.setActiveAlertCount(activeAlertCount);
        state.setUpdatedAt(now);

        DigitalTwinState savedState = digitalTwinStateRepository.save(state);

        // Update Digital Twin header
        digitalTwin.setLastSynchronizedAt(now);
        if (operatingState == MachineOperatingState.OFFLINE) {
            digitalTwin.setStatus(DigitalTwinStatus.OFFLINE);
        } else if (operatingState == MachineOperatingState.MAINTENANCE) {
            digitalTwin.setStatus(DigitalTwinStatus.MAINTENANCE);
        } else {
            digitalTwin.setStatus(DigitalTwinStatus.ACTIVE);
        }
        digitalTwinRepository.save(digitalTwin);

        // 8. History Snapshot Logic
        recordHistorySnapshotIfNecessary(digitalTwin, machine, savedState, previousState, now);

        log.info("Digital Twin synchronized: twinCode={}, machine={}, state={}, health={}, alerts={}",
                digitalTwin.getTwinCode(), machine.getMachineCode(), operatingState, healthScore, activeAlertCount);

        return DigitalTwinStateResponse.fromEntity(savedState);
    }

    private void recordHistorySnapshotIfNecessary(
            DigitalTwin digitalTwin,
            Machine machine,
            DigitalTwinState currentState,
            MachineOperatingState previousState,
            Instant now) {

        Optional<DigitalTwinStateHistory> lastSnapshotOpt = historyRepository.findFirstByDigitalTwinIdOrderByTimestampDesc(digitalTwin.getId());

        boolean shouldRecord = false;

        if (lastSnapshotOpt.isEmpty()) {
            shouldRecord = true;
        } else {
            DigitalTwinStateHistory last = lastSnapshotOpt.get();
            // Immediate record on state transition
            if (previousState != null && previousState != currentState.getOperatingState()) {
                shouldRecord = true;
            } else {
                long minutesSinceLastSnapshot = Duration.between(last.getTimestamp(), now).toMinutes();
                if (minutesSinceLastSnapshot >= properties.getHistoryIntervalMinutes()) {
                    // Check if values have materially changed to avoid pure duplicate spam
                    boolean changed = isMateriallyDifferent(last, currentState);
                    if (changed || minutesSinceLastSnapshot >= (properties.getHistoryIntervalMinutes() * 2)) {
                        shouldRecord = true;
                    }
                }
            }
        }

        if (shouldRecord) {
            DigitalTwinStateHistory history = DigitalTwinStateHistory.builder()
                    .digitalTwin(digitalTwin)
                    .machine(machine)
                    .timestamp(now)
                    .operatingState(currentState.getOperatingState())
                    .healthScore(currentState.getHealthScore())
                    .healthStatus(currentState.getHealthStatus())
                    .rulHours(currentState.getRulHours())
                    .rulStatus(currentState.getRulStatus())
                    .temperature(currentState.getTemperature())
                    .vibration(currentState.getVibration())
                    .current(currentState.getCurrent())
                    .pressure(currentState.getPressure())
                    .rpm(currentState.getRpm())
                    .acoustic(currentState.getAcoustic())
                    .activeAlertCount(currentState.getActiveAlertCount())
                    .build();
            historyRepository.save(history);
        }
    }

    private boolean isMateriallyDifferent(DigitalTwinStateHistory h, DigitalTwinState s) {
        if (h.getOperatingState() != s.getOperatingState()) return true;
        if (!valuesMatch(h.getHealthScore(), s.getHealthScore(), 1.0)) return true;
        if (!valuesMatch(h.getRulHours(), s.getRulHours(), 0.5)) return true;
        if (!valuesMatch(h.getTemperature(), s.getTemperature(), 0.5)) return true;
        if (!valuesMatch(h.getVibration(), s.getVibration(), 0.1)) return true;
        if (!valuesMatch(h.getCurrent(), s.getCurrent(), 0.2)) return true;
        if (h.getActiveAlertCount() != null && !h.getActiveAlertCount().equals(s.getActiveAlertCount())) return true;
        return false;
    }

    private boolean valuesMatch(Double v1, Double v2, double tolerance) {
        if (v1 == null && v2 == null) return true;
        if (v1 == null || v2 == null) return false;
        return Math.abs(v1 - v2) <= tolerance;
    }

    private synchronized DigitalTwin getOrCreateDigitalTwin(Machine machine) {
        return digitalTwinRepository.findByMachineId(machine.getId())
                .orElseGet(() -> {
                    String twinCode = "DT-" + machine.getMachineCode();
                    return digitalTwinRepository.save(DigitalTwin.builder()
                            .twinCode(twinCode)
                            .machine(machine)
                            .status(DigitalTwinStatus.ACTIVE)
                            .createdAt(Instant.now())
                            .updatedAt(Instant.now())
                            .build());
                });
    }

    @Override
    public void synchronizeAllActiveMachines() {
        if (!properties.isSyncEnabled()) {
            return;
        }
        List<Machine> machines = machineRepository.findAll();
        for (Machine machine : machines) {
            if (machine.getStatus() != MachineStatus.DECOMMISSIONED) {
                try {
                    synchronizeMachine(machine.getId());
                } catch (Exception e) {
                    log.error("Failed to synchronize Digital Twin for machine {}: {}", machine.getMachineCode(), e.getMessage());
                }
            }
        }
    }

    @Scheduled(
            fixedRateString = "${fedmaintain.digitaltwin.sync-interval-ms:60000}",
            initialDelay = 15000
    )
    public void scheduledDigitalTwinSync() {
        try {
            synchronizeAllActiveMachines();
        } catch (Exception e) {
            log.error("Error during scheduled digital twin synchronization: {}", e.getMessage());
        }
    }
}
