package com.fedmaintain.digitaltwin.dto;

import com.fedmaintain.digitaltwin.entity.DigitalTwin;
import com.fedmaintain.digitaltwin.entity.DigitalTwinStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DigitalTwinResponse {

    private Long id;
    private String twinCode;
    private Long machineId;
    private String machineCode;
    private String machineName;
    private String machineType;
    private String plantCode;
    private String plantName;
    private String areaName;
    private DigitalTwinStatus status;
    private Instant createdAt;
    private Instant updatedAt;
    private Instant lastSynchronizedAt;
    private DigitalTwinStateResponse currentState;
    private String federatedModelVersion;

    public DigitalTwinStateResponse getState() {
        return currentState;
    }

    public static DigitalTwinResponse fromEntity(DigitalTwin dt, DigitalTwinStateResponse state, String federatedModelVersion) {
        if (dt == null) return null;
        var m = dt.getMachine();
        String pCode = null;
        String pName = null;
        String aName = null;
        if (m != null && m.getProductionArea() != null) {
            aName = m.getProductionArea().getName();
            if (m.getProductionArea().getPlant() != null) {
                pCode = m.getProductionArea().getPlant().getCode();
                pName = m.getProductionArea().getPlant().getName();
            }
        }

        return DigitalTwinResponse.builder()
                .id(dt.getId())
                .twinCode(dt.getTwinCode())
                .machineId(m != null ? m.getId() : null)
                .machineCode(m != null ? m.getMachineCode() : null)
                .machineName(m != null ? m.getName() : null)
                .machineType(m != null ? m.getMachineType() : null)
                .plantCode(pCode)
                .plantName(pName)
                .areaName(aName)
                .status(dt.getStatus())
                .createdAt(dt.getCreatedAt())
                .updatedAt(dt.getUpdatedAt())
                .lastSynchronizedAt(dt.getLastSynchronizedAt())
                .currentState(state)
                .federatedModelVersion(federatedModelVersion)
                .build();
    }
}
