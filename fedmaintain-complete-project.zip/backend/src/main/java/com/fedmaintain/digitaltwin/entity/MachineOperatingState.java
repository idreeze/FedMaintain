package com.fedmaintain.digitaltwin.entity;

public enum MachineOperatingState {
    NORMAL,
    DEGRADING,
    WARNING,
    CRITICAL,
    FAILURE,
    OFFLINE,
    MAINTENANCE
}
