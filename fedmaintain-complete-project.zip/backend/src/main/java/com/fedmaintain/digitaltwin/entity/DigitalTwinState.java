package com.fedmaintain.digitaltwin.entity;

import com.fedmaintain.machine.entity.Machine;
import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;

@Entity
@Table(
        name = "digital_twin_states",
        indexes = {
                @Index(name = "idx_dt_states_machine", columnList = "machine_id")
        }
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DigitalTwinState {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "digital_twin_id", nullable = false, unique = true)
    private DigitalTwin digitalTwin;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "machine_id", nullable = false)
    private Machine machine;

    @Enumerated(EnumType.STRING)
    @Column(name = "operating_state", nullable = false, length = 30)
    @Builder.Default
    private MachineOperatingState operatingState = MachineOperatingState.NORMAL;

    @Column(name = "temperature")
    private Double temperature;

    @Column(name = "vibration")
    private Double vibration;

    @Column(name = "current")
    private Double current;

    @Column(name = "pressure")
    private Double pressure;

    @Column(name = "rpm")
    private Double rpm;

    @Column(name = "acoustic")
    private Double acoustic;

    @Column(name = "health_score")
    private Double healthScore;

    @Column(name = "health_status", length = 30)
    private String healthStatus;

    @Column(name = "rul_hours")
    private Double rulHours;

    @Column(name = "rul_status", length = 30)
    private String rulStatus;

    @Column(name = "last_telemetry_timestamp")
    private Instant lastTelemetryTimestamp;

    @Column(name = "last_prediction_timestamp")
    private Instant lastPredictionTimestamp;

    @Column(name = "active_alert_count", nullable = false)
    @Builder.Default
    private Integer activeAlertCount = 0;

    @Column(name = "updated_at", nullable = false)
    @Builder.Default
    private Instant updatedAt = Instant.now();

    @PrePersist
    @PreUpdate
    protected void onPersistOrUpdate() {
        this.updatedAt = Instant.now();
    }
}
