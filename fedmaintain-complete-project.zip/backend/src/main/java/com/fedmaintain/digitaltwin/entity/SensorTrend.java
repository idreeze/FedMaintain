package com.fedmaintain.digitaltwin.entity;

public enum SensorTrend {
    INCREASING,
    DECREASING,
    STABLE,
    UNKNOWN
}
