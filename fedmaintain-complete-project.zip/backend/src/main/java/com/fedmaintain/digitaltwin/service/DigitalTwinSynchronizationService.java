package com.fedmaintain.digitaltwin.service;

import com.fedmaintain.digitaltwin.dto.DigitalTwinStateResponse;

public interface DigitalTwinSynchronizationService {

    DigitalTwinStateResponse synchronizeMachine(Long machineId);

    void synchronizeAllActiveMachines();
}
