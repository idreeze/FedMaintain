package com.fedmaintain.digitaltwin.service;

import com.fedmaintain.alert.dto.AlertResponse;
import com.fedmaintain.digitaltwin.dto.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface DigitalTwinService {

    List<DigitalTwinSummaryResponse> getAllDigitalTwins();

    DigitalTwinResponse getDigitalTwinById(Long id);

    DigitalTwinResponse getDigitalTwinByMachineId(Long machineId);

    DigitalTwinStateResponse getDigitalTwinState(Long id);

    Page<DigitalTwinHistoryResponse> getDigitalTwinHistory(Long id, Pageable pageable);

    List<DigitalTwinSensorViewDto> getDigitalTwinSensors(Long id);

    List<AlertResponse> getDigitalTwinAlerts(Long id);

    List<DigitalTwinTimelineEventDto> getDigitalTwinTimeline(Long id);
}
