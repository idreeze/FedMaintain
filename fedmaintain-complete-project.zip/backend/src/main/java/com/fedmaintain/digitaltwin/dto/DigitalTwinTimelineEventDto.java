package com.fedmaintain.digitaltwin.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DigitalTwinTimelineEventDto {

    private Instant timestamp;
    private String eventType;
    private String severity;
    private String title;
    private String description;
}
