package com.fedmaintain.digitaltwin.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
@ConfigurationProperties(prefix = "fedmaintain.digitaltwin")
public class DigitalTwinProperties {

    private boolean syncEnabled = true;
    private long syncIntervalMs = 60000L;
    private long offlineTimeoutSeconds = 60L;
    private long historyIntervalMinutes = 5L;

    private StateThresholds state = new StateThresholds();

    @Data
    public static class StateThresholds {
        private double criticalRulHours = 24.0;
        private double warningRulHours = 72.0;
        private double criticalHealthScore = 40.0;
        private double warningHealthScore = 60.0;
        private double degradingHealthScore = 80.0;
        private double failureHealthScore = 20.0;
    }
}
