package com.fedmaintain.digitaltwin.dto;

import com.fedmaintain.digitaltwin.entity.DigitalTwin;
import com.fedmaintain.digitaltwin.entity.DigitalTwinState;
import com.fedmaintain.digitaltwin.entity.DigitalTwinStatus;
import com.fedmaintain.digitaltwin.entity.MachineOperatingState;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DigitalTwinSummaryResponse {

    private Long id;
    private String twinCode;
    private Long machineId;
    private String machineCode;
    private String machineName;
    private String machineType;
    private String plantCode;
    private String areaName;
    private DigitalTwinStatus status;
    private MachineOperatingState operatingState;
    private Double healthScore;
    private Double rulHours;
    private Integer activeAlertCount;
    private Instant lastSynchronizedAt;

    public static DigitalTwinSummaryResponse fromEntity(DigitalTwin dt, DigitalTwinState state) {
        if (dt == null) return null;
        var m = dt.getMachine();
        String pCode = null;
        String aName = null;
        if (m != null && m.getProductionArea() != null) {
            aName = m.getProductionArea().getName();
            if (m.getProductionArea().getPlant() != null) {
                pCode = m.getProductionArea().getPlant().getCode();
            }
        }

        return DigitalTwinSummaryResponse.builder()
                .id(dt.getId())
                .twinCode(dt.getTwinCode())
                .machineId(m != null ? m.getId() : null)
                .machineCode(m != null ? m.getMachineCode() : null)
                .machineName(m != null ? m.getName() : null)
                .machineType(m != null ? m.getMachineType() : null)
                .plantCode(pCode)
                .areaName(aName)
                .status(dt.getStatus())
                .operatingState(state != null ? state.getOperatingState() : MachineOperatingState.OFFLINE)
                .healthScore(state != null ? state.getHealthScore() : null)
                .rulHours(state != null ? state.getRulHours() : null)
                .activeAlertCount(state != null ? state.getActiveAlertCount() : 0)
                .lastSynchronizedAt(dt.getLastSynchronizedAt())
                .build();
    }
}
