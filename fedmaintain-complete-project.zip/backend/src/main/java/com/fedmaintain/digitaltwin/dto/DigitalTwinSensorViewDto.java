package com.fedmaintain.digitaltwin.dto;

import com.fedmaintain.digitaltwin.entity.SensorTrend;
import com.fedmaintain.sensor.entity.SensorType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DigitalTwinSensorViewDto {

    private Long sensorId;
    private String sensorCode;
    private SensorType sensorType;
    private Double value;
    private String unit;
    private String status;
    private Instant timestamp;
    private SensorTrend trend;
}
