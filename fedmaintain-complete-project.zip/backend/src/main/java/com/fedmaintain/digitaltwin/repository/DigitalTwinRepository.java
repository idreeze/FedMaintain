package com.fedmaintain.digitaltwin.repository;

import com.fedmaintain.digitaltwin.entity.DigitalTwin;
import com.fedmaintain.digitaltwin.entity.DigitalTwinStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface DigitalTwinRepository extends JpaRepository<DigitalTwin, Long> {

    Optional<DigitalTwin> findByMachineId(Long machineId);

    Optional<DigitalTwin> findByTwinCode(String twinCode);

    boolean existsByMachineId(Long machineId);

    boolean existsByTwinCode(String twinCode);

    List<DigitalTwin> findAllByOrderByTwinCodeAsc();

    List<DigitalTwin> findByStatus(DigitalTwinStatus status);
}
