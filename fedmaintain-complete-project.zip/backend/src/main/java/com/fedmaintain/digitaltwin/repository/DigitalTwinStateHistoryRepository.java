package com.fedmaintain.digitaltwin.repository;

import com.fedmaintain.digitaltwin.entity.DigitalTwinStateHistory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

@Repository
public interface DigitalTwinStateHistoryRepository extends JpaRepository<DigitalTwinStateHistory, Long> {

    Page<DigitalTwinStateHistory> findByDigitalTwinIdOrderByTimestampDesc(Long digitalTwinId, Pageable pageable);

    List<DigitalTwinStateHistory> findTop30ByDigitalTwinIdOrderByTimestampDesc(Long digitalTwinId);

    Optional<DigitalTwinStateHistory> findFirstByDigitalTwinIdOrderByTimestampDesc(Long digitalTwinId);

    List<DigitalTwinStateHistory> findByDigitalTwinIdAndTimestampBetweenOrderByTimestampAsc(
            Long digitalTwinId, Instant start, Instant end);
}
