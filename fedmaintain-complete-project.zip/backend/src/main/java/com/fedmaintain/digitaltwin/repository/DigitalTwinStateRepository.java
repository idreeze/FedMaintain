package com.fedmaintain.digitaltwin.repository;

import com.fedmaintain.digitaltwin.entity.DigitalTwinState;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface DigitalTwinStateRepository extends JpaRepository<DigitalTwinState, Long> {

    Optional<DigitalTwinState> findByDigitalTwinId(Long digitalTwinId);

    Optional<DigitalTwinState> findByMachineId(Long machineId);
}
