package com.fedmaintain.telemetry.service;

import com.fedmaintain.telemetry.dto.MachineLatestReadingsResponse;
import com.fedmaintain.telemetry.dto.SensorReadingDto;
import com.fedmaintain.telemetry.dto.SensorReadingMessage;
import com.fedmaintain.telemetry.dto.TelemetrySummaryResponse;

import java.time.Instant;
import java.util.List;

public interface TelemetryService {

    List<SensorReadingDto> getReadingsBySensor(Long sensorId, Instant start, Instant end, int limit);

    List<SensorReadingDto> getReadingsByMachine(Long machineId, Instant start, Instant end, int limit);

    SensorReadingDto getLatestReadingBySensor(Long sensorId);

    MachineLatestReadingsResponse getLatestReadingsByMachine(Long machineId);

    TelemetrySummaryResponse getTelemetrySummary(Long machineId);

    void processIncomingReading(SensorReadingMessage message);
}
