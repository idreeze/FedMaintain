package com.fedmaintain.telemetry.dto;

import com.fedmaintain.sensor.entity.ReadingQuality;
import com.fedmaintain.sensor.entity.SensorHealthState;
import com.fedmaintain.sensor.entity.SensorType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MachineLatestReadingsResponse {

    private String machineCode;
    private Long machineId;
    private List<LatestReadingItem> readings;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class LatestReadingItem {
        private String sensorCode;
        private SensorType sensorType;
        private Double value;
        private String unit;
        private Instant timestamp;
        private ReadingQuality quality;
        private SensorHealthState status;
    }
}
