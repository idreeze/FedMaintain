package com.fedmaintain.telemetry.dto;

import com.fedmaintain.sensor.entity.SensorHealthState;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;
import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TelemetrySummaryResponse {

    private String machineCode;
    private Long machineId;
    private Map<String, SensorSummaryMetric> sensors;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class SensorSummaryMetric {
        private String sensorCode;
        private Double current;
        private Double average;
        private Double minimum;
        private Double maximum;
        private String unit;
        private Instant latestTimestamp;
        private SensorHealthState status;
    }
}
