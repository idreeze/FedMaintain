package com.fedmaintain.telemetry.service.impl;

import com.fedmaintain.exception.ResourceNotFoundException;
import com.fedmaintain.machine.entity.Machine;
import com.fedmaintain.machine.repository.MachineRepository;
import com.fedmaintain.sensor.entity.ReadingQuality;
import com.fedmaintain.sensor.entity.Sensor;
import com.fedmaintain.sensor.entity.SensorHealthState;
import com.fedmaintain.sensor.entity.SensorReading;
import com.fedmaintain.sensor.repository.SensorReadingRepository;
import com.fedmaintain.sensor.repository.SensorRepository;
import com.fedmaintain.telemetry.dto.MachineLatestReadingsResponse;
import com.fedmaintain.telemetry.dto.SensorReadingDto;
import com.fedmaintain.telemetry.dto.SensorReadingMessage;
import com.fedmaintain.telemetry.dto.TelemetrySummaryResponse;
import com.fedmaintain.telemetry.service.TelemetryService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@Transactional(readOnly = true)
public class TelemetryServiceImpl implements TelemetryService {

    private static final Logger log = LoggerFactory.getLogger(TelemetryServiceImpl.class);

    private final SensorReadingRepository sensorReadingRepository;
    private final SensorRepository sensorRepository;
    private final MachineRepository machineRepository;

    public TelemetryServiceImpl(
            SensorReadingRepository sensorReadingRepository,
            SensorRepository sensorRepository,
            MachineRepository machineRepository) {
        this.sensorReadingRepository = sensorReadingRepository;
        this.sensorRepository = sensorRepository;
        this.machineRepository = machineRepository;
    }

    @Override
    public List<SensorReadingDto> getReadingsBySensor(Long sensorId, Instant start, Instant end, int limit) {
        if (!sensorRepository.existsById(sensorId)) {
            throw new ResourceNotFoundException("Sensor not found with id: " + sensorId);
        }

        Instant effectiveEnd = end != null ? end : Instant.now();
        Instant effectiveStart = start != null ? start : effectiveEnd.minus(1, ChronoUnit.HOURS);
        int effectiveLimit = Math.min(Math.max(limit, 1), 2000);

        Pageable pageable = PageRequest.of(0, effectiveLimit);
        List<SensorReading> readings = sensorReadingRepository.findBySensorIdAndTimeBetweenOrderByTimeAsc(
                sensorId, effectiveStart, effectiveEnd, pageable);

        return readings.stream()
                .map(SensorReadingDto::fromEntity)
                .collect(Collectors.toList());
    }

    @Override
    public List<SensorReadingDto> getReadingsByMachine(Long machineId, Instant start, Instant end, int limit) {
        if (!machineRepository.existsById(machineId)) {
            throw new ResourceNotFoundException("Machine not found with id: " + machineId);
        }

        Instant effectiveEnd = end != null ? end : Instant.now();
        Instant effectiveStart = start != null ? start : effectiveEnd.minus(1, ChronoUnit.HOURS);
        int effectiveLimit = Math.min(Math.max(limit, 1), 2000);

        Pageable pageable = PageRequest.of(0, effectiveLimit);
        List<SensorReading> readings = sensorReadingRepository.findByMachineIdAndTimeBetweenOrderByTimeAsc(
                machineId, effectiveStart, effectiveEnd, pageable);

        return readings.stream()
                .map(SensorReadingDto::fromEntity)
                .collect(Collectors.toList());
    }

    @Override
    public SensorReadingDto getLatestReadingBySensor(Long sensorId) {
        if (!sensorRepository.existsById(sensorId)) {
            throw new ResourceNotFoundException("Sensor not found with id: " + sensorId);
        }

        return sensorReadingRepository.findFirstBySensorIdOrderByTimeDesc(sensorId)
                .map(SensorReadingDto::fromEntity)
                .orElse(null);
    }

    @Override
    public MachineLatestReadingsResponse getLatestReadingsByMachine(Long machineId) {
        Machine machine = machineRepository.findById(machineId)
                .orElseThrow(() -> new ResourceNotFoundException("Machine not found with id: " + machineId));

        List<Sensor> sensors = sensorRepository.findByMachineId(machineId);
        List<MachineLatestReadingsResponse.LatestReadingItem> items = new ArrayList<>();

        for (Sensor sensor : sensors) {
            Double val = sensor.getLastReadingValue();
            Instant ts = sensor.getLastReadingTime();
            SensorHealthState state = sensor.getHealthState();

            ReadingQuality q = ReadingQuality.GOOD;
            if (state == SensorHealthState.CRITICAL) q = ReadingQuality.BAD;
            else if (state == SensorHealthState.WARNING) q = ReadingQuality.WARNING;

            items.add(MachineLatestReadingsResponse.LatestReadingItem.builder()
                    .sensorCode(sensor.getSensorCode())
                    .sensorType(sensor.getSensorType())
                    .value(val)
                    .unit(sensor.getUnit())
                    .timestamp(ts)
                    .quality(q)
                    .status(state)
                    .build());
        }

        return MachineLatestReadingsResponse.builder()
                .machineId(machine.getId())
                .machineCode(machine.getMachineCode())
                .readings(items)
                .build();
    }

    @Override
    public TelemetrySummaryResponse getTelemetrySummary(Long machineId) {
        Machine machine = machineRepository.findById(machineId)
                .orElseThrow(() -> new ResourceNotFoundException("Machine not found with id: " + machineId));

        List<Sensor> sensors = sensorRepository.findByMachineId(machineId);
        Map<String, TelemetrySummaryResponse.SensorSummaryMetric> metrics = new HashMap<>();

        Instant oneHourAgo = Instant.now().minus(1, ChronoUnit.HOURS);

        for (Sensor sensor : sensors) {
            Double current = sensor.getLastReadingValue();
            Double avg = sensorReadingRepository.getAverageValueSince(sensor.getId(), oneHourAgo);
            Double min = sensorReadingRepository.getMinValueSince(sensor.getId(), oneHourAgo);
            Double max = sensorReadingRepository.getMaxValueSince(sensor.getId(), oneHourAgo);

            double effectiveAvg = avg != null ? Math.round(avg * 10.0) / 10.0 : (current != null ? current : 0.0);
            double effectiveMin = min != null ? min : (current != null ? current : 0.0);
            double effectiveMax = max != null ? max : (current != null ? current : 0.0);

            String metricKey = sensor.getSensorType().name().toLowerCase();
            metrics.put(metricKey, TelemetrySummaryResponse.SensorSummaryMetric.builder()
                    .sensorCode(sensor.getSensorCode())
                    .current(current)
                    .average(effectiveAvg)
                    .minimum(effectiveMin)
                    .maximum(effectiveMax)
                    .unit(sensor.getUnit())
                    .latestTimestamp(sensor.getLastReadingTime())
                    .status(sensor.getHealthState())
                    .build());
        }

        return TelemetrySummaryResponse.builder()
                .machineId(machine.getId())
                .machineCode(machine.getMachineCode())
                .sensors(metrics)
                .build();
    }

    @Override
    @Transactional
    public void processIncomingReading(SensorReadingMessage message) {
        if (message == null || message.getMachineCode() == null || message.getSensorCode() == null) {
            log.warn("Discarding malformed MQTT sensor reading message: {}", message);
            return;
        }

        Machine machine = machineRepository.findByMachineCode(message.getMachineCode()).orElse(null);
        if (machine == null) {
            log.warn("Received telemetry for unknown machine: {}", message.getMachineCode());
            return;
        }

        Sensor sensor = sensorRepository.findBySensorCode(message.getSensorCode()).orElse(null);
        if (sensor == null) {
            log.warn("Received telemetry for unknown sensor: {}", message.getSensorCode());
            return;
        }

        if (!sensor.getMachine().getId().equals(machine.getId())) {
            log.warn("Sensor {} does not belong to machine {}", message.getSensorCode(), message.getMachineCode());
            return;
        }

        Double value = message.getValue();
        ReadingQuality quality = ReadingQuality.GOOD;
        SensorHealthState healthState = SensorHealthState.NORMAL;

        // Evaluate thresholds
        if (sensor.getCriticalThreshold() != null && value >= sensor.getCriticalThreshold()) {
            quality = ReadingQuality.BAD;
            healthState = SensorHealthState.CRITICAL;
        } else if (sensor.getWarningThreshold() != null && value >= sensor.getWarningThreshold()) {
            quality = ReadingQuality.WARNING;
            healthState = SensorHealthState.WARNING;
        } else if (sensor.getMinOperatingValue() != null && value < sensor.getMinOperatingValue()) {
            quality = ReadingQuality.WARNING;
            healthState = SensorHealthState.WARNING;
        } else if (sensor.getMaxOperatingValue() != null && value > sensor.getMaxOperatingValue()) {
            quality = ReadingQuality.WARNING;
            healthState = SensorHealthState.WARNING;
        }

        Instant readingTime = message.getTimestamp() != null ? message.getTimestamp() : Instant.now();

        // Update sensor latest metadata
        sensor.setLastReadingTime(readingTime);
        sensor.setLastReadingValue(value);
        sensor.setHealthState(healthState);
        sensorRepository.save(sensor);

        // Save to TimescaleDB hypertable
        SensorReading reading = SensorReading.builder()
                .time(readingTime)
                .sensorId(sensor.getId())
                .machineId(machine.getId())
                .value(value)
                .quality(quality)
                .build();

        sensorReadingRepository.save(reading);
    }
}
