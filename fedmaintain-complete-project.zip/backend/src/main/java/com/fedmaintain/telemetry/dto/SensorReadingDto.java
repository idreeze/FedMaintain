package com.fedmaintain.telemetry.dto;

import com.fedmaintain.sensor.entity.ReadingQuality;
import com.fedmaintain.sensor.entity.SensorReading;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SensorReadingDto {

    private Instant time;
    private Long sensorId;
    private Long machineId;
    private Double value;
    private ReadingQuality quality;

    public static SensorReadingDto fromEntity(SensorReading reading) {
        return SensorReadingDto.builder()
                .time(reading.getTime())
                .sensorId(reading.getSensorId())
                .machineId(reading.getMachineId())
                .value(reading.getValue())
                .quality(reading.getQuality())
                .build();
    }
}
