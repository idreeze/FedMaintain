package com.fedmaintain.telemetry.mqtt;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fedmaintain.telemetry.dto.SensorReadingMessage;
import com.fedmaintain.telemetry.service.TelemetryService;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;

@Component
public class MqttSubscriber implements MqttCallback {

    private static final Logger log = LoggerFactory.getLogger(MqttSubscriber.class);

    private final String brokerUrl;
    private final String clientId;
    private final String topicPrefix;
    private final TelemetryService telemetryService;
    private final ObjectMapper objectMapper;

    private MqttClient mqttClient;
    private boolean isSubscribed = false;

    public MqttSubscriber(
            @Value("${mqtt.broker-url:tcp://localhost:1883}") String brokerUrl,
            @Value("${mqtt.client-id:fedmaintain-backend}") String clientId,
            @Value("${mqtt.topic-prefix:fedmaintain}") String topicPrefix,
            TelemetryService telemetryService) {
        this.brokerUrl = brokerUrl;
        this.clientId = clientId;
        this.topicPrefix = topicPrefix;
        this.telemetryService = telemetryService;
        this.objectMapper = new ObjectMapper();
        this.objectMapper.registerModule(new JavaTimeModule());
    }

    @PostConstruct
    public void init() {
        connectAndSubscribe();
    }

    @Scheduled(fixedDelay = 10000)
    public void checkMqttConnection() {
        if (mqttClient == null || !mqttClient.isConnected()) {
            connectAndSubscribe();
        }
    }

    public synchronized void connectAndSubscribe() {
        try {
            if (mqttClient == null) {
                mqttClient = new MqttClient(brokerUrl, clientId, new MemoryPersistence());
                mqttClient.setCallback(this);
            }

            if (!mqttClient.isConnected()) {
                MqttConnectOptions options = new MqttConnectOptions();
                options.setAutomaticReconnect(true);
                options.setCleanSession(true);
                options.setConnectionTimeout(5);
                options.setKeepAliveInterval(30);

                log.info("Connecting to MQTT broker at: {}", brokerUrl);
                mqttClient.connect(options);
                log.info("Connected to MQTT broker successfully.");
            }

            if (!isSubscribed && mqttClient.isConnected()) {
                String topicFilter = topicPrefix + "/#";
                mqttClient.subscribe(topicFilter, 1);
                isSubscribed = true;
                log.info("Subscribed to telemetry topic filter: {}", topicFilter);
            }
        } catch (MqttException e) {
            log.warn("MQTT connection/subscription to {} deferred: {} (Broker might be starting up)", brokerUrl, e.getMessage());
            isSubscribed = false;
        } catch (Exception e) {
            log.error("Unexpected error in MQTT subscriber: {}", e.getMessage());
            isSubscribed = false;
        }
    }

    @Override
    public void connectionLost(Throwable cause) {
        log.warn("MQTT connection lost: {}. Automatic reconnect initiated.", cause != null ? cause.getMessage() : "Unknown");
        isSubscribed = false;
    }

    @Override
    public void messageArrived(String topic, MqttMessage message) {
        try {
            String payloadStr = new String(message.getPayload(), StandardCharsets.UTF_8);
            SensorReadingMessage readingMessage = objectMapper.readValue(payloadStr, SensorReadingMessage.class);
            telemetryService.processIncomingReading(readingMessage);
        } catch (Exception e) {
            log.error("Failed to parse and process MQTT telemetry on topic {}: {}", topic, e.getMessage());
        }
    }

    @Override
    public void deliveryComplete(IMqttDeliveryToken token) {
        // No-op for subscriber
    }

    public boolean isConnected() {
        return mqttClient != null && mqttClient.isConnected();
    }

    public void publishMessage(String topic, String payload) throws MqttException {
        if (mqttClient != null && mqttClient.isConnected()) {
            MqttMessage message = new MqttMessage(payload.getBytes(StandardCharsets.UTF_8));
            message.setQos(1);
            mqttClient.publish(topic, message);
        } else {
            throw new MqttException(MqttException.REASON_CODE_CLIENT_NOT_CONNECTED);
        }
    }

    @PreDestroy
    public void cleanUp() {
        try {
            if (mqttClient != null && mqttClient.isConnected()) {
                mqttClient.disconnect();
                mqttClient.close();
                log.info("MQTT subscriber disconnected cleanly.");
            }
        } catch (Exception ignored) {
        }
    }
}
