package com.fedmaintain.telemetry.dto;

import com.fedmaintain.sensor.entity.SensorType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SensorReadingMessage {

    @NotBlank(message = "machineCode is required")
    private String machineCode;

    @NotBlank(message = "sensorCode is required")
    private String sensorCode;

    @NotNull(message = "sensorType is required")
    private SensorType sensorType;

    @NotNull(message = "value is required")
    private Double value;

    private String unit;

    @Builder.Default
    private Instant timestamp = Instant.now();
}
