package com.fedmaintain.telemetry.simulator;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fedmaintain.sensor.entity.Sensor;
import com.fedmaintain.sensor.entity.SensorStatus;
import com.fedmaintain.sensor.entity.SensorType;
import com.fedmaintain.sensor.repository.SensorRepository;
import com.fedmaintain.telemetry.dto.SensorReadingMessage;
import com.fedmaintain.telemetry.mqtt.MqttSubscriber;
import com.fedmaintain.telemetry.service.TelemetryService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

@Service
public class SensorSimulatorService {

    private static final Logger log = LoggerFactory.getLogger(SensorSimulatorService.class);

    public enum SimulationMode {
        NORMAL,
        DEGRADING,
        WARNING,
        CRITICAL,
        FAILURE
    }

    private final SensorRepository sensorRepository;
    private final TelemetryService telemetryService;
    private final MqttSubscriber mqttSubscriber;
    private final ObjectMapper objectMapper;
    private final Random random = new Random();

    private volatile SimulationMode currentMode = SimulationMode.NORMAL;
    private final AtomicBoolean running = new AtomicBoolean(true);
    private final AtomicLong totalTicks = new AtomicLong(0);
    private final AtomicLong totalReadingsGenerated = new AtomicLong(0);

    public SensorSimulatorService(
            SensorRepository sensorRepository,
            TelemetryService telemetryService,
            MqttSubscriber mqttSubscriber) {
        this.sensorRepository = sensorRepository;
        this.telemetryService = telemetryService;
        this.mqttSubscriber = mqttSubscriber;
        this.objectMapper = new ObjectMapper();
    }

    @Scheduled(fixedRate = 4000)
    @org.springframework.transaction.annotation.Transactional
    public void scheduledTick() {
        if (!running.get()) {
            return;
        }
        tick();
    }

    @org.springframework.transaction.annotation.Transactional
    public int tick() {
        List<Sensor> sensors = sensorRepository.findAll().stream()
                .filter(s -> s.getStatus() == SensorStatus.ACTIVE)
                .toList();

        if (sensors.isEmpty()) {
            return 0;
        }

        totalTicks.incrementAndGet();
        int count = 0;

        for (Sensor sensor : sensors) {
            double simulatedValue = generateSimulatedValue(sensor, currentMode);
            SensorReadingMessage message = SensorReadingMessage.builder()
                    .machineCode(sensor.getMachine().getMachineCode())
                    .sensorCode(sensor.getSensorCode())
                    .sensorType(sensor.getSensorType())
                    .value(simulatedValue)
                    .unit(sensor.getUnit())
                    .timestamp(Instant.now())
                    .build();

            // Try publishing via MQTT if connected
            boolean publishedToMqtt = false;
            if (mqttSubscriber != null && mqttSubscriber.isConnected()) {
                try {
                    String topic = String.format("fedmaintain/plant/%s/area/%s/machine/%s/sensor/%s",
                            sensor.getMachine().getProductionArea().getPlant().getCode(),
                            sensor.getMachine().getProductionArea().getCode(),
                            sensor.getMachine().getMachineCode(),
                            sensor.getSensorCode());
                    String payload = objectMapper.writeValueAsString(message);
                    mqttSubscriber.publishMessage(topic, payload);
                    publishedToMqtt = true;
                } catch (Exception e) {
                    log.debug("Direct MQTT publish fell back to direct telemetry service: {}", e.getMessage());
                }
            }

            // If not published to MQTT (or in standalone test mode), ingest directly
            if (!publishedToMqtt) {
                telemetryService.processIncomingReading(message);
            }

            totalReadingsGenerated.incrementAndGet();
            count++;
        }

        log.debug("SensorSimulator tick #{} completed: {} readings simulated in {} mode",
                totalTicks.get(), count, currentMode);

        return count;
    }

    private double generateSimulatedValue(Sensor sensor, SimulationMode mode) {
        SensorType type = sensor.getSensorType();
        double base;
        double noise;

        switch (type) {
            case TEMPERATURE:
                switch (mode) {
                    case NORMAL -> base = 48.0 + random.nextDouble() * 5.0; // 48-53 C
                    case DEGRADING -> base = 68.0 + random.nextDouble() * 6.0; // 68-74 C
                    case WARNING -> base = 76.0 + random.nextDouble() * 5.0; // 76-81 C
                    case CRITICAL -> base = 82.0 + random.nextDouble() * 7.0; // 82-89 C
                    case FAILURE -> base = 98.0 + random.nextDouble() * 10.0; // 98-108 C
                    default -> base = 50.0;
                }
                break;

            case VIBRATION:
                switch (mode) {
                    case NORMAL -> base = 1.2 + random.nextDouble() * 0.8; // 1.2-2.0 mm/s
                    case DEGRADING -> base = 3.6 + random.nextDouble() * 1.5; // 3.6-5.1 mm/s
                    case WARNING -> base = 5.5 + random.nextDouble() * 1.2; // 5.5-6.7 mm/s
                    case CRITICAL -> base = 7.0 + random.nextDouble() * 2.0; // 7.0-9.0 mm/s
                    case FAILURE -> base = 12.0 + random.nextDouble() * 4.0; // 12-16 mm/s
                    default -> base = 1.5;
                }
                break;

            case CURRENT:
                switch (mode) {
                    case NORMAL -> base = 15.0 + random.nextDouble() * 3.0; // 15-18 A
                    case DEGRADING -> base = 25.0 + random.nextDouble() * 4.0; // 25-29 A
                    case WARNING -> base = 30.0 + random.nextDouble() * 4.0; // 30-34 A
                    case CRITICAL -> base = 35.0 + random.nextDouble() * 5.0; // 35-40 A
                    case FAILURE -> base = 48.0 + random.nextDouble() * 5.0; // 48-53 A
                    default -> base = 16.0;
                }
                break;

            case PRESSURE:
                switch (mode) {
                    case NORMAL -> base = 42.0 + random.nextDouble() * 5.0; // 42-47 psi
                    case DEGRADING -> base = 56.0 + random.nextDouble() * 6.0; // 56-62 psi
                    case WARNING -> base = 63.0 + random.nextDouble() * 5.0; // 63-68 psi
                    case CRITICAL -> base = 70.0 + random.nextDouble() * 7.0; // 70-77 psi
                    case FAILURE -> base = 88.0 + random.nextDouble() * 10.0; // 88-98 psi
                    default -> base = 45.0;
                }
                break;

            case RPM:
                switch (mode) {
                    case NORMAL -> base = 1800.0 + (random.nextDouble() - 0.5) * 30.0; // 1785-1815
                    case DEGRADING -> base = 1710.0 + (random.nextDouble() - 0.5) * 50.0; // 1685-1735
                    case WARNING -> base = 1600.0 + (random.nextDouble() - 0.5) * 60.0; // 1570-1630
                    case CRITICAL -> base = 1420.0 + (random.nextDouble() - 0.5) * 80.0; // 1380-1460
                    case FAILURE -> base = 950.0 + (random.nextDouble() - 0.5) * 120.0; // 890-1010
                    default -> base = 1800.0;
                }
                break;

            case ACOUSTIC:
                switch (mode) {
                    case NORMAL -> base = 50.0 + random.nextDouble() * 5.0; // 50-55 dB
                    case DEGRADING -> base = 68.0 + random.nextDouble() * 6.0; // 68-74 dB
                    case WARNING -> base = 76.0 + random.nextDouble() * 5.0; // 76-81 dB
                    case CRITICAL -> base = 84.0 + random.nextDouble() * 6.0; // 84-90 dB
                    case FAILURE -> base = 104.0 + random.nextDouble() * 8.0; // 104-112 dB
                    default -> base = 52.0;
                }
                break;

            default:
                base = 50.0 + (random.nextDouble() - 0.5) * 10.0;
                break;
        }

        return BigDecimal.valueOf(base).setScale(2, RoundingMode.HALF_UP).doubleValue();
    }

    public SimulationMode getCurrentMode() {
        return currentMode;
    }

    public void setCurrentMode(SimulationMode currentMode) {
        log.info("Simulator mode changed to: {}", currentMode);
        this.currentMode = currentMode;
    }

    public boolean isRunning() {
        return running.get();
    }

    public void setRunning(boolean isRunning) {
        log.info("Simulator running state set to: {}", isRunning);
        this.running.set(isRunning);
    }

    public long getTotalTicks() {
        return totalTicks.get();
    }

    public long getTotalReadingsGenerated() {
        return totalReadingsGenerated.get();
    }
}
