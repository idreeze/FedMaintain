package com.fedmaintain.telemetry.simulator;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/simulator")
public class SimulatorController {

    private final SensorSimulatorService simulatorService;

    public SimulatorController(SensorSimulatorService simulatorService) {
        this.simulatorService = simulatorService;
    }

    @GetMapping("/status")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER', 'OPERATOR')")
    public ResponseEntity<Map<String, Object>> getStatus() {
        return ResponseEntity.ok(Map.of(
                "running", simulatorService.isRunning(),
                "mode", simulatorService.getCurrentMode(),
                "totalTicks", simulatorService.getTotalTicks(),
                "totalReadingsGenerated", simulatorService.getTotalReadingsGenerated()
        ));
    }

    @PostMapping("/mode/{mode}")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER')")
    public ResponseEntity<Map<String, Object>> setMode(@PathVariable String mode) {
        SensorSimulatorService.SimulationMode simMode = SensorSimulatorService.SimulationMode.valueOf(mode.toUpperCase());
        simulatorService.setCurrentMode(simMode);
        return ResponseEntity.ok(Map.of(
                "message", "Simulation mode updated to " + simMode,
                "mode", simMode
        ));
    }

    @PostMapping("/start")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER')")
    public ResponseEntity<Map<String, Object>> startSimulation() {
        simulatorService.setRunning(true);
        return ResponseEntity.ok(Map.of("message", "Simulator started", "running", true));
    }

    @PostMapping("/stop")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER')")
    public ResponseEntity<Map<String, Object>> stopSimulation() {
        simulatorService.setRunning(false);
        return ResponseEntity.ok(Map.of("message", "Simulator stopped", "running", false));
    }

    @PostMapping("/tick")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER')")
    public ResponseEntity<Map<String, Object>> manualTick() {
        int simulatedCount = simulatorService.tick();
        return ResponseEntity.ok(Map.of(
                "message", "Simulated tick generated",
                "simulatedCount", simulatedCount,
                "mode", simulatorService.getCurrentMode()
        ));
    }
}
