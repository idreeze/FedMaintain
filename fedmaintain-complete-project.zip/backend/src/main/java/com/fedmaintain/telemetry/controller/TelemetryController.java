package com.fedmaintain.telemetry.controller;

import com.fedmaintain.telemetry.dto.MachineLatestReadingsResponse;
import com.fedmaintain.telemetry.dto.SensorReadingDto;
import com.fedmaintain.telemetry.dto.SensorReadingMessage;
import com.fedmaintain.telemetry.dto.TelemetrySummaryResponse;
import com.fedmaintain.telemetry.service.TelemetryService;
import jakarta.validation.Valid;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;

@RestController
@RequestMapping("/api")
public class TelemetryController {

    private final TelemetryService telemetryService;

    public TelemetryController(TelemetryService telemetryService) {
        this.telemetryService = telemetryService;
    }

    @GetMapping("/sensors/{id}/readings")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER', 'OPERATOR')")
    public ResponseEntity<List<SensorReadingDto>> getReadingsBySensor(
            @PathVariable Long id,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant start,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant end,
            @RequestParam(defaultValue = "100") int limit) {

        Instant effectiveEnd = (end != null) ? end : Instant.now();
        Instant effectiveStart = (start != null) ? start : effectiveEnd.minus(1, ChronoUnit.HOURS);
        int clampedLimit = Math.min(Math.max(limit, 1), 2000);

        return ResponseEntity.ok(telemetryService.getReadingsBySensor(id, effectiveStart, effectiveEnd, clampedLimit));
    }

    @GetMapping("/machines/{id}/readings")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER', 'OPERATOR')")
    public ResponseEntity<List<SensorReadingDto>> getReadingsByMachine(
            @PathVariable Long id,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant start,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant end,
            @RequestParam(defaultValue = "100") int limit) {

        Instant effectiveEnd = (end != null) ? end : Instant.now();
        Instant effectiveStart = (start != null) ? start : effectiveEnd.minus(1, ChronoUnit.HOURS);
        int clampedLimit = Math.min(Math.max(limit, 1), 2000);

        return ResponseEntity.ok(telemetryService.getReadingsByMachine(id, effectiveStart, effectiveEnd, clampedLimit));
    }

    @GetMapping("/sensors/{id}/latest")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER', 'OPERATOR')")
    public ResponseEntity<SensorReadingDto> getLatestReadingBySensor(@PathVariable Long id) {
        return ResponseEntity.ok(telemetryService.getLatestReadingBySensor(id));
    }

    @GetMapping("/machines/{id}/latest-readings")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER', 'OPERATOR')")
    public ResponseEntity<MachineLatestReadingsResponse> getLatestReadingsByMachine(@PathVariable Long id) {
        return ResponseEntity.ok(telemetryService.getLatestReadingsByMachine(id));
    }

    @GetMapping("/machines/{id}/telemetry/summary")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER', 'OPERATOR')")
    public ResponseEntity<TelemetrySummaryResponse> getTelemetrySummary(@PathVariable Long id) {
        return ResponseEntity.ok(telemetryService.getTelemetrySummary(id));
    }

    @PostMapping("/telemetry/readings")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER')")
    public ResponseEntity<Void> ingestReading(@Valid @RequestBody SensorReadingMessage message) {
        telemetryService.processIncomingReading(message);
        return ResponseEntity.status(HttpStatus.ACCEPTED).build();
    }
}
