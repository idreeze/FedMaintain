package com.fedmaintain.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api/test")
public class TestSecurityController {

    @GetMapping("/admin")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Map<String, String>> adminAccess() {
        return ResponseEntity.ok(Map.of(
                "role", "ADMIN",
                "message", "Admin access granted: full system authority verified."
        ));
    }

    @GetMapping("/engineer")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER')")
    public ResponseEntity<Map<String, String>> engineerAccess() {
        return ResponseEntity.ok(Map.of(
                "role", "ENGINEER",
                "message", "Engineer access granted: equipment, sensor & maintenance telemetry verified."
        ));
    }

    @GetMapping("/operator")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER', 'OPERATOR')")
    public ResponseEntity<Map<String, String>> operatorAccess() {
        return ResponseEntity.ok(Map.of(
                "role", "OPERATOR",
                "message", "Operator access granted: monitoring and operations telemetry verified."
        ));
    }
}
