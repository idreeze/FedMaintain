package com.fedmaintain.plant.dto;

import com.fedmaintain.plant.entity.Plant;
import com.fedmaintain.plant.entity.PlantStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PlantResponse {

    private Long id;
    private String name;
    private String code;
    private String location;
    private String description;
    private PlantStatus status;
    private long areaCount;
    private long machineCount;
    private Instant createdAt;
    private Instant updatedAt;

    public static PlantResponse fromEntity(Plant plant, long areaCount, long machineCount) {
        return PlantResponse.builder()
                .id(plant.getId())
                .name(plant.getName())
                .code(plant.getCode())
                .location(plant.getLocation())
                .description(plant.getDescription())
                .status(plant.getStatus())
                .areaCount(areaCount)
                .machineCount(machineCount)
                .createdAt(plant.getCreatedAt())
                .updatedAt(plant.getUpdatedAt())
                .build();
    }
}
