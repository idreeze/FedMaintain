package com.fedmaintain.plant.entity;

public enum PlantStatus {
    ACTIVE,
    INACTIVE
}
