package com.fedmaintain.plant.repository;

import com.fedmaintain.plant.entity.Plant;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PlantRepository extends JpaRepository<Plant, Long> {

    Optional<Plant> findByCode(String code);

    boolean existsByCode(String code);
}
