package com.fedmaintain.plant.service;

import com.fedmaintain.plant.dto.CreatePlantRequest;
import com.fedmaintain.plant.dto.PlantResponse;
import com.fedmaintain.plant.dto.UpdatePlantRequest;
import com.fedmaintain.plant.entity.Plant;

import java.util.List;

public interface PlantService {

    List<PlantResponse> getAllPlants();

    PlantResponse getPlantById(Long id);

    Plant getPlantEntityById(Long id);

    PlantResponse createPlant(CreatePlantRequest request);

    PlantResponse updatePlant(Long id, UpdatePlantRequest request);

    void deletePlant(Long id);
}
