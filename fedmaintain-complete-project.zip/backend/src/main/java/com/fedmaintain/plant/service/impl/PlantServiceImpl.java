package com.fedmaintain.plant.service.impl;

import com.fedmaintain.exception.ResourceNotFoundException;
import com.fedmaintain.exception.UserAlreadyExistsException;
import com.fedmaintain.machine.repository.MachineRepository;
import com.fedmaintain.plant.dto.CreatePlantRequest;
import com.fedmaintain.plant.dto.PlantResponse;
import com.fedmaintain.plant.dto.UpdatePlantRequest;
import com.fedmaintain.plant.entity.Plant;
import com.fedmaintain.plant.repository.PlantRepository;
import com.fedmaintain.plant.service.PlantService;
import com.fedmaintain.productionarea.entity.ProductionArea;
import com.fedmaintain.productionarea.repository.ProductionAreaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional(readOnly = true)
public class PlantServiceImpl implements PlantService {

    private final PlantRepository plantRepository;
    private final ProductionAreaRepository productionAreaRepository;
    private final MachineRepository machineRepository;

    public PlantServiceImpl(
            PlantRepository plantRepository,
            ProductionAreaRepository productionAreaRepository,
            MachineRepository machineRepository) {
        this.plantRepository = plantRepository;
        this.productionAreaRepository = productionAreaRepository;
        this.machineRepository = machineRepository;
    }

    @Override
    public List<PlantResponse> getAllPlants() {
        return plantRepository.findAll().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public PlantResponse getPlantById(Long id) {
        Plant plant = getPlantEntityById(id);
        return mapToResponse(plant);
    }

    @Override
    public Plant getPlantEntityById(Long id) {
        return plantRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Plant not found with id: " + id));
    }

    @Override
    @Transactional
    public PlantResponse createPlant(CreatePlantRequest request) {
        String code = request.getCode().trim().toUpperCase();
        if (plantRepository.existsByCode(code)) {
            throw new UserAlreadyExistsException("Plant with code already exists: " + code);
        }

        Plant plant = Plant.builder()
                .name(request.getName().trim())
                .code(code)
                .location(request.getLocation().trim())
                .description(request.getDescription())
                .status(request.getStatus())
                .build();

        Plant saved = plantRepository.save(plant);
        return mapToResponse(saved);
    }

    @Override
    @Transactional
    public PlantResponse updatePlant(Long id, UpdatePlantRequest request) {
        Plant plant = getPlantEntityById(id);

        plant.setName(request.getName().trim());
        plant.setLocation(request.getLocation().trim());
        if (request.getDescription() != null) {
            plant.setDescription(request.getDescription());
        }
        if (request.getStatus() != null) {
            plant.setStatus(request.getStatus());
        }

        Plant updated = plantRepository.save(plant);
        return mapToResponse(updated);
    }

    @Override
    @Transactional
    public void deletePlant(Long id) {
        Plant plant = getPlantEntityById(id);

        long areaCount = productionAreaRepository.countByPlantId(id);
        if (areaCount > 0) {
            throw new IllegalArgumentException(
                    "Cannot delete plant '" + plant.getName() + "'. It contains " + areaCount +
                    " production area(s). Please delete or reassign areas first.");
        }

        plantRepository.delete(plant);
    }

    private PlantResponse mapToResponse(Plant plant) {
        long areaCount = productionAreaRepository.countByPlantId(plant.getId());
        List<ProductionArea> areas = productionAreaRepository.findByPlantId(plant.getId());
        long machineCount = areas.stream()
                .mapToLong(area -> machineRepository.countByProductionAreaId(area.getId()))
                .sum();

        return PlantResponse.fromEntity(plant, areaCount, machineCount);
    }
}
