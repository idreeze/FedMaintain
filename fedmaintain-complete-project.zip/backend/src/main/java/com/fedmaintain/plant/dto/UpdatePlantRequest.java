package com.fedmaintain.plant.dto;

import com.fedmaintain.plant.entity.PlantStatus;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdatePlantRequest {

    @NotBlank(message = "Plant name is required")
    @Size(min = 2, max = 150, message = "Plant name must be between 2 and 150 characters")
    private String name;

    @NotBlank(message = "Plant location is required")
    @Size(min = 2, max = 200, message = "Location must be between 2 and 200 characters")
    private String location;

    private String description;

    private PlantStatus status;
}
