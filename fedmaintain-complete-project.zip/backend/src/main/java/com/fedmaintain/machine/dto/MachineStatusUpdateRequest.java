package com.fedmaintain.machine.dto;

import com.fedmaintain.machine.entity.MachineStatus;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MachineStatusUpdateRequest {

    @NotNull(message = "Status is required (ACTIVE, INACTIVE, MAINTENANCE, WARNING, CRITICAL, DECOMMISSIONED)")
    private MachineStatus status;
}
