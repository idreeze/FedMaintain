package com.fedmaintain.machine.service;

import com.fedmaintain.common.PageResponse;
import com.fedmaintain.machine.dto.CreateMachineRequest;
import com.fedmaintain.machine.dto.MachineResponse;
import com.fedmaintain.machine.dto.MachineStatusUpdateRequest;
import com.fedmaintain.machine.dto.UpdateMachineRequest;
import com.fedmaintain.machine.entity.Machine;
import com.fedmaintain.machine.entity.MachineCriticality;
import com.fedmaintain.machine.entity.MachineStatus;
import org.springframework.data.domain.Pageable;

public interface MachineService {

    PageResponse<MachineResponse> getMachines(
            String search,
            Long plantId,
            Long areaId,
            MachineStatus status,
            MachineCriticality criticality,
            Pageable pageable);

    MachineResponse getMachineById(Long id);

    Machine getMachineEntityById(Long id);

    Machine getMachineEntityByCode(String machineCode);

    MachineResponse createMachine(Long areaId, CreateMachineRequest request);

    MachineResponse updateMachine(Long id, UpdateMachineRequest request);

    MachineResponse updateMachineStatus(Long id, MachineStatusUpdateRequest request);

    void decommissionMachine(Long id);
}
