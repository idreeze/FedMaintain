package com.fedmaintain.machine.entity;

public enum MachineCriticality {
    LOW,
    MEDIUM,
    HIGH,
    CRITICAL
}
