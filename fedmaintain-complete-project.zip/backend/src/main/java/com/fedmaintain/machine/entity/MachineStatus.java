package com.fedmaintain.machine.entity;

public enum MachineStatus {
    ACTIVE,
    INACTIVE,
    MAINTENANCE,
    WARNING,
    CRITICAL,
    DECOMMISSIONED
}
