package com.fedmaintain.machine.dto;

import com.fedmaintain.machine.entity.Machine;
import com.fedmaintain.machine.entity.MachineCriticality;
import com.fedmaintain.machine.entity.MachineStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;
import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MachineResponse {

    private Long id;
    private Long productionAreaId;
    private String productionAreaName;
    private String productionAreaCode;
    private Long plantId;
    private String plantName;
    private String plantCode;
    private String machineCode;
    private String name;
    private String machineType;
    private String manufacturer;
    private String modelNumber;
    private String serialNumber;
    private LocalDate installationDate;
    private MachineStatus status;
    private MachineCriticality criticality;
    private String description;
    private long sensorCount;
    private Instant createdAt;
    private Instant updatedAt;

    public static MachineResponse fromEntity(Machine machine, long sensorCount) {
        return MachineResponse.builder()
                .id(machine.getId())
                .productionAreaId(machine.getProductionArea().getId())
                .productionAreaName(machine.getProductionArea().getName())
                .productionAreaCode(machine.getProductionArea().getCode())
                .plantId(machine.getProductionArea().getPlant().getId())
                .plantName(machine.getProductionArea().getPlant().getName())
                .plantCode(machine.getProductionArea().getPlant().getCode())
                .machineCode(machine.getMachineCode())
                .name(machine.getName())
                .machineType(machine.getMachineType())
                .manufacturer(machine.getManufacturer())
                .modelNumber(machine.getModelNumber())
                .serialNumber(machine.getSerialNumber())
                .installationDate(machine.getInstallationDate())
                .status(machine.getStatus())
                .criticality(machine.getCriticality())
                .description(machine.getDescription())
                .sensorCount(sensorCount)
                .createdAt(machine.getCreatedAt())
                .updatedAt(machine.getUpdatedAt())
                .build();
    }
}
