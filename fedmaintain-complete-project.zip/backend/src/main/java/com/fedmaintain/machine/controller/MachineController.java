package com.fedmaintain.machine.controller;

import com.fedmaintain.common.PageResponse;
import com.fedmaintain.machine.dto.CreateMachineRequest;
import com.fedmaintain.machine.dto.MachineResponse;
import com.fedmaintain.machine.dto.MachineStatusUpdateRequest;
import com.fedmaintain.machine.dto.UpdateMachineRequest;
import com.fedmaintain.machine.entity.MachineCriticality;
import com.fedmaintain.machine.entity.MachineStatus;
import com.fedmaintain.machine.service.MachineService;
import jakarta.validation.Valid;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class MachineController {

    private final MachineService machineService;

    public MachineController(MachineService machineService) {
        this.machineService = machineService;
    }

    @GetMapping("/machines")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER', 'OPERATOR')")
    public ResponseEntity<PageResponse<MachineResponse>> getMachines(
            @RequestParam(required = false) String search,
            @RequestParam(required = false) Long plantId,
            @RequestParam(required = false) Long areaId,
            @RequestParam(required = false) MachineStatus status,
            @RequestParam(required = false) MachineCriticality criticality,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @RequestParam(defaultValue = "createdAt") String sortBy,
            @RequestParam(defaultValue = "desc") String direction) {

        Sort sort = direction.equalsIgnoreCase("asc") ? Sort.by(sortBy).ascending() : Sort.by(sortBy).descending();
        Pageable pageable = PageRequest.of(page, size, sort);

        return ResponseEntity.ok(machineService.getMachines(search, plantId, areaId, status, criticality, pageable));
    }

    @GetMapping("/machines/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER', 'OPERATOR')")
    public ResponseEntity<MachineResponse> getMachineById(@PathVariable Long id) {
        return ResponseEntity.ok(machineService.getMachineById(id));
    }

    @PostMapping("/areas/{areaId}/machines")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER')")
    public ResponseEntity<MachineResponse> createMachine(
            @PathVariable Long areaId,
            @Valid @RequestBody CreateMachineRequest request) {
        MachineResponse response = machineService.createMachine(areaId, request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @PutMapping("/machines/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER')")
    public ResponseEntity<MachineResponse> updateMachine(
            @PathVariable Long id,
            @Valid @RequestBody UpdateMachineRequest request) {
        return ResponseEntity.ok(machineService.updateMachine(id, request));
    }

    @PatchMapping("/machines/{id}/status")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER')")
    public ResponseEntity<MachineResponse> updateMachineStatus(
            @PathVariable Long id,
            @Valid @RequestBody MachineStatusUpdateRequest request) {
        return ResponseEntity.ok(machineService.updateMachineStatus(id, request));
    }

    @DeleteMapping("/machines/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER')")
    public ResponseEntity<Void> decommissionMachine(@PathVariable Long id) {
        machineService.decommissionMachine(id);
        return ResponseEntity.noContent().build();
    }
}
