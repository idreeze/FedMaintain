package com.fedmaintain.machine.dto;

import com.fedmaintain.machine.entity.MachineCriticality;
import com.fedmaintain.machine.entity.MachineStatus;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateMachineRequest {

    @NotBlank(message = "Machine code is required")
    @Size(min = 2, max = 50, message = "Machine code must be between 2 and 50 characters")
    private String machineCode;

    @NotBlank(message = "Machine name is required")
    @Size(min = 2, max = 150, message = "Machine name must be between 2 and 150 characters")
    private String name;

    @NotBlank(message = "Machine type is required (e.g. CMP, ETCH, CVD, PVD, LITH)")
    private String machineType;

    private String manufacturer;
    private String modelNumber;
    private String serialNumber;
    private LocalDate installationDate;

    @Builder.Default
    private MachineStatus status = MachineStatus.ACTIVE;

    @NotNull(message = "Criticality is required (LOW, MEDIUM, HIGH, CRITICAL)")
    @Builder.Default
    private MachineCriticality criticality = MachineCriticality.MEDIUM;

    private String description;
}
