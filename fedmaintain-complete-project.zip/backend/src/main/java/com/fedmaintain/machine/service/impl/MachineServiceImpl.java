package com.fedmaintain.machine.service.impl;

import com.fedmaintain.common.PageResponse;
import com.fedmaintain.exception.ResourceNotFoundException;
import com.fedmaintain.exception.UserAlreadyExistsException;
import com.fedmaintain.machine.dto.CreateMachineRequest;
import com.fedmaintain.machine.dto.MachineResponse;
import com.fedmaintain.machine.dto.MachineStatusUpdateRequest;
import com.fedmaintain.machine.dto.UpdateMachineRequest;
import com.fedmaintain.machine.entity.Machine;
import com.fedmaintain.machine.entity.MachineCriticality;
import com.fedmaintain.machine.entity.MachineStatus;
import com.fedmaintain.machine.repository.MachineRepository;
import com.fedmaintain.machine.service.MachineService;
import com.fedmaintain.productionarea.entity.ProductionArea;
import com.fedmaintain.productionarea.repository.ProductionAreaRepository;
import com.fedmaintain.sensor.repository.SensorRepository;
import jakarta.persistence.criteria.Predicate;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
@Transactional(readOnly = true)
public class MachineServiceImpl implements MachineService {

    private final MachineRepository machineRepository;
    private final ProductionAreaRepository productionAreaRepository;
    private final SensorRepository sensorRepository;

    public MachineServiceImpl(
            MachineRepository machineRepository,
            ProductionAreaRepository productionAreaRepository,
            SensorRepository sensorRepository) {
        this.machineRepository = machineRepository;
        this.productionAreaRepository = productionAreaRepository;
        this.sensorRepository = sensorRepository;
    }

    @Override
    public PageResponse<MachineResponse> getMachines(
            String search,
            Long plantId,
            Long areaId,
            MachineStatus status,
            MachineCriticality criticality,
            Pageable pageable) {

        Specification<Machine> spec = (root, query, cb) -> {
            List<Predicate> predicates = new ArrayList<>();

            if (search != null && !search.trim().isEmpty()) {
                String searchPattern = "%" + search.trim().toLowerCase() + "%";
                Predicate codeMatch = cb.like(cb.lower(root.get("machineCode")), searchPattern);
                Predicate nameMatch = cb.like(cb.lower(root.get("name")), searchPattern);
                Predicate modelMatch = cb.like(cb.lower(root.get("modelNumber")), searchPattern);
                predicates.add(cb.or(codeMatch, nameMatch, modelMatch));
            }

            if (plantId != null) {
                predicates.add(cb.equal(root.get("productionArea").get("plant").get("id"), plantId));
            }

            if (areaId != null) {
                predicates.add(cb.equal(root.get("productionArea").get("id"), areaId));
            }

            if (status != null) {
                predicates.add(cb.equal(root.get("status"), status));
            }

            if (criticality != null) {
                predicates.add(cb.equal(root.get("criticality"), criticality));
            }

            return cb.and(predicates.toArray(new Predicate[0]));
        };

        Page<Machine> page = machineRepository.findAll(spec, pageable);
        Page<MachineResponse> responsePage = page.map(this::mapToResponse);
        return PageResponse.fromPage(responsePage);
    }

    @Override
    public MachineResponse getMachineById(Long id) {
        Machine machine = getMachineEntityById(id);
        return mapToResponse(machine);
    }

    @Override
    public Machine getMachineEntityById(Long id) {
        return machineRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Machine not found with id: " + id));
    }

    @Override
    public Machine getMachineEntityByCode(String machineCode) {
        return machineRepository.findByMachineCode(machineCode)
                .orElseThrow(() -> new ResourceNotFoundException("Machine not found with code: " + machineCode));
    }

    @Override
    @Transactional
    public MachineResponse createMachine(Long areaId, CreateMachineRequest request) {
        ProductionArea area = productionAreaRepository.findById(areaId)
                .orElseThrow(() -> new ResourceNotFoundException("Production area not found with id: " + areaId));

        String code = request.getMachineCode().trim().toUpperCase();
        if (machineRepository.existsByMachineCode(code)) {
            throw new UserAlreadyExistsException("Machine with code already exists: " + code);
        }

        if (request.getSerialNumber() != null && !request.getSerialNumber().trim().isEmpty()) {
            String serial = request.getSerialNumber().trim();
            if (machineRepository.existsBySerialNumber(serial)) {
                throw new UserAlreadyExistsException("Machine with serial number already exists: " + serial);
            }
        }

        Machine machine = Machine.builder()
                .productionArea(area)
                .machineCode(code)
                .name(request.getName().trim())
                .machineType(request.getMachineType().trim().toUpperCase())
                .manufacturer(request.getManufacturer())
                .modelNumber(request.getModelNumber())
                .serialNumber(request.getSerialNumber() != null ? request.getSerialNumber().trim() : null)
                .installationDate(request.getInstallationDate())
                .status(request.getStatus() != null ? request.getStatus() : MachineStatus.ACTIVE)
                .criticality(request.getCriticality())
                .description(request.getDescription())
                .build();

        Machine saved = machineRepository.save(machine);
        return mapToResponse(saved);
    }

    @Override
    @Transactional
    public MachineResponse updateMachine(Long id, UpdateMachineRequest request) {
        Machine machine = getMachineEntityById(id);

        if (request.getSerialNumber() != null && !request.getSerialNumber().trim().isEmpty()) {
            String newSerial = request.getSerialNumber().trim();
            if (!newSerial.equals(machine.getSerialNumber()) && machineRepository.existsBySerialNumber(newSerial)) {
                throw new UserAlreadyExistsException("Machine with serial number already exists: " + newSerial);
            }
            machine.setSerialNumber(newSerial);
        }

        machine.setName(request.getName().trim());
        machine.setMachineType(request.getMachineType().trim().toUpperCase());
        machine.setManufacturer(request.getManufacturer());
        machine.setModelNumber(request.getModelNumber());
        machine.setInstallationDate(request.getInstallationDate());
        if (request.getStatus() != null) {
            machine.setStatus(request.getStatus());
        }
        if (request.getCriticality() != null) {
            machine.setCriticality(request.getCriticality());
        }
        if (request.getDescription() != null) {
            machine.setDescription(request.getDescription());
        }

        Machine updated = machineRepository.save(machine);
        return mapToResponse(updated);
    }

    @Override
    @Transactional
    public MachineResponse updateMachineStatus(Long id, MachineStatusUpdateRequest request) {
        Machine machine = getMachineEntityById(id);
        machine.setStatus(request.getStatus());
        Machine updated = machineRepository.save(machine);
        return mapToResponse(updated);
    }

    @Override
    @Transactional
    public void decommissionMachine(Long id) {
        Machine machine = getMachineEntityById(id);
        // Soft deletion: marks machine as DECOMMISSIONED to protect historical telemetry & maintenance records
        machine.setStatus(MachineStatus.DECOMMISSIONED);
        machineRepository.save(machine);
    }

    private MachineResponse mapToResponse(Machine machine) {
        long sensorCount = sensorRepository.countByMachineId(machine.getId());
        return MachineResponse.fromEntity(machine, sensorCount);
    }
}
