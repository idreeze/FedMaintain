package com.fedmaintain.machine.repository;

import com.fedmaintain.machine.entity.Machine;
import com.fedmaintain.machine.entity.MachineStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface MachineRepository extends JpaRepository<Machine, Long>, JpaSpecificationExecutor<Machine> {

    Optional<Machine> findByMachineCode(String machineCode);

    boolean existsByMachineCode(String machineCode);

    boolean existsBySerialNumber(String serialNumber);

    long countByProductionAreaId(Long productionAreaId);

    long countByStatus(MachineStatus status);
}
