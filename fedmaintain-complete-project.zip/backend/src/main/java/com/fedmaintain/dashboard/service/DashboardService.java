package com.fedmaintain.dashboard.service;

import com.fedmaintain.dashboard.dto.DashboardStatsResponse;

public interface DashboardService {

    DashboardStatsResponse getDashboardStats();
}
