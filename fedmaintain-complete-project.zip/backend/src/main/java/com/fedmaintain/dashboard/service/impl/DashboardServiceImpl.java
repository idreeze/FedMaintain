package com.fedmaintain.dashboard.service.impl;

import com.fedmaintain.dashboard.dto.DashboardStatsResponse;
import com.fedmaintain.dashboard.service.DashboardService;
import com.fedmaintain.machine.entity.MachineStatus;
import com.fedmaintain.machine.repository.MachineRepository;
import com.fedmaintain.plant.repository.PlantRepository;
import com.fedmaintain.productionarea.repository.ProductionAreaRepository;
import com.fedmaintain.sensor.entity.SensorHealthState;
import com.fedmaintain.sensor.entity.SensorStatus;
import com.fedmaintain.sensor.repository.SensorRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional(readOnly = true)
public class DashboardServiceImpl implements DashboardService {

    private final PlantRepository plantRepository;
    private final ProductionAreaRepository productionAreaRepository;
    private final MachineRepository machineRepository;
    private final SensorRepository sensorRepository;

    public DashboardServiceImpl(
            PlantRepository plantRepository,
            ProductionAreaRepository productionAreaRepository,
            MachineRepository machineRepository,
            SensorRepository sensorRepository) {
        this.plantRepository = plantRepository;
        this.productionAreaRepository = productionAreaRepository;
        this.machineRepository = machineRepository;
        this.sensorRepository = sensorRepository;
    }

    @Override
    public DashboardStatsResponse getDashboardStats() {
        return DashboardStatsResponse.builder()
                .totalPlants(plantRepository.count())
                .totalAreas(productionAreaRepository.count())
                .totalMachines(machineRepository.count())
                .activeMachines(machineRepository.countByStatus(MachineStatus.ACTIVE))
                .maintenanceMachines(machineRepository.countByStatus(MachineStatus.MAINTENANCE))
                .warningMachines(machineRepository.countByStatus(MachineStatus.WARNING))
                .criticalMachines(machineRepository.countByStatus(MachineStatus.CRITICAL))
                .decommissionedMachines(machineRepository.countByStatus(MachineStatus.DECOMMISSIONED))
                .totalSensors(sensorRepository.count())
                .activeSensors(sensorRepository.countByStatus(SensorStatus.ACTIVE))
                .normalSensors(sensorRepository.countByHealthState(SensorHealthState.NORMAL))
                .warningSensors(sensorRepository.countByHealthState(SensorHealthState.WARNING))
                .criticalSensors(sensorRepository.countByHealthState(SensorHealthState.CRITICAL))
                .offlineSensors(sensorRepository.countByHealthState(SensorHealthState.OFFLINE))
                .build();
    }
}
