package com.fedmaintain.dashboard.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DashboardStatsResponse {

    private long totalPlants;
    private long totalAreas;
    private long totalMachines;
    private long activeMachines;
    private long maintenanceMachines;
    private long warningMachines;
    private long criticalMachines;
    private long decommissionedMachines;

    private long totalSensors;
    private long activeSensors;
    private long normalSensors;
    private long warningSensors;
    private long criticalSensors;
    private long offlineSensors;
}
