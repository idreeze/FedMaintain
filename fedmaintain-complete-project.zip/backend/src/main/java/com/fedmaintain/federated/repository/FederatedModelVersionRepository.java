package com.fedmaintain.federated.repository;

import com.fedmaintain.federated.entity.FederatedModelVersionEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface FederatedModelVersionRepository extends JpaRepository<FederatedModelVersionEntity, Long> {
    Optional<FederatedModelVersionEntity> findByVersion(String version);
    Optional<FederatedModelVersionEntity> findFirstByOrderByRoundNumberDesc();
    List<FederatedModelVersionEntity> findAllByOrderByRoundNumberDesc();
}
