package com.fedmaintain.federated.service;

import com.fedmaintain.federated.dto.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface FederatedTrainingService {
    FederatedRoundResponse startRound(StartFederatedRoundRequest request);
    List<FederatedRoundResponse> getAllRounds();
    FederatedRoundResponse getRoundById(Long roundId);
    List<FederatedClientResponse> getAllClients();
    FederatedClientResponse getClientById(String clientId);
    List<FederatedModelResponse> getAllModels();
    FederatedModelResponse getModelById(Long id);
    FederatedMetricsResponse getMetrics();
}
