package com.fedmaintain.federated.aggregation;

import com.fedmaintain.federated.model.FederatedLinearRegressionModel;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class FedAvgAggregator {

    public static class ClientUpdate {
        private final String clientId;
        private final double[] weights;
        private final double bias;
        private final int sampleCount;
        private final double trainingLoss;

        public ClientUpdate(String clientId, double[] weights, double bias, int sampleCount, double trainingLoss) {
            this.clientId = clientId;
            this.weights = weights;
            this.bias = bias;
            this.sampleCount = sampleCount;
            this.trainingLoss = trainingLoss;
        }

        public String getClientId() {
            return clientId;
        }

        public double[] getWeights() {
            return weights;
        }

        public double getBias() {
            return bias;
        }

        public int getSampleCount() {
            return sampleCount;
        }

        public double getTrainingLoss() {
            return trainingLoss;
        }
    }

    /**
     * Performs weighted FedAvg across valid client updates:
     * W_global = Σ(W_i * n_i) / Σ(n_i)
     * b_global = Σ(b_i * n_i) / Σ(n_i)
     *
     * @param updates List of validated client parameter updates
     * @return New global aggregated FederatedLinearRegressionModel
     */
    public FederatedLinearRegressionModel aggregate(List<ClientUpdate> updates) {
        if (updates == null || updates.isEmpty()) {
            throw new IllegalArgumentException("Cannot aggregate empty client updates list");
        }

        int featureDim = updates.get(0).getWeights().length;
        long totalSamples = 0;

        for (ClientUpdate u : updates) {
            totalSamples += u.getSampleCount();
        }

        if (totalSamples == 0) {
            throw new IllegalArgumentException("Total sample count across clients must be greater than 0");
        }

        double[] aggregatedWeights = new double[featureDim];
        double aggregatedBias = 0.0;

        for (ClientUpdate u : updates) {
            double weightRatio = (double) u.getSampleCount() / totalSamples;
            double[] clientW = u.getWeights();

            for (int j = 0; j < featureDim; j++) {
                aggregatedWeights[j] += clientW[j] * weightRatio;
            }
            aggregatedBias += u.getBias() * weightRatio;
        }

        return new FederatedLinearRegressionModel(aggregatedWeights, aggregatedBias);
    }
}
