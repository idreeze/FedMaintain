package com.fedmaintain.federated.repository;

import com.fedmaintain.federated.entity.FederatedRoundEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface FederatedRoundRepository extends JpaRepository<FederatedRoundEntity, Long> {
    Optional<FederatedRoundEntity> findByRoundNumber(Integer roundNumber);
    Optional<FederatedRoundEntity> findFirstByOrderByRoundNumberDesc();
    List<FederatedRoundEntity> findAllByOrderByRoundNumberDesc();
}
