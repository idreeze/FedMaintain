package com.fedmaintain.federated.entity;

public enum FederatedRoundStatus {
    STARTED,
    AGGREGATING,
    COMPLETED,
    FAILED
}
