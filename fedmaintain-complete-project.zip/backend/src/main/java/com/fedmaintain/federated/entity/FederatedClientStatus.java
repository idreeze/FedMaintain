package com.fedmaintain.federated.entity;

public enum FederatedClientStatus {
    ACTIVE,
    INACTIVE,
    TRAINING
}
