package com.fedmaintain.federated.dto;

import com.fedmaintain.federated.entity.FederatedModelVersionEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FederatedModelResponse {
    private Long id;
    private String modelName;
    private String version;
    private Integer roundNumber;
    private String algorithm;
    private Integer clientCount;
    private Integer sampleCount;
    private String artifactPath;
    private Instant createdAt;

    public static FederatedModelResponse fromEntity(FederatedModelVersionEntity m) {
        if (m == null) return null;
        return FederatedModelResponse.builder()
                .id(m.getId())
                .modelName(m.getModelName())
                .version(m.getVersion())
                .roundNumber(m.getRoundNumber())
                .algorithm(m.getAlgorithm())
                .clientCount(m.getClientCount())
                .sampleCount(m.getSampleCount())
                .artifactPath(m.getArtifactPath())
                .createdAt(m.getCreatedAt())
                .build();
    }
}
