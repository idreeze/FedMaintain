package com.fedmaintain.federated.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class StartFederatedRoundRequest {
    @Builder.Default
    private List<String> clientIds = List.of("PLANT-A", "PLANT-B", "PLANT-C");
    @Builder.Default
    private Integer localEpochs = 5;
    @Builder.Default
    private Double learningRate = 0.01;
}
