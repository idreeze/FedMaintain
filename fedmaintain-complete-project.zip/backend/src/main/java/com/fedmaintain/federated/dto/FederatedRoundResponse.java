package com.fedmaintain.federated.dto;

import com.fedmaintain.federated.entity.FederatedRoundEntity;
import com.fedmaintain.federated.entity.FederatedRoundStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FederatedRoundResponse {
    private Long id;
    private Integer round;
    private String globalModel;
    private String globalModelVersion;
    private Integer participatingClients;
    private Double trainingLoss;
    private Double mae;
    private Double rmse;
    private Double r2;
    private FederatedRoundStatus status;
    private Instant startedAt;
    private Instant completedAt;

    public static FederatedRoundResponse fromEntity(FederatedRoundEntity r) {
        if (r == null) return null;
        return FederatedRoundResponse.builder()
                .id(r.getId())
                .round(r.getRoundNumber())
                .globalModel(r.getGlobalModelVersion())
                .globalModelVersion(r.getGlobalModelVersion())
                .participatingClients(r.getParticipatingClients())
                .trainingLoss(r.getTrainingLoss())
                .mae(r.getMae())
                .rmse(r.getRmse())
                .r2(r.getR2())
                .status(r.getStatus())
                .startedAt(r.getStartedAt())
                .completedAt(r.getCompletedAt())
                .build();
    }
}
