package com.fedmaintain.federated.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;

@Entity
@Table(name = "federated_rounds")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FederatedRoundEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "round_number", nullable = false, unique = true)
    private Integer roundNumber;

    @Column(name = "global_model_version", length = 64)
    private String globalModelVersion;

    @Column(name = "started_at", nullable = false)
    @Builder.Default
    private Instant startedAt = Instant.now();

    @Column(name = "completed_at")
    private Instant completedAt;

    @Column(name = "participating_clients", nullable = false)
    @Builder.Default
    private Integer participatingClients = 0;

    @Column(name = "training_loss")
    private Double trainingLoss;

    @Column(name = "mae")
    private Double mae;

    @Column(name = "rmse")
    private Double rmse;

    @Column(name = "r2")
    private Double r2;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    @Builder.Default
    private FederatedRoundStatus status = FederatedRoundStatus.STARTED;
}
