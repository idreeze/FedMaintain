package com.fedmaintain.federated.dataset;

import org.springframework.stereotype.Service;

import java.util.Random;

@Service
public class LocalPlantDatasetService {

    public static class LocalDataset {
        private final double[][] features;
        private final double[] targets;
        private final int sampleCount;

        public LocalDataset(double[][] features, double[] targets) {
            this.features = features;
            this.targets = targets;
            this.sampleCount = targets != null ? targets.length : 0;
        }

        public double[][] getFeatures() {
            return features;
        }

        public double[] getTargets() {
            return targets;
        }

        public int getSampleCount() {
            return sampleCount;
        }
    }

    /**
     * Synthesizes isolated local training data for each simulated plant.
     * Features: [temp_norm, vib_norm, curr_norm, press_norm, rpm_norm, aco_norm]
     * Target: rul_hours
     *
     * Non-IID Characteristics:
     * - PLANT-A: nominal baseline distribution
     * - PLANT-B: higher thermal variation / thermal drift
     * - PLANT-C: higher mechanical vibration variance
     */
    public LocalDataset getLocalDataset(String clientId) {
        Random rand;
        int numSamples;
        double tempDrift;
        double vibDrift;

        switch (clientId) {
            case "PLANT-B" -> {
                rand = new Random(102);
                numSamples = 120;
                tempDrift = 0.25; // Elevated thermal degradation
                vibDrift = 0.05;
            }
            case "PLANT-C" -> {
                rand = new Random(203);
                numSamples = 95;
                tempDrift = 0.05;
                vibDrift = 0.35; // Elevated mechanical bearing wear
            }
            default -> { // PLANT-A
                rand = new Random(42);
                numSamples = 150;
                tempDrift = 0.0;
                vibDrift = 0.0;
            }
        }

        double[][] X = new double[numSamples][6];
        double[] y = new double[numSamples];

        for (int i = 0; i < numSamples; i++) {
            // Synthetic lifecycle degradation progress 0.0 (fresh) -> 1.0 (failure)
            double progress = (double) i / numSamples;
            double trueRul = (1.0 - progress) * 72.0; // 72h down to 0h

            // Temperature normalized
            double temp = 0.5 + (progress * 0.4) + tempDrift + (rand.nextDouble() * 0.05);
            // Vibration normalized
            double vib = 0.1 + (progress * 0.7) + vibDrift + (rand.nextDouble() * 0.05);
            // Current normalized
            double curr = 0.3 + (progress * 0.5) + (rand.nextDouble() * 0.04);
            // Pressure normalized
            double press = 0.4 + (progress * 0.4) + (rand.nextDouble() * 0.04);
            // RPM normalized (decreasing)
            double rpm = 0.9 - (progress * 0.4) + (rand.nextDouble() * 0.03);
            // Acoustic normalized
            double aco = 0.4 + (progress * 0.5) + (rand.nextDouble() * 0.04);

            X[i] = new double[]{temp, vib, curr, press, rpm, aco};
            y[i] = Math.max(0.0, trueRul + (rand.nextDouble() - 0.5) * 2.0);
        }

        return new LocalDataset(X, y);
    }
}
