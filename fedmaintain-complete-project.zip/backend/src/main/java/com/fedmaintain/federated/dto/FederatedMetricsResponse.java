package com.fedmaintain.federated.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FederatedMetricsResponse {
    private List<FederatedRoundResponse> rounds;
    private Double latestMae;
    private Double latestRmse;
    private Double latestR2;
    private Double latestTrainingLoss;
    private Integer totalRounds;
    private Integer totalRoundsCompleted;
    private Integer activeClientsCount;
    private Integer totalClients;
}

