package com.fedmaintain.federated.controller;

import com.fedmaintain.common.ApiResponse;
import com.fedmaintain.federated.dto.*;
import com.fedmaintain.federated.service.CentralizedVsFederatedComparisonService;
import com.fedmaintain.federated.service.FederatedTrainingService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/federated")
public class FederatedController {

    private final FederatedTrainingService federatedService;
    private final CentralizedVsFederatedComparisonService comparisonService;

    public FederatedController(
            FederatedTrainingService federatedService,
            CentralizedVsFederatedComparisonService comparisonService) {
        this.federatedService = federatedService;
        this.comparisonService = comparisonService;
    }

    @PostMapping("/rounds/start")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<FederatedRoundResponse>> startRound(
            @RequestBody(required = false) StartFederatedRoundRequest request) {
        if (request == null) {
            request = new StartFederatedRoundRequest();
        }
        FederatedRoundResponse response = federatedService.startRound(request);
        return ResponseEntity.ok(ApiResponse.success("Federated round completed successfully", response));
    }

    @GetMapping("/rounds")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER', 'OPERATOR')")
    public ResponseEntity<ApiResponse<List<FederatedRoundResponse>>> getAllRounds() {
        List<FederatedRoundResponse> list = federatedService.getAllRounds();
        return ResponseEntity.ok(ApiResponse.success(list));
    }

    @GetMapping("/rounds/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER', 'OPERATOR')")
    public ResponseEntity<ApiResponse<FederatedRoundResponse>> getRoundById(@PathVariable Long id) {
        FederatedRoundResponse response = federatedService.getRoundById(id);
        return ResponseEntity.ok(ApiResponse.success(response));
    }

    @GetMapping("/clients")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER', 'OPERATOR')")
    public ResponseEntity<ApiResponse<List<FederatedClientResponse>>> getAllClients() {
        List<FederatedClientResponse> clients = federatedService.getAllClients();
        return ResponseEntity.ok(ApiResponse.success(clients));
    }

    @GetMapping("/clients/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER', 'OPERATOR')")
    public ResponseEntity<ApiResponse<FederatedClientResponse>> getClientById(@PathVariable String id) {
        FederatedClientResponse client = federatedService.getClientById(id);
        return ResponseEntity.ok(ApiResponse.success(client));
    }

    @GetMapping("/models")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER', 'OPERATOR')")
    public ResponseEntity<ApiResponse<List<FederatedModelResponse>>> getAllModels() {
        List<FederatedModelResponse> models = federatedService.getAllModels();
        return ResponseEntity.ok(ApiResponse.success(models));
    }

    @GetMapping("/models/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER', 'OPERATOR')")
    public ResponseEntity<ApiResponse<FederatedModelResponse>> getModelById(@PathVariable Long id) {
        FederatedModelResponse model = federatedService.getModelById(id);
        return ResponseEntity.ok(ApiResponse.success(model));
    }

    @GetMapping("/metrics")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER', 'OPERATOR')")
    public ResponseEntity<ApiResponse<FederatedMetricsResponse>> getMetrics() {
        FederatedMetricsResponse metrics = federatedService.getMetrics();
        return ResponseEntity.ok(ApiResponse.success(metrics));
    }

    @GetMapping("/comparison")
    @PreAuthorize("hasAnyRole('ADMIN', 'ENGINEER', 'OPERATOR')")
    public ResponseEntity<ApiResponse<ModelComparisonResponse>> getComparison() {
        ModelComparisonResponse comparison = comparisonService.compareModels();
        return ResponseEntity.ok(ApiResponse.success(comparison));
    }
}
