package com.fedmaintain.federated.repository;

import com.fedmaintain.federated.entity.FederatedClientEntity;
import com.fedmaintain.federated.entity.FederatedClientStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface FederatedClientRepository extends JpaRepository<FederatedClientEntity, Long> {
    Optional<FederatedClientEntity> findByClientId(String clientId);
    List<FederatedClientEntity> findByStatus(FederatedClientStatus status);
    boolean existsByClientId(String clientId);
}
