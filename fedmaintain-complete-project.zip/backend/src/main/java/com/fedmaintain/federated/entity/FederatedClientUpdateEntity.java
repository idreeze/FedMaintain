package com.fedmaintain.federated.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;

@Entity
@Table(
        name = "federated_client_updates",
        indexes = {
                @Index(name = "idx_fed_updates_round", columnList = "round_id")
        }
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FederatedClientUpdateEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "round_id", nullable = false)
    private FederatedRoundEntity round;

    @Column(name = "client_id", nullable = false, length = 64)
    private String clientId;

    @Column(name = "sample_count", nullable = false)
    @Builder.Default
    private Integer sampleCount = 0;

    @Column(name = "training_epochs", nullable = false)
    @Builder.Default
    private Integer trainingEpochs = 1;

    @Column(name = "training_loss")
    private Double trainingLoss;

    @Column(name = "update_status", nullable = false, length = 30)
    @Builder.Default
    private String updateStatus = "ACCEPTED";

    @Column(name = "created_at", nullable = false)
    @Builder.Default
    private Instant createdAt = Instant.now();
}
