package com.fedmaintain.federated.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;

@Entity
@Table(name = "federated_model_versions")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FederatedModelVersionEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "model_name", nullable = false, length = 100)
    private String modelName;

    @Column(nullable = false, unique = true, length = 50)
    private String version;

    @Column(name = "round_number", nullable = false)
    private Integer roundNumber;

    @Column(nullable = false, length = 50)
    @Builder.Default
    private String algorithm = "FED_LINEAR_REGRESSION";

    @Column(name = "client_count", nullable = false)
    @Builder.Default
    private Integer clientCount = 0;

    @Column(name = "sample_count", nullable = false)
    @Builder.Default
    private Integer sampleCount = 0;

    @Column(name = "artifact_path")
    private String artifactPath;

    @Column(name = "created_at", nullable = false)
    @Builder.Default
    private Instant createdAt = Instant.now();
}
