package com.fedmaintain.federated.privacy;

import com.fedmaintain.federated.aggregation.FedAvgAggregator.ClientUpdate;

/**
 * Strategy interface for privacy-enhancing technologies (Differential Privacy, Secure Aggregation).
 */
public interface PrivacyProtectionStrategy {
    ClientUpdate prepareUpdate(ClientUpdate rawUpdate);
    boolean validateUpdate(ClientUpdate update);
    String getStrategyName();
}
