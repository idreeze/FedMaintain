package com.fedmaintain.federated.service;

import com.fedmaintain.federated.dto.ModelComparisonResponse;
import com.fedmaintain.federated.entity.FederatedRoundEntity;
import com.fedmaintain.federated.privacy.PrivacyProtectionStrategy;
import com.fedmaintain.federated.repository.FederatedRoundRepository;
import com.fedmaintain.ml.entity.ModelStatus;
import com.fedmaintain.ml.entity.ModelVersion;
import com.fedmaintain.ml.repository.ModelVersionRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class CentralizedVsFederatedComparisonService {

    private final ModelVersionRepository modelVersionRepository;
    private final FederatedRoundRepository federatedRoundRepository;
    private final PrivacyProtectionStrategy privacyStrategy;

    public CentralizedVsFederatedComparisonService(
            ModelVersionRepository modelVersionRepository,
            FederatedRoundRepository federatedRoundRepository,
            PrivacyProtectionStrategy privacyStrategy) {
        this.modelVersionRepository = modelVersionRepository;
        this.federatedRoundRepository = federatedRoundRepository;
        this.privacyStrategy = privacyStrategy;
    }

    @Transactional(readOnly = true)
    public ModelComparisonResponse compareModels() {
        ModelVersion centModel = modelVersionRepository.findFirstByStatusOrderByCreatedAtDesc(ModelStatus.ACTIVE)
                .orElse(null);

        FederatedRoundEntity fedRound = federatedRoundRepository.findFirstByOrderByRoundNumberDesc()
                .orElse(null);

        String summary;
        if (centModel != null && fedRound != null && centModel.getMae() != null && fedRound.getMae() != null) {
            double maeDiff = Math.abs(centModel.getMae() - fedRound.getMae());
            if (centModel.getMae() < fedRound.getMae()) {
                summary = String.format("Centralized model achieves slightly lower MAE (%.2fh vs %.2fh) due to unconstrained access to pooled cleanroom data. Federated learning achieves comparable RUL estimation while keeping raw telemetry strictly confined to local edge plant storage.",
                        centModel.getMae(), fedRound.getMae());
            } else {
                summary = String.format("Federated FedAvg model achieved MAE %.2fh vs Centralized MAE %.2fh across heterogeneous plant distributions.",
                        fedRound.getMae(), centModel.getMae());
            }
        } else {
            summary = "Centralized and Federated models are available for comparison once training rounds are completed.";
        }

        return ModelComparisonResponse.builder()
                .centralizedModelVersion(centModel != null ? centModel.getVersion() : "None")
                .centralizedAlgorithm(centModel != null ? centModel.getAlgorithm().name() : "N/A")
                .centralizedMae(centModel != null ? centModel.getMae() : null)
                .centralizedRmse(centModel != null ? centModel.getRmse() : null)
                .centralizedR2(centModel != null ? centModel.getR2() : null)
                .federatedModelVersion(fedRound != null ? fedRound.getGlobalModelVersion() : "None")
                .federatedAlgorithm("FED_LINEAR_REGRESSION (FedAvg)")
                .federatedMae(fedRound != null ? fedRound.getMae() : null)
                .federatedRmse(fedRound != null ? fedRound.getRmse() : null)
                .federatedR2(fedRound != null ? fedRound.getR2() : null)
                .privacyStrategy(privacyStrategy.getStrategyName())
                .evaluationMethodology("Evaluated on holdout synthetic validation degradation dataset across all participating plants.")
                .factualSummary(summary)
                .build();
    }
}
