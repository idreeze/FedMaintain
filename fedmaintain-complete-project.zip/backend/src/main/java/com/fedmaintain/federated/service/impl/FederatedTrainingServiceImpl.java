package com.fedmaintain.federated.service.impl;

import com.fedmaintain.exception.ResourceNotFoundException;
import com.fedmaintain.federated.aggregation.FedAvgAggregator;
import com.fedmaintain.federated.aggregation.FedAvgAggregator.ClientUpdate;
import com.fedmaintain.federated.aggregation.ModelUpdateValidator;
import com.fedmaintain.federated.client.SimulatedFederatedClient;
import com.fedmaintain.federated.dataset.LocalPlantDatasetService;
import com.fedmaintain.federated.dataset.LocalPlantDatasetService.LocalDataset;
import com.fedmaintain.federated.dto.*;
import com.fedmaintain.federated.entity.*;
import com.fedmaintain.federated.model.FederatedLinearRegressionModel;
import com.fedmaintain.federated.privacy.PrivacyProtectionStrategy;
import com.fedmaintain.federated.repository.FederatedClientRepository;
import com.fedmaintain.federated.repository.FederatedClientUpdateRepository;
import com.fedmaintain.federated.repository.FederatedModelVersionRepository;
import com.fedmaintain.federated.repository.FederatedRoundRepository;
import com.fedmaintain.federated.service.FederatedTrainingService;
import com.fedmaintain.ml.evaluation.ModelEvaluationService;
import com.fedmaintain.ml.evaluation.ModelEvaluationService.EvaluationMetrics;
import com.fedmaintain.ml.service.ModelStorageService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.*;

@Service
public class FederatedTrainingServiceImpl implements FederatedTrainingService {

    private static final Logger log = LoggerFactory.getLogger(FederatedTrainingServiceImpl.class);

    private final FederatedClientRepository clientRepository;
    private final FederatedRoundRepository roundRepository;
    private final FederatedClientUpdateRepository updateRepository;
    private final FederatedModelVersionRepository modelVersionRepository;
    private final SimulatedFederatedClient clientExecutor;
    private final FedAvgAggregator aggregator;
    private final ModelUpdateValidator validator;
    private final PrivacyProtectionStrategy privacyStrategy;
    private final ModelEvaluationService evaluationService;
    private final LocalPlantDatasetService datasetService;
    private final ModelStorageService storageService;

    @Value("${federated.minimum-clients:2}")
    private int minimumClients;

    public FederatedTrainingServiceImpl(
            FederatedClientRepository clientRepository,
            FederatedRoundRepository roundRepository,
            FederatedClientUpdateRepository updateRepository,
            FederatedModelVersionRepository modelVersionRepository,
            SimulatedFederatedClient clientExecutor,
            FedAvgAggregator aggregator,
            ModelUpdateValidator validator,
            PrivacyProtectionStrategy privacyStrategy,
            ModelEvaluationService evaluationService,
            LocalPlantDatasetService datasetService,
            ModelStorageService storageService) {
        this.clientRepository = clientRepository;
        this.roundRepository = roundRepository;
        this.updateRepository = updateRepository;
        this.modelVersionRepository = modelVersionRepository;
        this.clientExecutor = clientExecutor;
        this.aggregator = aggregator;
        this.validator = validator;
        this.privacyStrategy = privacyStrategy;
        this.evaluationService = evaluationService;
        this.datasetService = datasetService;
        this.storageService = storageService;
    }

    @Override
    @Transactional
    public FederatedRoundResponse startRound(StartFederatedRoundRequest request) {
        bootstrapClientsIfEmpty();

        int nextRoundNumber = (int) (roundRepository.count() + 1);
        String globalModelVersion = "FED-RUL-v" + nextRoundNumber;
        log.info("Initiating Federated Round #{} [{}]", nextRoundNumber, globalModelVersion);

        // 1. Select participating clients
        List<String> targetClientIds = (request.getClientIds() != null && !request.getClientIds().isEmpty())
                ? request.getClientIds()
                : List.of("PLANT-A", "PLANT-B", "PLANT-C");

        List<FederatedClientEntity> participatingEntities = clientRepository.findAll().stream()
                .filter(c -> targetClientIds.contains(c.getClientId()) && c.getStatus() == FederatedClientStatus.ACTIVE)
                .toList();

        // 2. Client Fault Tolerance Check
        if (participatingEntities.size() < minimumClients) {
            FederatedRoundEntity failedRound = FederatedRoundEntity.builder()
                    .roundNumber(nextRoundNumber)
                    .globalModelVersion(globalModelVersion)
                    .startedAt(Instant.now())
                    .completedAt(Instant.now())
                    .participatingClients(participatingEntities.size())
                    .status(FederatedRoundStatus.FAILED)
                    .build();
            roundRepository.save(failedRound);
            throw new IllegalStateException(String.format(
                    "Federated training round %d failed: insufficient participating clients. Required at least %d, but only %d active.",
                    nextRoundNumber, minimumClients, participatingEntities.size()));
        }

        FederatedRoundEntity round = FederatedRoundEntity.builder()
                .roundNumber(nextRoundNumber)
                .globalModelVersion(globalModelVersion)
                .startedAt(Instant.now())
                .participatingClients(participatingEntities.size())
                .status(FederatedRoundStatus.STARTED)
                .build();
        round = roundRepository.save(round);

        // 3. Load or initialize global model parameters
        FederatedLinearRegressionModel globalModel = loadCurrentGlobalModel();
        double[] currentWeights = globalModel.getWeights();
        double currentBias = globalModel.getBias();

        int localEpochs = (request.getLocalEpochs() != null && request.getLocalEpochs() > 0) ? request.getLocalEpochs() : 5;
        double lr = (request.getLearningRate() != null && request.getLearningRate() > 0) ? request.getLearningRate() : 0.01;

        // 4. Distribute parameters to each edge client and execute local training
        List<ClientUpdate> collectedUpdates = new ArrayList<>();
        Set<String> validIds = new HashSet<>(targetClientIds);
        Set<String> processedIds = new HashSet<>();

        round.setStatus(FederatedRoundStatus.AGGREGATING);
        roundRepository.save(round);

        double totalLoss = 0.0;
        int updateCount = 0;

        for (FederatedClientEntity client : participatingEntities) {
            client.setStatus(FederatedClientStatus.TRAINING);
            clientRepository.save(client);

            // Edge client training
            ClientUpdate rawUpdate = clientExecutor.performLocalTraining(
                    client.getClientId(), currentWeights, currentBias, localEpochs, lr);

            // Privacy strategy preparation
            ClientUpdate preparedUpdate = privacyStrategy.prepareUpdate(rawUpdate);

            // Validation: reject null, NaN, Inf, dimension mismatch, duplicates
            boolean isValid = validator.validate(preparedUpdate, currentWeights.length, validIds, processedIds)
                    && privacyStrategy.validateUpdate(preparedUpdate);

            if (isValid) {
                collectedUpdates.add(preparedUpdate);
                processedIds.add(client.getClientId());
                totalLoss += preparedUpdate.getTrainingLoss();
                updateCount++;

                // Persist update record
                FederatedClientUpdateEntity updateEntity = FederatedClientUpdateEntity.builder()
                        .round(round)
                        .clientId(client.getClientId())
                        .sampleCount(preparedUpdate.getSampleCount())
                        .trainingEpochs(localEpochs)
                        .trainingLoss(preparedUpdate.getTrainingLoss())
                        .updateStatus("ACCEPTED")
                        .createdAt(Instant.now())
                        .build();
                updateRepository.save(updateEntity);

                client.setLastSeen(Instant.now());
                client.setDatasetSize(preparedUpdate.getSampleCount());
            } else {
                log.warn("Update from {} was rejected by validator", client.getClientId());
                FederatedClientUpdateEntity updateEntity = FederatedClientUpdateEntity.builder()
                        .round(round)
                        .clientId(client.getClientId())
                        .sampleCount(rawUpdate != null ? rawUpdate.getSampleCount() : 0)
                        .trainingEpochs(localEpochs)
                        .trainingLoss(0.0)
                        .updateStatus("REJECTED")
                        .createdAt(Instant.now())
                        .build();
                updateRepository.save(updateEntity);
            }

            client.setStatus(FederatedClientStatus.ACTIVE);
            clientRepository.save(client);
        }

        // 5. Aggregate with FedAvg
        if (collectedUpdates.size() < minimumClients) {
            round.setStatus(FederatedRoundStatus.FAILED);
            round.setCompletedAt(Instant.now());
            roundRepository.save(round);
            throw new IllegalStateException("Round failed: too few valid updates collected for FedAvg (" + collectedUpdates.size() + ")");
        }

        FederatedLinearRegressionModel aggregatedGlobalModel = aggregator.aggregate(collectedUpdates);

        // 6. Evaluate new global model on holdout test set (from all plants)
        EvaluationMetrics metrics = evaluateGlobalModel(aggregatedGlobalModel);
        double avgLoss = updateCount > 0 ? (totalLoss / updateCount) : 0.0;

        // 7. Persist global model artifact
        String artifactPath = storageService.saveModel(globalModelVersion, aggregatedGlobalModel);

        // 8. Register in federated model versions
        FederatedModelVersionEntity modelVersion = FederatedModelVersionEntity.builder()
                .modelName("Federated RUL Linear Regressor")
                .version(globalModelVersion)
                .roundNumber(nextRoundNumber)
                .algorithm("FED_LINEAR_REGRESSION")
                .clientCount(collectedUpdates.size())
                .sampleCount(collectedUpdates.stream().mapToInt(ClientUpdate::getSampleCount).sum())
                .artifactPath(artifactPath)
                .createdAt(Instant.now())
                .build();
        modelVersionRepository.save(modelVersion);

        // 9. Complete round
        round.setStatus(FederatedRoundStatus.COMPLETED);
        round.setCompletedAt(Instant.now());
        round.setTrainingLoss(Math.round(avgLoss * 10000.0) / 10000.0);
        round.setMae(metrics.getMae());
        round.setRmse(metrics.getRmse());
        round.setR2(metrics.getR2());
        round = roundRepository.save(round);

        log.info("Federated Round #{} completed successfully! Global Model: {}, MAE: {}, RMSE: {}, R2: {}",
                nextRoundNumber, globalModelVersion, metrics.getMae(), metrics.getRmse(), metrics.getR2());

        return FederatedRoundResponse.fromEntity(round);
    }

    private FederatedLinearRegressionModel loadCurrentGlobalModel() {
        Optional<FederatedModelVersionEntity> latestOpt = modelVersionRepository.findFirstByOrderByRoundNumberDesc();
        if (latestOpt.isPresent()) {
            try {
                return (FederatedLinearRegressionModel) storageService.loadModel(latestOpt.get().getArtifactPath());
            } catch (Exception e) {
                log.warn("Could not load previous federated model from disk, initializing fresh model: {}", e.getMessage());
            }
        }
        return new FederatedLinearRegressionModel(6); // 6 normalized features
    }

    private EvaluationMetrics evaluateGlobalModel(FederatedLinearRegressionModel model) {
        // Evaluate on holdout validation samples across plants
        List<Double> actuals = new ArrayList<>();
        List<Double> preds = new ArrayList<>();

        for (String cId : List.of("PLANT-A", "PLANT-B", "PLANT-C")) {
            LocalDataset ds = datasetService.getLocalDataset(cId);
            double[][] X = ds.getFeatures();
            double[] y = ds.getTargets();
            // Use last 25% of samples as holdout test
            int startIdx = (int) (X.length * 0.75);
            for (int i = startIdx; i < X.length; i++) {
                actuals.add(y[i]);
                preds.add(model.predict(X[i]));
            }
        }

        return evaluationService.evaluate(actuals, preds);
    }

    private void bootstrapClientsIfEmpty() {
        if (clientRepository.count() >= 3) {
            return;
        }

        String[][] clients = {
                {"PLANT-A", "BLR-01"},
                {"PLANT-B", "SGP-01"},
                {"PLANT-C", "DRS-01"}
        };

        for (String[] c : clients) {
            if (!clientRepository.existsByClientId(c[0])) {
                clientRepository.save(FederatedClientEntity.builder()
                        .clientId(c[0])
                        .plantCode(c[1])
                        .status(FederatedClientStatus.ACTIVE)
                        .datasetSize(100)
                        .lastSeen(Instant.now())
                        .createdAt(Instant.now())
                        .build());
            }
        }
    }

    @Override
    @Transactional(readOnly = true)
    public List<FederatedRoundResponse> getAllRounds() {
        return roundRepository.findAllByOrderByRoundNumberDesc().stream()
                .map(FederatedRoundResponse::fromEntity)
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public FederatedRoundResponse getRoundById(Long roundId) {
        return roundRepository.findById(roundId)
                .map(FederatedRoundResponse::fromEntity)
                .orElseThrow(() -> new ResourceNotFoundException("Federated round not found with id: " + roundId));
    }

    @Override
    @Transactional
    public List<FederatedClientResponse> getAllClients() {
        bootstrapClientsIfEmpty();
        return clientRepository.findAll().stream()
                .map(FederatedClientResponse::fromEntity)
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public FederatedClientResponse getClientById(String clientId) {
        return clientRepository.findByClientId(clientId)
                .map(FederatedClientResponse::fromEntity)
                .orElseThrow(() -> new ResourceNotFoundException("Federated client not found: " + clientId));
    }

    @Override
    @Transactional(readOnly = true)
    public List<FederatedModelResponse> getAllModels() {
        return modelVersionRepository.findAllByOrderByRoundNumberDesc().stream()
                .map(FederatedModelResponse::fromEntity)
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public FederatedModelResponse getModelById(Long id) {
        return modelVersionRepository.findById(id)
                .map(FederatedModelResponse::fromEntity)
                .orElseThrow(() -> new ResourceNotFoundException("Federated model not found with id: " + id));
    }

    @Override
    @Transactional(readOnly = true)
    public FederatedMetricsResponse getMetrics() {
        List<FederatedRoundEntity> rounds = roundRepository.findAllByOrderByRoundNumberDesc();
        List<FederatedRoundResponse> roundDtos = rounds.stream()
                .map(FederatedRoundResponse::fromEntity)
                .toList();

        FederatedRoundEntity latest = rounds.isEmpty() ? null : rounds.get(0);

        return FederatedMetricsResponse.builder()
                .rounds(roundDtos)
                .latestMae(latest != null ? latest.getMae() : null)
                .latestRmse(latest != null ? latest.getRmse() : null)
                .latestR2(latest != null ? latest.getR2() : null)
                .latestTrainingLoss(latest != null ? latest.getTrainingLoss() : null)
                .totalRounds(rounds.size())
                .totalRoundsCompleted((int) rounds.stream().filter(r -> r.getStatus() == FederatedRoundStatus.COMPLETED).count())
                .activeClientsCount((int) clientRepository.count())
                .totalClients((int) clientRepository.count())
                .build();
    }
}
