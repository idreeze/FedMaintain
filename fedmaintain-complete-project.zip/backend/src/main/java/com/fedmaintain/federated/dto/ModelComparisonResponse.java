package com.fedmaintain.federated.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ModelComparisonResponse {
    private String centralizedModelVersion;
    private String centralizedAlgorithm;
    private Double centralizedMae;
    private Double centralizedRmse;
    private Double centralizedR2;

    private String federatedModelVersion;
    private String federatedAlgorithm;
    private Double federatedMae;
    private Double federatedRmse;
    private Double federatedR2;

    private String privacyStrategy;
    private String evaluationMethodology;
    private String factualSummary;
}
