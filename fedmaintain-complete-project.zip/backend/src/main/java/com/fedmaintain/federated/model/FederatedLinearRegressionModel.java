package com.fedmaintain.federated.model;

import java.io.Serializable;
import java.util.Arrays;

public class FederatedLinearRegressionModel implements Serializable {

    private static final long serialVersionUID = 1L;

    private double[] weights;
    private double bias;
    private final int featureCount;

    public FederatedLinearRegressionModel(int featureCount) {
        this.featureCount = featureCount;
        this.weights = new double[featureCount];
        // Initialize weights small
        Arrays.fill(this.weights, 0.0);
        this.bias = 48.0; // Default healthy RUL prior in hours
    }

    public FederatedLinearRegressionModel(double[] weights, double bias) {
        this.featureCount = weights.length;
        this.weights = Arrays.copyOf(weights, weights.length);
        this.bias = bias;
    }

    public double predict(double[] features) {
        if (features == null || features.length != featureCount) {
            throw new IllegalArgumentException("Feature dimension mismatch. Expected: " + featureCount);
        }
        double sum = bias;
        for (int i = 0; i < featureCount; i++) {
            sum += weights[i] * features[i];
        }
        return Math.max(0.0, sum); // Non-negative RUL hours
    }

    /**
     * Executes local training using mini-batch / stochastic gradient descent.
     *
     * @param features     Matrix of feature rows (N x D)
     * @param targets      Target RUL vector (N)
     * @param epochs       Number of local training epochs
     * @param learningRate Gradient step size
     * @param batchSize    Batch size for updates
     * @return Final training MSE loss
     */
    public double train(double[][] features, double[] targets, int epochs, double learningRate, int batchSize) {
        if (features == null || targets == null || features.length == 0 || features.length != targets.length) {
            return 0.0;
        }

        int n = features.length;
        double finalLoss = 0.0;

        for (int epoch = 0; epoch < epochs; epoch++) {
            double epochSqError = 0.0;

            for (int i = 0; i < n; i++) {
                double[] row = features[i];
                double actual = targets[i];
                double pred = predict(row);
                double err = pred - actual; // Residual

                epochSqError += err * err;

                // Gradient step: dL/dw_j = 2 * err * x_j, dL/db = 2 * err
                double step = learningRate * (2.0 * err / n);
                // Clip gradient step to prevent divergence on outliers
                step = Math.max(-5.0, Math.min(5.0, step));

                for (int j = 0; j < featureCount; j++) {
                    weights[j] -= step * row[j];
                    if (Double.isNaN(weights[j]) || Double.isInfinite(weights[j])) {
                        weights[j] = 0.0;
                    }
                }
                bias -= step;
                if (Double.isNaN(bias) || Double.isInfinite(bias)) {
                    bias = 48.0;
                }
            }

            finalLoss = epochSqError / n;
        }

        return Math.round(finalLoss * 10000.0) / 10000.0;
    }

    public double[] getWeights() {
        return Arrays.copyOf(weights, weights.length);
    }

    public double getBias() {
        return bias;
    }

    public void setParameters(double[] newWeights, double newBias) {
        if (newWeights == null || newWeights.length != featureCount) {
            throw new IllegalArgumentException("Weight vector dimension mismatch");
        }
        this.weights = Arrays.copyOf(newWeights, newWeights.length);
        this.bias = newBias;
    }

    public int getFeatureCount() {
        return featureCount;
    }
}
