package com.fedmaintain.federated.entity;

import com.fedmaintain.plant.entity.Plant;
import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;

@Entity
@Table(name = "federated_clients")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FederatedClientEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "client_id", nullable = false, unique = true, length = 64)
    private String clientId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "plant_id")
    private Plant plant;

    @Column(name = "plant_code", nullable = false, length = 50)
    private String plantCode;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    @Builder.Default
    private FederatedClientStatus status = FederatedClientStatus.ACTIVE;

    @Column(name = "dataset_size", nullable = false)
    @Builder.Default
    private Integer datasetSize = 0;

    @Column(name = "last_seen", nullable = false)
    @Builder.Default
    private Instant lastSeen = Instant.now();

    @Column(name = "created_at", nullable = false)
    @Builder.Default
    private Instant createdAt = Instant.now();
}
