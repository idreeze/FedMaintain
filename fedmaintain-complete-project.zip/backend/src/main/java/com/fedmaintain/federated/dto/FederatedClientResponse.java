package com.fedmaintain.federated.dto;

import com.fedmaintain.federated.entity.FederatedClientEntity;
import com.fedmaintain.federated.entity.FederatedClientStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FederatedClientResponse {
    private Long id;
    private String clientId;
    private Long plantId;
    private String plantCode;
    private FederatedClientStatus status;
    private Integer datasetSize;
    private Instant lastSeen;
    private Instant createdAt;

    public static FederatedClientResponse fromEntity(FederatedClientEntity c) {
        if (c == null) return null;
        return FederatedClientResponse.builder()
                .id(c.getId())
                .clientId(c.getClientId())
                .plantId(c.getPlant() != null ? c.getPlant().getId() : null)
                .plantCode(c.getPlantCode())
                .status(c.getStatus())
                .datasetSize(c.getDatasetSize())
                .lastSeen(c.getLastSeen())
                .createdAt(c.getCreatedAt())
                .build();
    }
}
