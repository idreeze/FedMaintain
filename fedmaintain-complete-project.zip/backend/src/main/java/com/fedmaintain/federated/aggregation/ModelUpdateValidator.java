package com.fedmaintain.federated.aggregation;

import com.fedmaintain.federated.aggregation.FedAvgAggregator.ClientUpdate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.Set;

@Component
public class ModelUpdateValidator {

    private static final Logger log = LoggerFactory.getLogger(ModelUpdateValidator.class);

    public boolean validate(ClientUpdate update, int expectedDimension, Set<String> validClients, Set<String> alreadyUpdatedClients) {
        if (update == null) {
            log.warn("Rejected client update: update payload is null");
            return false;
        }

        if (update.getClientId() == null || !validClients.contains(update.getClientId())) {
            log.warn("Rejected client update: unknown client ID '{}'", update.getClientId());
            return false;
        }

        if (alreadyUpdatedClients != null && alreadyUpdatedClients.contains(update.getClientId())) {
            log.warn("Rejected client update: duplicate update from client '{}'", update.getClientId());
            return false;
        }

        if (update.getSampleCount() <= 0) {
            log.warn("Rejected client update from '{}': sample count must be positive (got {})",
                    update.getClientId(), update.getSampleCount());
            return false;
        }

        double[] weights = update.getWeights();
        if (weights == null || weights.length != expectedDimension) {
            log.warn("Rejected client update from '{}': parameter dimension mismatch. Expected {}, got {}",
                    update.getClientId(), expectedDimension, weights != null ? weights.length : 0);
            return false;
        }

        for (int i = 0; i < weights.length; i++) {
            if (Double.isNaN(weights[i]) || Double.isInfinite(weights[i])) {
                log.warn("Rejected client update from '{}': weight[{}] is NaN or Infinite", update.getClientId(), i);
                return false;
            }
        }

        if (Double.isNaN(update.getBias()) || Double.isInfinite(update.getBias())) {
            log.warn("Rejected client update from '{}': bias is NaN or Infinite", update.getClientId());
            return false;
        }

        return true;
    }
}
