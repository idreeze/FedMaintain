package com.fedmaintain.federated.privacy;

import com.fedmaintain.federated.aggregation.FedAvgAggregator.ClientUpdate;
import org.springframework.stereotype.Component;

/**
 * Baseline no-op privacy strategy for the FedMaintain prototype.
 *
 * NOTE ON PRIVACY BOUNDARY:
 * Parameter aggregation via standard FedAvg keeps raw sensor data local to the edge cleanrooms.
 * However, FedAvg alone does NOT mathematically guarantee differential privacy or resistance
 * to gradient-inversion attacks. This class serves as the clean extension point for DP noise
 * addition or cryptographic secure aggregation modules in future research phases.
 */
@Component
public class NoOpPrivacyStrategy implements PrivacyProtectionStrategy {

    @Override
    public ClientUpdate prepareUpdate(ClientUpdate rawUpdate) {
        return rawUpdate; // Pass-through
    }

    @Override
    public boolean validateUpdate(ClientUpdate update) {
        return update != null;
    }

    @Override
    public String getStrategyName() {
        return "NO_OP_BASELINE (FedAvg Parameter Isolation)";
    }
}
