package com.fedmaintain.federated.client;

import com.fedmaintain.federated.aggregation.FedAvgAggregator.ClientUpdate;
import com.fedmaintain.federated.dataset.LocalPlantDatasetService;
import com.fedmaintain.federated.dataset.LocalPlantDatasetService.LocalDataset;
import com.fedmaintain.federated.model.FederatedLinearRegressionModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class SimulatedFederatedClient {

    private static final Logger log = LoggerFactory.getLogger(SimulatedFederatedClient.class);
    private final LocalPlantDatasetService datasetService;

    public SimulatedFederatedClient(LocalPlantDatasetService datasetService) {
        this.datasetService = datasetService;
    }

    /**
     * Executes local edge training on local plant dataset.
     * Raw sensor/feature data NEVER leaves the local client.
     */
    public ClientUpdate performLocalTraining(
            String clientId,
            double[] globalWeights,
            double globalBias,
            int localEpochs,
            double learningRate) {

        log.info("Client {} starting local gradient training: epochs={}, lr={}", clientId, localEpochs, learningRate);

        LocalDataset localData = datasetService.getLocalDataset(clientId);
        if (localData == null || localData.getSampleCount() == 0) {
            log.warn("Client {} has no local data to train on", clientId);
            return new ClientUpdate(clientId, globalWeights, globalBias, 0, 0.0);
        }

        // Initialize local model with global parameters
        FederatedLinearRegressionModel localModel = new FederatedLinearRegressionModel(globalWeights, globalBias);

        // Train locally using gradient descent
        double finalLoss = localModel.train(
                localData.getFeatures(),
                localData.getTargets(),
                localEpochs,
                learningRate,
                16);

        log.info("Client {} finished local training: samples={}, finalLoss={}",
                clientId, localData.getSampleCount(), finalLoss);

        // Return only parameters and metadata
        return new ClientUpdate(
                clientId,
                localModel.getWeights(),
                localModel.getBias(),
                localData.getSampleCount(),
                finalLoss);
    }
}
