package com.fedmaintain.federated.repository;

import com.fedmaintain.federated.entity.FederatedClientUpdateEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FederatedClientUpdateRepository extends JpaRepository<FederatedClientUpdateEntity, Long> {
    List<FederatedClientUpdateEntity> findByRoundId(Long roundId);
}
