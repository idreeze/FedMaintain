package com.fedmaintain.user.entity;

public enum Role {
    ADMIN,
    ENGINEER,
    OPERATOR
}
