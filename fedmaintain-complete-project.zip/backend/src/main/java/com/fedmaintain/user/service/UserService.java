package com.fedmaintain.user.service;

import com.fedmaintain.user.dto.UserDto;
import com.fedmaintain.user.entity.User;

import java.util.Optional;

public interface UserService {

    Optional<User> findByEmail(String email);

    User getUserById(Long id);

    UserDto getUserDtoById(Long id);

    boolean existsByEmail(String email);

    User save(User user);
}
