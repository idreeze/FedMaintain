package com.fedmaintain.service.impl;

import com.fedmaintain.dto.HealthResponse;
import com.fedmaintain.service.HealthService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.sql.Connection;

@Service
public class HealthServiceImpl implements HealthService {

    private static final Logger log = LoggerFactory.getLogger(HealthServiceImpl.class);

    private final DataSource dataSource;
    private final String serviceName;
    private final String serviceVersion;

    public HealthServiceImpl(
            DataSource dataSource,
            @Value("${spring.application.name:FedMaintain Backend}") String serviceName,
            @Value("${app.version:1.0.0}") String serviceVersion) {
        this.dataSource = dataSource;
        this.serviceName = serviceName;
        this.serviceVersion = serviceVersion;
    }

    @Override
    public HealthResponse getHealth() {
        return HealthResponse.builder()
                .status("UP")
                .service(serviceName)
                .version(serviceVersion)
                .build();
    }

    @Override
    public boolean isDatabaseConnected() {
        try (Connection connection = dataSource.getConnection()) {
            return connection.isValid(2);
        } catch (Exception e) {
            log.warn("Database connection check failed: {}", e.getMessage());
            return false;
        }
    }
}
