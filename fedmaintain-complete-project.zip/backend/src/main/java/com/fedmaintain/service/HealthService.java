package com.fedmaintain.service;

import com.fedmaintain.dto.HealthResponse;

public interface HealthService {

    HealthResponse getHealth();

    boolean isDatabaseConnected();
}
