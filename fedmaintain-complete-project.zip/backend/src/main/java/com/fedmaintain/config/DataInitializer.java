package com.fedmaintain.config;

import com.fedmaintain.digitaltwin.entity.DigitalTwin;
import com.fedmaintain.digitaltwin.entity.DigitalTwinStatus;
import com.fedmaintain.digitaltwin.repository.DigitalTwinRepository;
import com.fedmaintain.digitaltwin.service.DigitalTwinSynchronizationService;
import com.fedmaintain.machine.entity.Machine;
import com.fedmaintain.machine.entity.MachineCriticality;
import com.fedmaintain.machine.entity.MachineStatus;
import com.fedmaintain.machine.repository.MachineRepository;
import com.fedmaintain.plant.entity.Plant;
import com.fedmaintain.plant.entity.PlantStatus;
import com.fedmaintain.plant.repository.PlantRepository;
import com.fedmaintain.productionarea.entity.AreaStatus;
import com.fedmaintain.productionarea.entity.ProductionArea;
import com.fedmaintain.productionarea.repository.ProductionAreaRepository;
import com.fedmaintain.sensor.entity.*;
import com.fedmaintain.sensor.repository.SensorReadingRepository;
import com.fedmaintain.sensor.repository.SensorRepository;
import com.fedmaintain.ml.dto.TrainModelRequest;
import com.fedmaintain.ml.entity.ModelStatus;
import com.fedmaintain.ml.repository.ModelVersionRepository;
import com.fedmaintain.ml.service.ModelTrainingService;
import com.fedmaintain.user.entity.Role;
import com.fedmaintain.user.entity.User;
import com.fedmaintain.user.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@Component
public class DataInitializer implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(DataInitializer.class);

    private final UserRepository userRepository;
    private final PlantRepository plantRepository;
    private final ProductionAreaRepository productionAreaRepository;
    private final MachineRepository machineRepository;
    private final SensorRepository sensorRepository;
    private final SensorReadingRepository sensorReadingRepository;
    private final DigitalTwinRepository digitalTwinRepository;
    private final DigitalTwinSynchronizationService digitalTwinSyncService;
    private final ModelTrainingService modelTrainingService;
    private final ModelVersionRepository modelVersionRepository;
    private final PasswordEncoder passwordEncoder;

    private final String adminEmail;
    private final String adminPassword;
    private final String adminName;

    public DataInitializer(
            UserRepository userRepository,
            PlantRepository plantRepository,
            ProductionAreaRepository productionAreaRepository,
            MachineRepository machineRepository,
            SensorRepository sensorRepository,
            SensorReadingRepository sensorReadingRepository,
            DigitalTwinRepository digitalTwinRepository,
            DigitalTwinSynchronizationService digitalTwinSyncService,
            ModelTrainingService modelTrainingService,
            ModelVersionRepository modelVersionRepository,
            PasswordEncoder passwordEncoder,
            @Value("${app.admin.email:admin@fedmaintain.com}") String adminEmail,
            @Value("${app.admin.password:Admin@123}") String adminPassword,
            @Value("${app.admin.name:FedMaintain Admin}") String adminName) {
        this.userRepository = userRepository;
        this.plantRepository = plantRepository;
        this.productionAreaRepository = productionAreaRepository;
        this.machineRepository = machineRepository;
        this.sensorRepository = sensorRepository;
        this.sensorReadingRepository = sensorReadingRepository;
        this.digitalTwinRepository = digitalTwinRepository;
        this.digitalTwinSyncService = digitalTwinSyncService;
        this.modelTrainingService = modelTrainingService;
        this.modelVersionRepository = modelVersionRepository;
        this.passwordEncoder = passwordEncoder;
        this.adminEmail = adminEmail;
        this.adminPassword = adminPassword;
        this.adminName = adminName;
    }

    @Override
    public void run(String... args) {
        seedUsers();
        seedAssetsAndSensors();
        seedInitialRulModel();
        seedDigitalTwins();
    }

    private void seedInitialRulModel() {
        try {
            if (modelVersionRepository.findFirstByStatusOrderByCreatedAtDesc(ModelStatus.ACTIVE).isEmpty()) {
                log.info("No ACTIVE RUL model found in registry. Bootstrapping baseline RUL model...");
                modelTrainingService.trainModel(new TrainModelRequest());
                log.info("Baseline RUL model bootstrapped successfully.");
            }
        } catch (Exception e) {
            log.warn("Failed to bootstrap baseline RUL model during startup: {}", e.getMessage(), e);
        }
    }

    @Transactional
    public void seedUsers() {
        if (!userRepository.existsByEmail(adminEmail)) {
            log.info("Bootstrapping initial FedMaintain ADMIN account: {}", adminEmail);
            userRepository.save(User.builder()
                    .name(adminName)
                    .email(adminEmail.trim().toLowerCase())
                    .password(passwordEncoder.encode(adminPassword))
                    .role(Role.ADMIN)
                    .enabled(true)
                    .build());
        }

        if (!userRepository.existsByEmail("engineer@fedmaintain.com")) {
            userRepository.save(User.builder()
                    .name("Process Engineer")
                    .email("engineer@fedmaintain.com")
                    .password(passwordEncoder.encode("Engineer@123"))
                    .role(Role.ENGINEER)
                    .enabled(true)
                    .build());
        }

        if (!userRepository.existsByEmail("operator@fedmaintain.com")) {
            userRepository.save(User.builder()
                    .name("Floor Operator")
                    .email("operator@fedmaintain.com")
                    .password(passwordEncoder.encode("Operator@123"))
                    .role(Role.OPERATOR)
                    .enabled(true)
                    .build());
        }
    }

    @Transactional
    public void seedAssetsAndSensors() {
        if (plantRepository.count() > 0) {
            log.info("Assets and sensors already seeded.");
            return;
        }

        log.info("Seeding initial semiconductor plant, production areas, machines, and sensors...");

        // 1. Plant
        Plant plant = plantRepository.save(Plant.builder()
                .code("BLR-01")
                .name("Bengaluru Fab 1")
                .location("Whitefield Semiconductor Park, Bengaluru, India")
                .description("Advanced 300mm Semiconductor Fabrication Facility")
                .status(PlantStatus.ACTIVE)
                .build());

        // 2. Production Areas
        ProductionArea cmpArea = productionAreaRepository.save(ProductionArea.builder()
                .plant(plant)
                .code("CMP-AREA")
                .name("Chemical Mechanical Planarization Bay")
                .description("Wafer surface planarization and chemical slurry polishing")
                .status(AreaStatus.ACTIVE)
                .build());

        ProductionArea etchArea = productionAreaRepository.save(ProductionArea.builder()
                .plant(plant)
                .code("ETCH-AREA")
                .name("Plasma Dry & Wet Etching Bay")
                .description("Precision dielectric and conductor plasma etching")
                .status(AreaStatus.ACTIVE)
                .build());

        ProductionArea cvdArea = productionAreaRepository.save(ProductionArea.builder()
                .plant(plant)
                .code("CVD-AREA")
                .name("Chemical Vapor Deposition Bay")
                .description("Atomic layer and thin-film chemical vapor deposition")
                .status(AreaStatus.ACTIVE)
                .build());

        productionAreaRepository.save(ProductionArea.builder()
                .plant(plant)
                .code("LITHO-AREA")
                .name("Extreme Ultraviolet Lithography Bay")
                .description("Sub-nanometer circuit patterning and photoresist exposure")
                .status(AreaStatus.ACTIVE)
                .build());

        // 3. Machines
        Machine cmpMachine = machineRepository.save(Machine.builder()
                .productionArea(cmpArea)
                .machineCode("CMP-001")
                .name("Applied Materials Reflexion LK")
                .machineType("CMP")
                .modelNumber("Reflexion LK CMP")
                .serialNumber("AMAT-2024-CMP-901")
                .manufacturer("Applied Materials")
                .criticality(MachineCriticality.CRITICAL)
                .status(MachineStatus.ACTIVE)
                .installationDate(LocalDate.now().minusDays(365))
                .build());

        Machine etchMachine = machineRepository.save(Machine.builder()
                .productionArea(etchArea)
                .machineCode("ETCH-001")
                .name("Lam Research Kiyo EX")
                .machineType("ETCH")
                .modelNumber("Kiyo EX Etcher")
                .serialNumber("LAM-2023-KT-441")
                .manufacturer("Lam Research")
                .criticality(MachineCriticality.HIGH)
                .status(MachineStatus.ACTIVE)
                .installationDate(LocalDate.now().minusDays(400))
                .build());

        Machine cvdMachine = machineRepository.save(Machine.builder()
                .productionArea(cvdArea)
                .machineCode("CVD-001")
                .name("Tokyo Electron Trias")
                .machineType("CVD")
                .modelNumber("Trias Titanium CVD")
                .serialNumber("TEL-2023-TR-812")
                .manufacturer("Tokyo Electron")
                .criticality(MachineCriticality.MEDIUM)
                .status(MachineStatus.ACTIVE)
                .installationDate(LocalDate.now().minusDays(250))
                .build());

        // 4. Sensors
        List<Sensor> allSensors = new ArrayList<>();

        // CMP-001 Sensors
        allSensors.add(Sensor.builder()
                .machine(cmpMachine)
                .sensorCode("CMP-001-TEMP-01")
                .name("Main Spindle Temperature")
                .sensorType(SensorType.TEMPERATURE)
                .unit("°C")
                .samplingIntervalMs(1000)
                .status(SensorStatus.ACTIVE)
                .minOperatingValue(20.0)
                .maxOperatingValue(95.0)
                .warningThreshold(75.0)
                .criticalThreshold(85.0)
                .healthState(SensorHealthState.NORMAL)
                .build());

        allSensors.add(Sensor.builder()
                .machine(cmpMachine)
                .sensorCode("CMP-001-VIB-01")
                .name("Platen Vibration Sensor")
                .sensorType(SensorType.VIBRATION)
                .unit("mm/s")
                .samplingIntervalMs(1000)
                .status(SensorStatus.ACTIVE)
                .minOperatingValue(0.0)
                .maxOperatingValue(15.0)
                .warningThreshold(5.0)
                .criticalThreshold(8.0)
                .healthState(SensorHealthState.NORMAL)
                .build());

        allSensors.add(Sensor.builder()
                .machine(cmpMachine)
                .sensorCode("CMP-001-CUR-01")
                .name("Motor Drive Current")
                .sensorType(SensorType.CURRENT)
                .unit("A")
                .samplingIntervalMs(1000)
                .status(SensorStatus.ACTIVE)
                .minOperatingValue(0.0)
                .maxOperatingValue(50.0)
                .warningThreshold(30.0)
                .criticalThreshold(40.0)
                .healthState(SensorHealthState.NORMAL)
                .build());

        allSensors.add(Sensor.builder()
                .machine(cmpMachine)
                .sensorCode("CMP-001-PRESS-01")
                .name("Slurry Delivery Pressure")
                .sensorType(SensorType.PRESSURE)
                .unit("psi")
                .samplingIntervalMs(1000)
                .status(SensorStatus.ACTIVE)
                .minOperatingValue(0.0)
                .maxOperatingValue(100.0)
                .warningThreshold(60.0)
                .criticalThreshold(75.0)
                .healthState(SensorHealthState.NORMAL)
                .build());

        allSensors.add(Sensor.builder()
                .machine(cmpMachine)
                .sensorCode("CMP-001-RPM-01")
                .name("Polishing Head Rotation")
                .sensorType(SensorType.RPM)
                .unit("RPM")
                .samplingIntervalMs(1000)
                .status(SensorStatus.ACTIVE)
                .minOperatingValue(500.0)
                .maxOperatingValue(3000.0)
                .warningThreshold(2200.0)
                .criticalThreshold(2500.0)
                .healthState(SensorHealthState.NORMAL)
                .build());

        allSensors.add(Sensor.builder()
                .machine(cmpMachine)
                .sensorCode("CMP-001-ACOUSTIC-01")
                .name("Pad Acoustic Emission")
                .sensorType(SensorType.ACOUSTIC)
                .unit("dB")
                .samplingIntervalMs(1000)
                .status(SensorStatus.ACTIVE)
                .minOperatingValue(20.0)
                .maxOperatingValue(120.0)
                .warningThreshold(75.0)
                .criticalThreshold(90.0)
                .healthState(SensorHealthState.NORMAL)
                .build());

        // ETCH-001 Sensors
        allSensors.add(Sensor.builder()
                .machine(etchMachine)
                .sensorCode("ETCH-001-TEMP-01")
                .name("Chamber Wall Temperature")
                .sensorType(SensorType.TEMPERATURE)
                .unit("°C")
                .samplingIntervalMs(1000)
                .status(SensorStatus.ACTIVE)
                .minOperatingValue(10.0)
                .maxOperatingValue(90.0)
                .warningThreshold(65.0)
                .criticalThreshold(80.0)
                .healthState(SensorHealthState.NORMAL)
                .build());

        allSensors.add(Sensor.builder()
                .machine(etchMachine)
                .sensorCode("ETCH-001-VIB-01")
                .name("Turbo Molecular Pump Vibration")
                .sensorType(SensorType.VIBRATION)
                .unit("mm/s")
                .samplingIntervalMs(1000)
                .status(SensorStatus.ACTIVE)
                .minOperatingValue(0.0)
                .maxOperatingValue(12.0)
                .warningThreshold(4.5)
                .criticalThreshold(7.0)
                .healthState(SensorHealthState.NORMAL)
                .build());

        // CVD-001 Sensors
        allSensors.add(Sensor.builder()
                .machine(cvdMachine)
                .sensorCode("CVD-001-TEMP-01")
                .name("Susceptor Heater Temperature")
                .sensorType(SensorType.TEMPERATURE)
                .unit("°C")
                .samplingIntervalMs(1000)
                .status(SensorStatus.ACTIVE)
                .minOperatingValue(50.0)
                .maxOperatingValue(300.0)
                .warningThreshold(240.0)
                .criticalThreshold(270.0)
                .healthState(SensorHealthState.NORMAL)
                .build());

        allSensors.add(Sensor.builder()
                .machine(cvdMachine)
                .sensorCode("CVD-001-CUR-01")
                .name("RF Plasma Current")
                .sensorType(SensorType.CURRENT)
                .unit("A")
                .samplingIntervalMs(1000)
                .status(SensorStatus.ACTIVE)
                .minOperatingValue(0.0)
                .maxOperatingValue(60.0)
                .warningThreshold(40.0)
                .criticalThreshold(50.0)
                .healthState(SensorHealthState.NORMAL)
                .build());

        List<Sensor> savedSensors = sensorRepository.saveAll(allSensors);

        // 5. Seed initial historical readings (past 30 minutes, 15 data points each)
        Random random = new Random();
        Instant now = Instant.now();
        List<SensorReading> readings = new ArrayList<>();

        for (Sensor sensor : savedSensors) {
            double baseVal = switch (sensor.getSensorType()) {
                case TEMPERATURE -> 52.0;
                case VIBRATION -> 1.6;
                case CURRENT -> 16.5;
                case PRESSURE -> 44.0;
                case RPM -> 1800.0;
                case ACOUSTIC -> 52.0;
                default -> 50.0;
            };

            for (int i = 15; i >= 0; i--) {
                Instant time = now.minus(i * 2L, ChronoUnit.MINUTES);
                double noise = (random.nextDouble() - 0.5) * (baseVal * 0.05);
                double val = Math.round((baseVal + noise) * 100.0) / 100.0;

                readings.add(SensorReading.builder()
                        .time(time)
                        .sensorId(sensor.getId())
                        .machineId(sensor.getMachine().getId())
                        .value(val)
                        .quality(ReadingQuality.GOOD)
                        .build());

                if (i == 0) {
                    sensor.setLastReadingTime(time);
                    sensor.setLastReadingValue(val);
                    sensor.setHealthState(SensorHealthState.NORMAL);
                }
            }
        }

        sensorReadingRepository.saveAll(readings);
        sensorRepository.saveAll(savedSensors);

        log.info("Successfully seeded 1 Plant, 4 Areas, 3 Machines, {} Sensors, and {} initial readings.",
                savedSensors.size(), readings.size());
    }

    @Transactional
    public void seedDigitalTwins() {
        List<Machine> machines = machineRepository.findAll();
        int seededCount = 0;
        for (Machine machine : machines) {
            if (!digitalTwinRepository.existsByMachineId(machine.getId())) {
                digitalTwinRepository.save(DigitalTwin.builder()
                        .twinCode("DT-" + machine.getMachineCode())
                        .machine(machine)
                        .status(DigitalTwinStatus.ACTIVE)
                        .createdAt(Instant.now())
                        .updatedAt(Instant.now())
                        .build());
                seededCount++;
                try {
                    digitalTwinSyncService.synchronizeMachine(machine.getId());
                } catch (Exception e) {
                    log.debug("Initial digital twin sync deferred for {}: {}", machine.getMachineCode(), e.getMessage());
                }
            }
        }
        log.info("Initialized Digital Twins for {} machines ({} newly created).", machines.size(), seededCount);
    }
}
